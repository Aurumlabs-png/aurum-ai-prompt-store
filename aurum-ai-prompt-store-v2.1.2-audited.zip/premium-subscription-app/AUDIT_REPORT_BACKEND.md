# Aurum AI Prompt Store — Backend & Security Audit Report

**Scope:** Backend API, authentication/authorization, JWT/session security, Prisma
schema & relationships, Paystack payment security, secure download protection,
input sanitization, error handling, code duplication, backend performance.

**Explicitly out of scope for this pass:** Frontend, UI/UX, mobile responsiveness,
SEO, accessibility. No features were added or redesigned — every change below is a
fix to existing, already-shipped behavior.

---

## 1. Problems Found & Fixed

### 🔴 Critical

| # | Issue | File(s) | Fix |
|---|---|---|---|
| 1 | **Email verification bypass.** `GET /api/auth/verify-email` passed `req.query.token` straight into a Prisma `findFirst` `where` clause with no presence check. Prisma silently drops `undefined` fields from a `where` clause — so a request with **no** `?token=` at all collapsed the query to "any user with a non-expired verification token" and verified whoever matched first, regardless of who asked. | `authController.js` | Added a `typeof token !== 'string' \|\| !token` guard before the query. |
| 2 | **Broken object-level authorization on payment verification.** `GET /api/payments/verify/:reference` performed no ownership check — any authenticated user could pass another user's payment reference and trigger Paystack verification + state changes (including marking someone else's payment `FAILED`) on it. | `paymentController.js` | Added an explicit ownership check (`payment.userId === req.user.id \|\| role === 'ADMIN'`) before calling Paystack, returning 403/404 otherwise. |
| 3 | **CSV/formula injection (CWE-1236) in subscriber export.** `name`/`email` are user-controlled at signup with no character restrictions. A value starting with `=`, `+`, `-`, or `@` is interpreted as a formula by Excel/Sheets **even inside quoted CSV fields**. A low-privilege user could plant a payload (e.g. `=HYPERLINK(...)`, `=cmd\|...`) that executes when an **admin** opens `subscribers.csv`. | `adminController.js` | Added OWASP-standard mitigation: prefix any field starting with `=+-@` or tab/CR with a leading `'`. |

### 🟠 High — Authorization / Data Integrity

| # | Issue | File(s) | Fix |
|---|---|---|---|
| 4 | Same `undefined`-filter class of bug also present in `forgotPassword` (no validation on `email` at all) and `resetPassword` (validated `password` but not `token`'s type). Both could reach Prisma with an `undefined` filter under the right malformed request. | `authController.js` | Added type/presence guards to both. Systematically re-audited **every** `findFirst`/`findUnique` call site in the codebase for this exact pattern — confirmed no other occurrences (all other sites use route params, which Express can never deliver as `undefined`, or already-authenticated `req.user.id`). |
| 5 | Review submissions had no DB-level uniqueness constraint on `(userId, contentId)` — the controller did find-then-write, a TOCTOU race that let concurrent requests create duplicate reviews from the same user. | `schema.prisma`, `reviewController.js` | Added `@@unique([userId, contentId])`; rewrote `createReview` to use `upsert` against the constraint (atomic at the DB level). |
| 6 | `Content.rating` was a static default (4.8) that the review-approval flow never actually updated — displayed ratings were completely disconnected from real review data. | `reviewController.js` | Added `recomputeContentRating()`, called after approve/reject/delete so the rating reflects the live average of approved reviews. |

### 🟡 Medium — Input Validation Gaps

Several endpoints coerced request input with `Number()`/direct assignment and passed it straight to Prisma with no validation. Because Prisma throws a `PrismaClientValidationError` (no `.code` property) for type/enum mismatches, these were **invisible to the error handler that existed before this audit** and surfaced as raw, unhelpful 500s — including on publicly-reachable, unauthenticated endpoints.

| # | Endpoint | Problem | Fix |
|---|---|---|---|
| 7 | `GET /api/marketplace/prompts?type=` (**public, unauthenticated**) | Any value for `type` was passed directly into an enum filter — `?type=anything` 500'd. | Validated against the `ContentType` enum before querying. |
| 8 | `POST /api/content` (admin upload) | `type` never validated against the enum before Cloudinary upload + DB write. | Added the same enum check. |
| 9 | `POST /api/admin/coupons`, `PATCH /api/admin/coupons/:id` | `value`/`usageLimit` coerced with `Number()` with no finiteness check — non-numeric input produced `NaN` written toward the DB; no upper bound on `PERCENTAGE` (a >100% coupon was possible). | Added `Number.isFinite`/`Number.isInteger` checks and a 100% cap. |
| 10 | `PATCH /api/admin/settings` (`membershipPriceKobo`, `membershipDurationDays`) | **Feeds directly into the live Paystack charge amount and subscription length** with zero validation — a malformed or malicious value here corrupts every subsequent subscription charge. | Added strict positive-integer validation before write. |
| 11 | `POST /api/admin/coins/rules`, `PATCH .../rules/:id` | `coinAmount` coerced with `Number()`, no validation; `name`/`trigger` not required-checked. | Added full validation (required strings, positive integer amount). |
| 12 | `PATCH /api/users/profile` | `name` had zero validation, even though **signup** enforces a 2–80 character policy via Zod — the policy was trivially bypassable by editing your profile immediately after signing up. | Added matching validation to close the bypass. |
| 13 | `PATCH /api/users/password` | `currentPassword` was passed straight to `bcrypt.compare()` with no type check — a missing/non-string value throws synchronously inside bcrypt, producing an unhandled 500 instead of a clean 400. | Added a type/presence guard. |
| 14 | `POST /api/auth/login` | Only checked truthiness, not type, of `email`/`password`. | Added `typeof === 'string'` checks. |
| 15 | `POST /api/payments/coupon/validate`, coupon path in `POST /api/payments/initialize` | `applyCoupon(code, ...)` called `code.trim()` immediately with no guard — a missing `code` threw an unhandled `TypeError`. | Added a guard inside the shared `applyCoupon()` function, fixing both call sites at once. |
| 16 | `GET /api/marketplace/prompts?limit=` | A negative `limit` (e.g. `-5`) produced a negative Prisma `take`, which Prisma silently interprets as "reverse order" rather than erroring — confusing, unintended pagination behavior. | Clamped `take` to `[1, 50]`. |

### 🟢 Low — Hardening

| # | Issue | Fix |
|---|---|---|
| 17 | `jwt.verify()` didn't pin allowed algorithms — defense-in-depth gap against algorithm-confusion attacks. | Added explicit `{ algorithms: ['HS256'] }`. |
| 18 | Paystack webhook HMAC signature check used `signature !== expected` — a plain string comparison, not timing-safe. Low practical exploitability remotely, but a documented best-practice gap on the exact code path that authorizes payment activation. | Switched to `crypto.timingSafeEqual` with a length guard (handles missing/malformed signature headers safely). |
| 19 | `POST /api/payments/coupon/validate` had no rate limit — an authenticated user could brute-force coupon codes with unlimited attempts. | Added `paymentLimiter`. |
| 20 | Unused `csurf` dependency listed in `package.json` but never `require()`'d anywhere — dead weight, and `csurf` is an unmaintained package with known advisories, so keeping it invites false confidence and npm-audit noise for a protection that isn't actually active. | Removed. (CSRF risk is already mitigated by the `sameSite: 'lax'` cookie policy, which blocks cross-site XHR/fetch from carrying the auth cookie.) |
| 21 | Dead `signRefreshToken()` / `JWT_REFRESH_SECRET` / `JWT_REFRESH_EXPIRES_IN` — scaffolded but never wired into any auth flow, misleadingly implying a refresh-token rotation system exists. | Removed the unused function and env vars. |

### ⚙️ Production Readiness / Performance

| # | Issue | Fix |
|---|---|---|
| 22 | **Missing `trust proxy` setting.** The deployment guide recommends Railway/Render, both of which sit behind a reverse proxy. Without `trust proxy` set, `express-rate-limit@7` throws on the `X-Forwarded-For` header those proxies add — this would have broken (or thrown on) every rate-limited request in the documented production deployment path. | Added `app.set('trust proxy', 1)`. |
| 23 | `GET /api/admin/subscribers?status=` fetched **every** user into memory and filtered by subscription status in JavaScript. | Moved the filter into the Prisma `where` clause (DB-level). |
| 24 | `getRevenue` and `getDashboardStats` independently duplicated the same monthly-aggregation loop, each pulling **full** `Payment` rows into memory just to sum a number. | Extracted a shared `getRevenueSummary()` helper using `prisma.payment.aggregate()` for the total and a slim two-column `select` for the monthly breakdown. |
| 25 | `GET /api/content` (legacy listing, backs the dashboard's "Recent Prompts" widget) had no result limit — returns the entire `Content` table on every call as the catalog grows. | Added a capped, configurable `limit` (default 50, max 100). |
| 26 | Tag-parsing logic (comma-split/trim/filter) duplicated verbatim between `createContent` and `updateContent`. | Extracted to a shared `parseTags()` helper. |
| 27 | Near-identical `optionalAuth` middleware copy-pasted in `content.routes.js` and `marketplace.routes.js`. | Consolidated into a single exported `optionalAuth` in `middleware/auth.js`. |

---

## 2. Problems Deferred (with reasoning)

These are real, verified findings that were **not** fixed in this pass, because
fixing them properly would mean redesigning existing architecture or shipping new
functionality — both explicitly out of scope ("do not redesign," "do not build new
features"). Flagging them clearly rather than either ignoring them or overstepping
scope with a risky partial fix.

1. **Premium file URLs are not access-controlled at the storage layer.**
   `secureDownload` correctly *gates who receives* a content file's URL (via
   `requireActiveSubscription`), but the underlying Cloudinary assets are uploaded
   as public resources (`resource_type` only, no `type: 'authenticated'`). Once a
   legitimate subscriber receives a `fileUrl`, that URL works for **anyone**,
   indefinitely, with no auth — the app-layer gate only controls the *first*
   hand-off, not redistribution.
   **Why deferred:** a correct fix requires switching the Cloudinary upload type
   to `authenticated`, storing the asset's `public_id` (not just `secure_url`) on
   `Content`, and generating short-lived signed URLs per download request. This
   changes the upload/download data model and would need re-uploading any content
   already in production under the old public type — a coordinated infrastructure
   change, not a safe drop-in patch. **Recommended follow-up**, in priority order:
   switch new uploads to `type: 'authenticated'`, add a `cloudinaryPublicId` field
   to `Content`, and have `secureDownload` call
   `cloudinary.utils.private_download_url()` to mint a time-limited URL per request.

2. **Non-premium (`isPremium: false`) content still requires an active
   subscription to download**, because `requireActiveSubscription` is applied
   unconditionally to all of `POST /api/downloads/:contentId`. This is a
   functional inconsistency, not a security hole — it fails *safe* (more
   restrictive than intended), never *open*. Loosening this is a behavior change
   to existing, working logic and was left alone per "do not redesign."

3. **Coupon `value` is stored as `Float`.** For a currency-adjacent field this
   carries a theoretical floating-point precision risk. In practice, all values
   entered through the existing admin UI are whole Naira/percentage numbers, so
   this has not manifested as a real bug. A `Decimal`/integer-kobo migration would
   be the correct long-term fix but is a schema-shape change beyond this pass's
   "fix verified issues" mandate.

4. **`RewardRule` records (Coins Management) are configurable in the admin panel
   but nothing in the codebase actually fires them** — e.g. creating a `SIGNUP`
   trigger rule does not currently grant coins on signup. This was flagged but
   intentionally not wired up: doing so is *new behavior* (an automatic
   coin-granting engine), not a fix to an existing broken code path, and is
   explicitly excluded by "do not build new features."

5. **Frontend audit not started** (verify-email UI, coupon UI, dynamic pricing
   display, ARIA/accessibility, SEO metadata, mobile responsiveness) — per this
   task's explicit scope, frontend QA was not touched in this pass and remains a
   distinct follow-up.

---

## 3. Security Improvements Summary

- Closed one **critical authentication bypass** (email verification) and one
  **broken object-level authorization** issue (cross-user payment verification).
- Closed a **CSV/formula-injection** vector reachable by any registered user,
  targeting admin sessions.
- Systematically eliminated an entire *class* of bug (Prisma `undefined`-filter
  silently dropping `where` conditions) across every call site in the codebase,
  not just the one it was first found in.
- Hardened JWT verification (explicit algorithm allow-list) and webhook
  signature verification (timing-safe comparison).
- Closed input-validation gaps on every endpoint that writes numeric values
  feeding into live payment amounts or DB enum columns — the highest-value
  targets, since these directly affect money movement and were previously
  capable of 500ing on malformed/malicious input.
- Removed a dead, unmaintained dependency (`csurf`) that provided a false sense
  of protection while doing nothing.
- Fixed a `trust proxy` misconfiguration that would have broken rate limiting
  (or thrown errors outright) on the exact production deployment path this
  project's own docs recommend.

## 4. Production Readiness Status

**Backend: substantially more production-ready than before this audit**, with
one clearly-documented, non-trivial gap remaining (storage-layer file
protection — see Deferred #1). All fixes in this report are additive/corrective:
no existing endpoint contract changed shape, no feature was removed, and the
Prisma schema change (`Review` unique constraint) is additive-only and requires
only a standard `prisma migrate dev`.

**Recommended before public launch:**
1. Implement signed/authenticated Cloudinary URLs (Deferred #1) — the single
   highest-impact remaining gap for a "premium paid content" product.
2. Run `npm audit` on both `frontend/` and `backend/` after `npm install` (not
   possible in this sandboxed environment — no package registry access) and
   patch any flagged transitive vulnerabilities.
3. Complete a corresponding Frontend & Accessibility QA pass (out of scope here).
4. Load-test the payment webhook and dashboard aggregation endpoints before
   high-traffic launch.
