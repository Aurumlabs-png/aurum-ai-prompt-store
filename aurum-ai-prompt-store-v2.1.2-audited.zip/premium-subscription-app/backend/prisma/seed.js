const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const prisma = new PrismaClient();

async function main() {
  const adminEmail = 'admin@premiumplatform.com';
  let admin = await prisma.user.findUnique({ where: { email: adminEmail } });

  if (admin) {
    console.log('Admin already exists, skipping admin creation.');
  } else {
    const password = await bcrypt.hash('ChangeMe123!', 12);
    admin = await prisma.user.create({
      data: {
        name: 'Platform Admin',
        email: adminEmail,
        password,
        role: 'ADMIN',
        isEmailVerified: true,
        subscription: { create: { status: 'ACTIVE', startedAt: new Date(), expiresAt: new Date('2099-01-01') } },
      },
    });
    console.log('Seeded admin user:');
    console.log(`  email: ${adminEmail}`);
    console.log('  password: ChangeMe123!  (change this immediately after first login)');
  }

  const existingContent = await prisma.content.count();
  if (existingContent === 0) {
    const samples = [
      { title: 'The Perfect Cold Email', category: 'Marketing', type: 'TEXT', isBestSeller: true, isVerified: true },
      { title: 'Cinematic Character Portrait', category: 'Art & Midjourney', type: 'TEXT', isTrending: true, isVerified: true },
      { title: 'Full-Stack Code Reviewer', category: 'Coding & Development', type: 'TEXT', isVerified: true },
      { title: 'Investor Pitch Refiner', category: 'Business & Strategy', type: 'TEXT', isBestSeller: true },
      { title: 'SEO Blog Architect', category: 'Writing & Content', type: 'TEXT', isTrending: true },
      { title: 'Research Paper Synthesizer', category: 'Education & Research', type: 'TEXT' },
    ];

    await prisma.content.createMany({
      data: samples.map((s) => ({
        title: s.title,
        description: `A hand-crafted, tested prompt for ${s.category.toLowerCase()}.`,
        type: s.type,
        category: s.category,
        isPremium: true,
        isTrending: !!s.isTrending,
        isBestSeller: !!s.isBestSeller,
        isVerified: !!s.isVerified,
        fileUrl: 'https://example.com/placeholder-prompt.txt',
        uploadedById: admin.id,
      })),
    });
    console.log(`Seeded ${samples.length} sample marketplace prompts.`);
  } else {
    console.log('Content already seeded, skipping.');
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
