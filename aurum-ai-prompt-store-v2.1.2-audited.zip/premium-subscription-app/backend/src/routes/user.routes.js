const router = require('express').Router();
const { protect } = require('../middleware/auth');
const {
  updateProfile,
  changePassword,
  toggleDarkMode,
  getNotifications,
  markNotificationRead,
} = require('../controllers/userController');

router.use(protect);
router.patch('/profile', updateProfile);
router.patch('/password', changePassword);
router.patch('/dark-mode', toggleDarkMode);
router.get('/notifications', getNotifications);
router.patch('/notifications/:id/read', markNotificationRead);

module.exports = router;
