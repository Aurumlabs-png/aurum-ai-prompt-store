const router = require('express').Router();
const { protect } = require('../middleware/auth');
const { createReview, getApprovedReviews } = require('../controllers/reviewController');

router.get('/:contentId', getApprovedReviews); // public
router.post('/:contentId', protect, createReview);

module.exports = router;
