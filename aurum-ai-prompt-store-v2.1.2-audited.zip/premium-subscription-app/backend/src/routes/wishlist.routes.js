const router = require('express').Router();
const { protect } = require('../middleware/auth');
const { getWishlist, addToWishlist, removeFromWishlist } = require('../controllers/wishlistController');

router.use(protect);
router.get('/', getWishlist);
router.post('/:contentId', addToWishlist);
router.delete('/:contentId', removeFromWishlist);

module.exports = router;
