const router = require('express').Router();
const { protect } = require('../middleware/auth');
const { getStatus, cancelAutoRenew } = require('../controllers/subscriptionController');

router.get('/status', protect, getStatus);
router.post('/cancel-renewal', protect, cancelAutoRenew);

module.exports = router;
