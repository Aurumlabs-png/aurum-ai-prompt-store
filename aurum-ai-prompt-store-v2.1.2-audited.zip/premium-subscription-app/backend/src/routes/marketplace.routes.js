const router = require('express').Router();
const { optionalAuth } = require('../middleware/auth');
const { listPrompts, getTrending, getPromptDetail } = require('../controllers/marketplaceController');

router.get('/prompts', optionalAuth, listPrompts);
router.get('/trending', optionalAuth, getTrending);
router.get('/prompts/:id', optionalAuth, getPromptDetail);

module.exports = router;
