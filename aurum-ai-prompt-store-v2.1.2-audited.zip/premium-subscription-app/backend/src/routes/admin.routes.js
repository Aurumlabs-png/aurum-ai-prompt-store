const router = require('express').Router();
const { protect, restrictTo } = require('../middleware/auth');

const {
  getSubscribers,
  getUserDetail,
  suspendUser,
  banUser,
  reactivateUser,
  deleteUser,
  getRevenue,
  getAnalytics,
  getDashboardStats,
  exportSubscribersCsv,
  getAllPayments,
  refundPayment,
} = require('../controllers/adminController');

const {
  addCoins,
  removeCoins,
  getCoinHistory,
  listRewardRules,
  createRewardRule,
  updateRewardRule,
  deleteRewardRule,
} = require('../controllers/coinController');

const { listCoupons, createCoupon, updateCoupon, deleteCoupon } = require('../controllers/couponController');

const { listReviewsAdmin, approveReview, rejectReview, deleteReview } = require('../controllers/reviewController');

const { getAdminSettings, updateSettings } = require('../controllers/settingsController');

router.use(protect, restrictTo('ADMIN'));

// ---- Dashboard Home ----
router.get('/dashboard', getDashboardStats);
router.get('/revenue', getRevenue);
router.get('/analytics', getAnalytics);
router.get('/payments', getAllPayments);
router.post('/payments/:id/refund', refundPayment);
router.get('/export/subscribers.csv', exportSubscribersCsv);

// ---- User Management ----
router.get('/subscribers', getSubscribers);
router.get('/users/:id', getUserDetail);
router.patch('/users/:id/suspend', suspendUser);
router.patch('/users/:id/ban', banUser);
router.patch('/users/:id/reactivate', reactivateUser);
router.delete('/users/:id', deleteUser);

// ---- Coins Management ----
router.get('/coins/history', getCoinHistory);
router.post('/coins/:userId/add', addCoins);
router.post('/coins/:userId/remove', removeCoins);
router.get('/coins/rules', listRewardRules);
router.post('/coins/rules', createRewardRule);
router.patch('/coins/rules/:id', updateRewardRule);
router.delete('/coins/rules/:id', deleteRewardRule);

// ---- Coupons ----
router.get('/coupons', listCoupons);
router.post('/coupons', createCoupon);
router.patch('/coupons/:id', updateCoupon);
router.delete('/coupons/:id', deleteCoupon);

// ---- Reviews ----
router.get('/reviews', listReviewsAdmin);
router.patch('/reviews/:id/approve', approveReview);
router.patch('/reviews/:id/reject', rejectReview);
router.delete('/reviews/:id', deleteReview);

// ---- Website Settings ----
router.get('/settings', getAdminSettings);
router.patch('/settings', updateSettings);

module.exports = router;
