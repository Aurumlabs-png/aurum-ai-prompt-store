const router = require('express').Router();
const { protect } = require('../middleware/auth');
const { paymentLimiter } = require('../middleware/rateLimit');
const {
  initializePayment,
  verifyPayment,
  paystackWebhook,
  getPaymentHistory,
  validateCoupon,
} = require('../controllers/paymentController');

// Webhook must stay PUBLIC (Paystack calls it directly) — it is protected
// instead by HMAC signature verification inside the controller.
router.post('/webhook', paystackWebhook);

router.post('/initialize', protect, paymentLimiter, initializePayment);
router.get('/verify/:reference', protect, verifyPayment);
router.get('/history', protect, getPaymentHistory);
router.post('/coupon/validate', protect, paymentLimiter, validateCoupon);

module.exports = router;
