const router = require('express').Router();
const { getPublicSettings } = require('../controllers/settingsController');

// Public — the frontend reads this to render branding, theme, and analytics tags.
router.get('/', getPublicSettings);

module.exports = router;
