const router = require('express').Router();
const { protect } = require('../middleware/auth');
const { getCart, addToCart, removeFromCart, checkout } = require('../controllers/cartController');

router.use(protect);
router.get('/', getCart);
router.post('/checkout', checkout);
router.post('/:contentId', addToCart);
router.delete('/:contentId', removeFromCart);

module.exports = router;
