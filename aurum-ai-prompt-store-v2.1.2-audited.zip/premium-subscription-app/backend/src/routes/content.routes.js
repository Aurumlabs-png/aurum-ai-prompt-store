const router = require('express').Router();
const multer = require('multer');
const { protect, restrictTo, requireActiveSubscription, optionalAuth } = require('../middleware/auth');
const {
  listContent,
  getContent,
  createContent,
  updateContent,
  deleteContent,
} = require('../controllers/contentController');

// In-memory storage — buffer streamed straight to Cloudinary, never
// written to local disk. 100MB cap covers video/audio uploads.
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 100 * 1024 * 1024 } });

router.get('/', optionalAuth, listContent);
router.get('/:id', protect, requireActiveSubscription, getContent);

router.post('/', protect, restrictTo('ADMIN'), upload.single('file'), createContent);
router.patch('/:id', protect, restrictTo('ADMIN'), updateContent);
router.delete('/:id', protect, restrictTo('ADMIN'), deleteContent);

module.exports = router;
