const router = require('express').Router();
const { protect, requireActiveSubscription } = require('../middleware/auth');
const { secureDownload, getDownloadHistory } = require('../controllers/downloadController');

router.use(protect);
router.get('/history', getDownloadHistory);
router.post('/:contentId', requireActiveSubscription, secureDownload);

module.exports = router;
