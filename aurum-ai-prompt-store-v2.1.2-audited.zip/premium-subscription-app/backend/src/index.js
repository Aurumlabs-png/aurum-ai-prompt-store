require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const hpp = require('hpp');
const xssClean = require('xss-clean');
const mongoSanitize = require('express-mongo-sanitize');

const { globalLimiter } = require('./middleware/rateLimit');
const errorHandler = require('./middleware/errorHandler');

const authRoutes = require('./routes/auth.routes');
const userRoutes = require('./routes/user.routes');
const subscriptionRoutes = require('./routes/subscription.routes');
const paymentRoutes = require('./routes/payment.routes');
const contentRoutes = require('./routes/content.routes');
const adminRoutes = require('./routes/admin.routes');
const marketplaceRoutes = require('./routes/marketplace.routes');
const wishlistRoutes = require('./routes/wishlist.routes');
const cartRoutes = require('./routes/cart.routes');
const downloadRoutes = require('./routes/download.routes');
const settingsRoutes = require('./routes/settings.routes');
const reviewRoutes = require('./routes/review.routes');

const app = express();

// Trust the first proxy hop (Railway/Render/etc. sit in front of this app).
// Without this, express-rate-limit v7 throws on the X-Forwarded-For header
// it receives from the proxy, and req.ip would reflect the proxy's address
// instead of the real client — breaking both rate limiting and audit logs.
app.set('trust proxy', 1);

// ---------- Security middleware ----------
app.use(helmet()); // sets secure HTTP headers
app.use(
  cors({
    origin: process.env.CLIENT_URL || 'http://localhost:3000',
    credentials: true,
  })
);

// NOTE: Paystack/Flutterwave/Stripe webhooks require the RAW body for
// signature verification, so we register the webhook route's raw parser
// BEFORE the global json() parser below.
app.use('/api/payments/webhook', express.raw({ type: 'application/json' }));

app.use(express.json({ limit: '10mb' }));
app.use(cookieParser(process.env.COOKIE_SECRET));
app.use(hpp()); // HTTP Parameter Pollution protection
app.use(xssClean()); // sanitizes user input against XSS
app.use(mongoSanitize()); // strips $ and . operators from input (NoSQL/JSON injection)
app.use(globalLimiter); // rate limiting on all routes

// SQL Injection protection: handled at the data layer — Prisma uses
// parameterized queries for every generated call, so raw string
// interpolation into SQL is never used anywhere in this codebase.

// ---------- Routes ----------
app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/subscriptions', subscriptionRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/content', contentRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/marketplace', marketplaceRoutes);
app.use('/api/wishlist', wishlistRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/downloads', downloadRoutes);
app.use('/api/settings', settingsRoutes);
app.use('/api/reviews', reviewRoutes);

// ---------- 404 + error handling ----------
app.use((req, res) => res.status(404).json({ success: false, message: 'Route not found' }));
app.use(errorHandler);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT} [${process.env.NODE_ENV}]`));

module.exports = app;
