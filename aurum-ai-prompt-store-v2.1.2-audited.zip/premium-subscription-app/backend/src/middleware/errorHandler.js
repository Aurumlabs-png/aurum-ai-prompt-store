// Centralized error handler. Never leaks stack traces in production.

/**
 * Translates known Prisma error codes into clean HTTP responses instead of
 * letting them fall through as opaque 500s. Codes reference:
 * https://www.prisma.io/docs/orm/reference/error-reference
 */
function mapPrismaError(err) {
  if (!err || typeof err.code !== 'string' || !err.code.startsWith('P')) return null;

  switch (err.code) {
    case 'P2002': // unique constraint violation
      return { statusCode: 409, message: `A record with this ${err.meta?.target || 'value'} already exists.` };
    case 'P2003': // foreign key constraint violation (e.g. referencing a deleted/nonexistent record)
      return { statusCode: 400, message: 'This action references a record that does not exist.' };
    case 'P2025': // record to update/delete was not found
      return { statusCode: 404, message: 'The requested record was not found.' };
    case 'P2000': // value too long for column type
      return { statusCode: 400, message: 'One of the provided values is too long.' };
    case 'P2011': // null constraint violation
      return { statusCode: 400, message: 'A required field was missing.' };
    default:
      return null;
  }
}

function errorHandler(err, req, res, next) {
  console.error(err);

  const prismaMapping = mapPrismaError(err);
  const statusCode = prismaMapping?.statusCode || err.statusCode || 500;
  const rawMessage = prismaMapping?.message || err.message;

  const message =
    process.env.NODE_ENV === 'production' && statusCode === 500
      ? 'Something went wrong. Please try again later.'
      : rawMessage || 'Server error';

  res.status(statusCode).json({
    success: false,
    message,
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack }),
  });
}

module.exports = errorHandler;
