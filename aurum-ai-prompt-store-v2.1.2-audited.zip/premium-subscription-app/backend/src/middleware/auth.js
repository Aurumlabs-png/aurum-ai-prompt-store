const jwt = require('jsonwebtoken');
const prisma = require('../config/db');

/**
 * Verifies the JWT sent either as an httpOnly cookie ("token") or as a
 * Bearer token in the Authorization header. Attaches the authenticated
 * user (minus password) to req.user.
 */
async function protect(req, res, next) {
  try {
    let token;

    if (req.cookies?.token) {
      token = req.cookies.token;
    } else if (req.headers.authorization?.startsWith('Bearer ')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return res.status(401).json({ success: false, message: 'Not authenticated' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET, { algorithms: ['HS256'] });

    const user = await prisma.user.findUnique({
      where: { id: decoded.id },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        status: true,
        isEmailVerified: true,
        darkMode: true,
        avatarUrl: true,
      },
    });

    if (!user) {
      return res.status(401).json({ success: false, message: 'User no longer exists' });
    }

    if (user.status === 'BANNED') {
      return res.status(403).json({ success: false, message: 'This account has been banned. Contact support for details.' });
    }
    if (user.status === 'SUSPENDED') {
      return res.status(403).json({ success: false, message: 'This account is suspended. Contact support for details.' });
    }

    req.user = user;
    next();
  } catch (err) {
    return res.status(401).json({ success: false, message: 'Invalid or expired token' });
  }
}

/** Role-based access control. Usage: restrictTo('ADMIN') */
function restrictTo(...roles) {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: 'Insufficient permissions' });
    }
    next();
  };
}

/**
 * Blocks access to premium content unless the user has an ACTIVE,
 * non-expired subscription. Admins always pass through.
 */
async function requireActiveSubscription(req, res, next) {
  if (req.user.role === 'ADMIN') return next();

  const subscription = await prisma.subscription.findUnique({
    where: { userId: req.user.id },
  });

  const isActive =
    subscription &&
    subscription.status === 'ACTIVE' &&
    subscription.expiresAt &&
    new Date(subscription.expiresAt) > new Date();

  if (!isActive) {
    return res.status(402).json({
      success: false,
      message: 'An active subscription is required to access this content',
    });
  }

  next();
}

/**
 * Like `protect`, but never blocks the request. If a valid session is
 * present it attaches req.user; otherwise the request proceeds unauthenticated.
 * Used by public-but-personalized routes (e.g. marketplace listings that
 * show locked/unlocked state). Consolidated here to avoid the near-identical
 * copies that previously existed in content.routes.js and marketplace.routes.js.
 */
function optionalAuth(req, res, next) {
  if (req.cookies?.token || req.headers.authorization) {
    return protect(req, res, next);
  }
  next();
}

module.exports = { protect, restrictTo, requireActiveSubscription, optionalAuth };
