const prisma = require('../config/db');

/** Fetches the singleton Settings row, creating it with defaults if absent. */
async function getOrCreateSettings() {
  let settings = await prisma.settings.findUnique({ where: { id: 'singleton' } });
  if (!settings) {
    settings = await prisma.settings.create({ data: { id: 'singleton' } });
  }
  return settings;
}

/** Resolves the current subscription price in kobo — DB override, else env default. */
async function getSubscriptionPriceKobo() {
  const settings = await getOrCreateSettings();
  return settings.membershipPriceKobo || Number(process.env.SUBSCRIPTION_PRICE_KOBO || 100000);
}

/** Resolves the current subscription duration in days — DB override, else env default. */
async function getSubscriptionDurationDays() {
  const settings = await getOrCreateSettings();
  return settings.membershipDurationDays || Number(process.env.SUBSCRIPTION_DURATION_DAYS || 30);
}

module.exports = { getOrCreateSettings, getSubscriptionPriceKobo, getSubscriptionDurationDays };
