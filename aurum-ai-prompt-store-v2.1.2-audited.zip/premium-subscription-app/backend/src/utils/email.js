const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT) || 587,
  secure: false,
  auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
});

async function sendEmail({ to, subject, html }) {
  await transporter.sendMail({
    from: process.env.EMAIL_FROM,
    to,
    subject,
    html,
  });
}

const wrap = (title, body) => `
  <div style="font-family: Arial, sans-serif; max-width:600px; margin:auto; padding:32px; background:#0b1f17; color:#f5f0e6;">
    <h1 style="color:#d4af37; font-size:20px;">${title}</h1>
    <div style="line-height:1.6; font-size:14px;">${body}</div>
    <p style="margin-top:32px; font-size:12px; color:#9ca3af;">Premium Platform &copy; ${new Date().getFullYear()}</p>
  </div>`;

const sendVerificationEmail = (to, link) =>
  sendEmail({
    to,
    subject: 'Verify your email',
    html: wrap('Verify your email', `<p>Click below to verify your account:</p><a href="${link}" style="color:#d4af37;">${link}</a>`),
  });

const sendResetPasswordEmail = (to, link) =>
  sendEmail({
    to,
    subject: 'Reset your password',
    html: wrap('Reset password', `<p>Click below to reset your password (valid 30 minutes):</p><a href="${link}" style="color:#d4af37;">${link}</a>`),
  });

const sendPaymentConfirmationEmail = (to, { amount, reference, expiresAt }) =>
  sendEmail({
    to,
    subject: 'Payment confirmed — subscription active',
    html: wrap(
      'Payment received',
      `<p>Your payment of ₦${(amount / 100).toLocaleString()} was successful.</p>
       <p>Reference: <b>${reference}</b></p>
       <p>Your premium subscription is active until <b>${new Date(expiresAt).toDateString()}</b>.</p>`
    ),
  });

module.exports = {
  sendEmail,
  sendVerificationEmail,
  sendResetPasswordEmail,
  sendPaymentConfirmationEmail,
};
