const jwt = require('jsonwebtoken');

function signAccessToken(userId) {
  return jwt.sign({ id: userId }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });
}

/** Sets the JWT as a secure, httpOnly cookie (mitigates XSS token theft). */
function sendTokenCookie(res, token) {
  res.cookie('token', token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax', // CSRF mitigation for cross-site cookie use
    maxAge: 7 * 24 * 60 * 60 * 1000,
  });
}

module.exports = { signAccessToken, sendTokenCookie };
