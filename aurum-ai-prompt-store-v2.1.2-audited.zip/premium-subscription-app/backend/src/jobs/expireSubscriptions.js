/**
 * Run this on a daily schedule (Railway/Render cron, or `node-cron` in
 * process) to flip ACTIVE subscriptions to EXPIRED once their expiresAt
 * has passed, independent of whether the user logs in.
 *
 * Example wiring with node-cron in src/index.js:
 *   const cron = require('node-cron');
 *   cron.schedule('0 1 * * *', require('./jobs/expireSubscriptions'));
 */
const prisma = require('../config/db');

module.exports = async function expireSubscriptions() {
  const result = await prisma.subscription.updateMany({
    where: { status: 'ACTIVE', expiresAt: { lt: new Date() } },
    data: { status: 'EXPIRED' },
  });
  console.log(`[cron] Expired ${result.count} subscription(s) at ${new Date().toISOString()}`);
  return result.count;
};
