const asyncHandler = require('express-async-handler');
const prisma = require('../config/db');

const NEW_WINDOW_DAYS = 14;

/** Returns whether the requesting user currently has unlocked access. */
async function getHasAccess(userId, role) {
  if (role === 'ADMIN') return true;
  if (!userId) return false;
  const sub = await prisma.subscription.findUnique({ where: { userId } });
  return !!(sub?.status === 'ACTIVE' && sub.expiresAt && sub.expiresAt > new Date());
}

/** Strips the real fileUrl from locked items and attaches computed badge flags. */
function decorate(item, hasAccess) {
  const isNew = Date.now() - new Date(item.createdAt).getTime() < NEW_WINDOW_DAYS * 24 * 60 * 60 * 1000;
  const locked = item.isPremium && !hasAccess;
  return {
    ...item,
    fileUrl: locked ? null : item.fileUrl,
    locked,
    badges: {
      trending: item.isTrending,
      bestSeller: item.isBestSeller,
      verified: item.isVerified,
      featured: item.isFeatured,
      isNew,
    },
  };
}

const CONTENT_TYPES = ['TEXT', 'IMAGE', 'VIDEO', 'PDF', 'AUDIO'];

// @route GET /api/marketplace/prompts
// Query params: q, category, type, sort (trending|bestseller|newest|rating), page, limit
const listPrompts = asyncHandler(async (req, res) => {
  const { q, category, type, tag, featured, sort = 'newest', page = '1', limit = '12' } = req.query;

  if (type && !CONTENT_TYPES.includes(String(type))) {
    return res.status(400).json({ success: false, message: `type must be one of: ${CONTENT_TYPES.join(', ')}` });
  }

  const where = {
    ...(q && {
      OR: [
        { title: { contains: String(q), mode: 'insensitive' } },
        { description: { contains: String(q), mode: 'insensitive' } },
      ],
    }),
    ...(category && category !== 'All' && { category: String(category) }),
    ...(type && { type: String(type) }),
    ...(tag && { tags: { has: String(tag) } }),
    ...(featured === 'true' && { isFeatured: true }),
  };

  const orderBy =
    sort === 'trending' ? [{ isTrending: 'desc' }, { views: 'desc' }] :
    sort === 'bestseller' ? [{ isBestSeller: 'desc' }, { downloadCount: 'desc' }] :
    sort === 'rating' ? [{ rating: 'desc' }] :
    [{ createdAt: 'desc' }]; // newest

  const take = Math.max(Math.min(Number(limit) || 12, 50), 1);
  const skip = (Math.max(Number(page) || 1, 1) - 1) * take;

  const [items, total, categories] = await Promise.all([
    prisma.content.findMany({ where, orderBy, take, skip }),
    prisma.content.count({ where }),
    prisma.content.findMany({ select: { category: true }, distinct: ['category'] }),
  ]);

  const hasAccess = await getHasAccess(req.user?.id, req.user?.role);

  res.json({
    success: true,
    prompts: items.map((i) => decorate(i, hasAccess)),
    total,
    page: Number(page) || 1,
    totalPages: Math.max(Math.ceil(total / take), 1),
    categories: categories.map((c) => c.category),
    hasAccess,
  });
});

// @route GET /api/marketplace/trending
const getTrending = asyncHandler(async (req, res) => {
  const items = await prisma.content.findMany({
    where: { OR: [{ isTrending: true }, { isBestSeller: true }] },
    orderBy: [{ views: 'desc' }],
    take: 8,
  });
  const hasAccess = await getHasAccess(req.user?.id, req.user?.role);
  res.json({ success: true, prompts: items.map((i) => decorate(i, hasAccess)) });
});

// @route GET /api/marketplace/prompts/:id
const getPromptDetail = asyncHandler(async (req, res) => {
  const item = await prisma.content.findUnique({ where: { id: req.params.id } });
  if (!item) return res.status(404).json({ success: false, message: 'Prompt not found' });

  const hasAccess = await getHasAccess(req.user?.id, req.user?.role);

  const related = await prisma.content.findMany({
    where: { category: item.category, id: { not: item.id } },
    take: 4,
    orderBy: { views: 'desc' },
  });

  let wishlisted = false;
  let inCart = false;
  if (req.user) {
    const [w, c] = await Promise.all([
      prisma.wishlist.findUnique({ where: { userId_contentId: { userId: req.user.id, contentId: item.id } } }),
      prisma.cartItem.findUnique({ where: { userId_contentId: { userId: req.user.id, contentId: item.id } } }),
    ]);
    wishlisted = !!w;
    inCart = !!c;
  }

  res.json({
    success: true,
    prompt: decorate(item, hasAccess),
    related: related.map((r) => decorate(r, hasAccess)),
    wishlisted,
    inCart,
  });
});

module.exports = { listPrompts, getTrending, getPromptDetail, getHasAccess, decorate };
