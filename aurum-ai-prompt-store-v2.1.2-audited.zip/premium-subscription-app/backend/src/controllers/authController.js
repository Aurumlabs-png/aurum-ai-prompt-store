const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const asyncHandler = require('express-async-handler');
const { z } = require('zod');
const prisma = require('../config/db');
const { signAccessToken, sendTokenCookie } = require('../utils/jwt');
const { sendVerificationEmail, sendResetPasswordEmail } = require('../utils/email');

const signupSchema = z.object({
  name: z.string().min(2).max(80),
  email: z.string().email(),
  password: z.string().min(8, 'Password must be at least 8 characters'),
});

// @route POST /api/auth/signup
const signup = asyncHandler(async (req, res) => {
  const parsed = signupSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ success: false, message: parsed.error.errors[0].message });
  }
  const { name, email, password } = parsed.data;

  const existing = await prisma.user.findUnique({ where: { email } });
  if (existing) {
    return res.status(409).json({ success: false, message: 'Email already registered' });
  }

  const hashedPassword = await bcrypt.hash(password, 12);
  const emailVerifyToken = crypto.randomBytes(32).toString('hex');

  const user = await prisma.user.create({
    data: {
      name,
      email,
      password: hashedPassword,
      emailVerifyToken,
      emailVerifyExpiry: new Date(Date.now() + 24 * 60 * 60 * 1000),
      subscription: { create: { status: 'NONE' } },
    },
  });

  const link = `${process.env.CLIENT_URL}/verify-email?token=${emailVerifyToken}`;
  await sendVerificationEmail(email, link).catch((e) => console.error('Email send failed', e));

  const token = signAccessToken(user.id);
  sendTokenCookie(res, token);

  res.status(201).json({
    success: true,
    message: 'Account created. Please check your email to verify your account.',
    token,
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
  });
});

// @route POST /api/auth/login
const login = asyncHandler(async (req, res) => {
  const { email, password } = req.body;
  if (typeof email !== 'string' || typeof password !== 'string' || !email || !password) {
    return res.status(400).json({ success: false, message: 'Email and password are required' });
  }

  const user = await prisma.user.findUnique({ where: { email } });
  // Generic message on purpose — avoids leaking which emails exist
  if (!user || !(await bcrypt.compare(password, user.password))) {
    return res.status(401).json({ success: false, message: 'Invalid email or password' });
  }

  if (user.status === 'BANNED') {
    return res.status(403).json({ success: false, message: 'This account has been banned. Contact support for details.' });
  }
  if (user.status === 'SUSPENDED') {
    return res.status(403).json({ success: false, message: 'This account is suspended. Contact support for details.' });
  }

  const token = signAccessToken(user.id);
  sendTokenCookie(res, token);

  res.json({
    success: true,
    token,
    user: { id: user.id, name: user.name, email: user.email, role: user.role },
  });
});

// @route POST /api/auth/logout
const logout = asyncHandler(async (req, res) => {
  res.clearCookie('token');
  res.json({ success: true, message: 'Logged out' });
});

// @route GET /api/auth/verify-email?token=...
const verifyEmail = asyncHandler(async (req, res) => {
  const { token } = req.query;

  // CRITICAL: Prisma silently drops `undefined` fields from a `where`
  // clause. Without this guard, a request with no ?token= at all would
  // collapse the query to "any user with a non-expired verification
  // token" and verify whoever matched first — an authentication bypass.
  if (typeof token !== 'string' || !token) {
    return res.status(400).json({ success: false, message: 'A valid verification token is required' });
  }

  const user = await prisma.user.findFirst({
    where: { emailVerifyToken: token, emailVerifyExpiry: { gt: new Date() } },
  });

  if (!user) {
    return res.status(400).json({ success: false, message: 'Invalid or expired verification link' });
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { isEmailVerified: true, emailVerifyToken: null, emailVerifyExpiry: null },
  });

  res.json({ success: true, message: 'Email verified successfully' });
});

// @route POST /api/auth/forgot-password
const forgotPassword = asyncHandler(async (req, res) => {
  const { email } = req.body;
  if (typeof email !== 'string' || !email) {
    return res.status(400).json({ success: false, message: 'A valid email is required' });
  }

  const user = await prisma.user.findUnique({ where: { email } });

  // Always respond success — don't reveal whether the email exists
  if (!user) {
    return res.json({ success: true, message: 'If that email exists, a reset link has been sent.' });
  }

  const resetToken = crypto.randomBytes(32).toString('hex');
  await prisma.user.update({
    where: { id: user.id },
    data: { resetToken, resetTokenExpiry: new Date(Date.now() + 30 * 60 * 1000) },
  });

  const link = `${process.env.CLIENT_URL}/reset-password?token=${resetToken}`;
  await sendResetPasswordEmail(email, link).catch((e) => console.error('Email send failed', e));

  res.json({ success: true, message: 'If that email exists, a reset link has been sent.' });
});

// @route POST /api/auth/reset-password
const resetPassword = asyncHandler(async (req, res) => {
  const { token, password } = req.body;
  if (typeof token !== 'string' || !token) {
    return res.status(400).json({ success: false, message: 'A valid reset token is required' });
  }
  if (typeof password !== 'string' || password.length < 8) {
    return res.status(400).json({ success: false, message: 'Password must be at least 8 characters' });
  }

  const user = await prisma.user.findFirst({
    where: { resetToken: token, resetTokenExpiry: { gt: new Date() } },
  });
  if (!user) {
    return res.status(400).json({ success: false, message: 'Invalid or expired reset link' });
  }

  const hashedPassword = await bcrypt.hash(password, 12);
  await prisma.user.update({
    where: { id: user.id },
    data: { password: hashedPassword, resetToken: null, resetTokenExpiry: null },
  });

  res.json({ success: true, message: 'Password reset successful. You can now log in.' });
});

// @route GET /api/auth/me
const getMe = asyncHandler(async (req, res) => {
  const subscription = await prisma.subscription.findUnique({ where: { userId: req.user.id } });
  res.json({ success: true, user: req.user, subscription });
});

module.exports = { signup, login, logout, verifyEmail, forgotPassword, resetPassword, getMe };
