const asyncHandler = require('express-async-handler');
const cloudinary = require('cloudinary').v2;
const prisma = require('../config/db');

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// @route GET /api/content
// Public list — titles/thumbnails only. Locked items don't expose fileUrl
// unless the requester has an active subscription (checked below).
const listContent = asyncHandler(async (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 50, 100);
  const items = await prisma.content.findMany({ orderBy: { createdAt: 'desc' }, take: limit });

  let hasAccess = req.user?.role === 'ADMIN';
  if (req.user && !hasAccess) {
    const sub = await prisma.subscription.findUnique({ where: { userId: req.user.id } });
    hasAccess = sub?.status === 'ACTIVE' && sub.expiresAt > new Date();
  }

  const sanitized = items.map((item) => ({
    ...item,
    fileUrl: item.isPremium && !hasAccess ? null : item.fileUrl,
    locked: item.isPremium && !hasAccess,
  }));

  res.json({ success: true, content: sanitized, hasAccess });
});

const CONTENT_TYPES = ['TEXT', 'IMAGE', 'VIDEO', 'PDF', 'AUDIO'];

/** Shared by createContent/updateContent — was previously duplicated inline in both. */
function parseTags(raw) {
  if (raw === undefined) return undefined;
  return String(raw).split(',').map((t) => t.trim()).filter(Boolean);
}
const getContent = asyncHandler(async (req, res) => {
  const content = await prisma.content.update({
    where: { id: req.params.id },
    data: { views: { increment: 1 } },
  });
  res.json({ success: true, content });
});

// @route POST /api/content  (ADMIN only)
const createContent = asyncHandler(async (req, res) => {
  const { title, description, type, isPremium, category, tags, isFeatured, isTrending, isBestSeller, isVerified } = req.body;

  if (!req.file) {
    return res.status(400).json({ success: false, message: 'A file is required' });
  }
  if (!CONTENT_TYPES.includes(type)) {
    return res.status(400).json({ success: false, message: `type must be one of: ${CONTENT_TYPES.join(', ')}` });
  }

  const tagList = parseTags(tags) || [];

  // Resource type mapping for Cloudinary
  const resourceType = ['VIDEO', 'AUDIO'].includes(type) ? 'video' : type === 'PDF' ? 'raw' : 'image';

  const upload = await new Promise((resolve, reject) => {
    const stream = cloudinary.uploader.upload_stream(
      { resource_type: resourceType, folder: 'premium-content' },
      (err, result) => (err ? reject(err) : resolve(result))
    );
    stream.end(req.file.buffer);
  });

  const content = await prisma.content.create({
    data: {
      title,
      description,
      type,
      isPremium: isPremium !== 'false',
      category: category || 'General',
      tags: tagList,
      isFeatured: isFeatured === 'true',
      isTrending: isTrending === 'true',
      isBestSeller: isBestSeller === 'true',
      isVerified: isVerified === 'true',
      fileUrl: upload.secure_url,
      thumbnailUrl: resourceType === 'image' ? upload.secure_url : null,
      uploadedById: req.user.id,
    },
  });

  res.status(201).json({ success: true, content });
});

// @route PATCH /api/content/:id (ADMIN only)
const updateContent = asyncHandler(async (req, res) => {
  const { title, description, isPremium, category, tags, isFeatured, isTrending, isBestSeller, isVerified } = req.body;
  const asBool = (v) => (v === undefined ? undefined : v === 'true' || v === true);

  const content = await prisma.content.update({
    where: { id: req.params.id },
    data: {
      title,
      description,
      category,
      tags: parseTags(tags),
      isPremium: asBool(isPremium),
      isFeatured: asBool(isFeatured),
      isTrending: asBool(isTrending),
      isBestSeller: asBool(isBestSeller),
      isVerified: asBool(isVerified),
    },
  });
  res.json({ success: true, content });
});

// @route DELETE /api/content/:id (ADMIN only)
const deleteContent = asyncHandler(async (req, res) => {
  await prisma.content.delete({ where: { id: req.params.id } });
  res.json({ success: true, message: 'Content deleted' });
});

module.exports = { listContent, getContent, createContent, updateContent, deleteContent };
