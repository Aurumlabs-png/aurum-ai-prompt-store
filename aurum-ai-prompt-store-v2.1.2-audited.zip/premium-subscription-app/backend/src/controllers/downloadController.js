const asyncHandler = require('express-async-handler');
const prisma = require('../config/db');

// @route POST /api/downloads/:contentId
// Requires an active subscription (enforced by requireActiveSubscription
// middleware on the route). Logs the download event and returns the secure
// file URL — Cloudinary URLs are already signed/HTTPS; this endpoint is the
// gate that ensures only paying subscribers ever receive the real link.
const secureDownload = asyncHandler(async (req, res) => {
  const content = await prisma.content.findUnique({ where: { id: req.params.contentId } });
  if (!content) return res.status(404).json({ success: false, message: 'Prompt not found' });

  await prisma.$transaction([
    prisma.download.create({ data: { userId: req.user.id, contentId: content.id } }),
    prisma.content.update({ where: { id: content.id }, data: { downloadCount: { increment: 1 } } }),
  ]);

  res.json({ success: true, fileUrl: content.fileUrl, title: content.title });
});

// @route GET /api/downloads/history
const getDownloadHistory = asyncHandler(async (req, res) => {
  const downloads = await prisma.download.findMany({
    where: { userId: req.user.id },
    include: { content: { select: { id: true, title: true, type: true, category: true, thumbnailUrl: true } } },
    orderBy: { downloadedAt: 'desc' },
    take: 100,
  });
  res.json({ success: true, downloads });
});

module.exports = { secureDownload, getDownloadHistory };
