const asyncHandler = require('express-async-handler');
const prisma = require('../config/db');
const { getHasAccess, decorate } = require('./marketplaceController');

// @route GET /api/cart
const getCart = asyncHandler(async (req, res) => {
  const items = await prisma.cartItem.findMany({
    where: { userId: req.user.id },
    include: { content: true },
    orderBy: { createdAt: 'desc' },
  });
  const hasAccess = await getHasAccess(req.user.id, req.user.role);
  res.json({ success: true, cart: items.map((c) => decorate(c.content, hasAccess)), hasAccess });
});

// @route POST /api/cart/:contentId
const addToCart = asyncHandler(async (req, res) => {
  await prisma.cartItem.upsert({
    where: { userId_contentId: { userId: req.user.id, contentId: req.params.contentId } },
    update: {},
    create: { userId: req.user.id, contentId: req.params.contentId },
  });
  res.status(201).json({ success: true, message: 'Added to cart' });
});

// @route DELETE /api/cart/:contentId
const removeFromCart = asyncHandler(async (req, res) => {
  await prisma.cartItem.deleteMany({ where: { userId: req.user.id, contentId: req.params.contentId } });
  res.json({ success: true, message: 'Removed from cart' });
});

// @route POST /api/cart/checkout
// Access to every prompt is granted by an active subscription (not per-item
// pricing), so "checkout" verifies the subscription, logs each carted prompt
// as unlocked/downloaded for the user's history, and clears the cart. If the
// user isn't subscribed yet, we tell the frontend to route them to the
// existing Paystack subscription flow instead of charging per item.
const checkout = asyncHandler(async (req, res) => {
  const hasAccess = await getHasAccess(req.user.id, req.user.role);

  if (!hasAccess) {
    return res.status(402).json({
      success: false,
      message: 'An active subscription is required to check out your cart.',
      requiresSubscription: true,
    });
  }

  const items = await prisma.cartItem.findMany({ where: { userId: req.user.id } });

  await prisma.$transaction([
    ...items.map((item) =>
      prisma.download.create({ data: { userId: req.user.id, contentId: item.contentId } })
    ),
    ...items.map((item) =>
      prisma.content.update({ where: { id: item.contentId }, data: { downloadCount: { increment: 1 } } })
    ),
    prisma.cartItem.deleteMany({ where: { userId: req.user.id } }),
  ]);

  res.json({ success: true, message: `Unlocked ${items.length} prompt(s) from your cart.` });
});

module.exports = { getCart, addToCart, removeFromCart, checkout };
