const bcrypt = require('bcryptjs');
const asyncHandler = require('express-async-handler');
const prisma = require('../config/db');

// @route PATCH /api/users/profile
const updateProfile = asyncHandler(async (req, res) => {
  const { name, avatarUrl } = req.body;

  if (name !== undefined && (typeof name !== 'string' || name.trim().length < 2 || name.trim().length > 80)) {
    return res.status(400).json({ success: false, message: 'Name must be between 2 and 80 characters' });
  }
  if (avatarUrl !== undefined && avatarUrl !== null && typeof avatarUrl !== 'string') {
    return res.status(400).json({ success: false, message: 'avatarUrl must be a string' });
  }

  const user = await prisma.user.update({
    where: { id: req.user.id },
    data: { name: name?.trim(), avatarUrl },
    select: { id: true, name: true, email: true, avatarUrl: true, role: true },
  });
  res.json({ success: true, user });
});

// @route PATCH /api/users/password
const changePassword = asyncHandler(async (req, res) => {
  const { currentPassword, newPassword } = req.body;
  if (typeof currentPassword !== 'string' || !currentPassword) {
    return res.status(400).json({ success: false, message: 'Current password is required' });
  }
  if (typeof newPassword !== 'string' || newPassword.length < 8) {
    return res.status(400).json({ success: false, message: 'New password must be at least 8 characters' });
  }

  const user = await prisma.user.findUnique({ where: { id: req.user.id } });
  if (!(await bcrypt.compare(currentPassword, user.password))) {
    return res.status(401).json({ success: false, message: 'Current password is incorrect' });
  }

  const hashedPassword = await bcrypt.hash(newPassword, 12);
  await prisma.user.update({ where: { id: req.user.id }, data: { password: hashedPassword } });

  res.json({ success: true, message: 'Password updated' });
});

// @route PATCH /api/users/dark-mode
const toggleDarkMode = asyncHandler(async (req, res) => {
  const user = await prisma.user.update({
    where: { id: req.user.id },
    data: { darkMode: req.body.darkMode },
    select: { darkMode: true },
  });
  res.json({ success: true, darkMode: user.darkMode });
});

// @route GET /api/users/notifications
const getNotifications = asyncHandler(async (req, res) => {
  const notifications = await prisma.notification.findMany({
    where: { userId: req.user.id },
    orderBy: { createdAt: 'desc' },
    take: 50,
  });
  res.json({ success: true, notifications });
});

// @route PATCH /api/users/notifications/:id/read
const markNotificationRead = asyncHandler(async (req, res) => {
  await prisma.notification.updateMany({
    where: { id: req.params.id, userId: req.user.id },
    data: { read: true },
  });
  res.json({ success: true });
});

module.exports = { updateProfile, changePassword, toggleDarkMode, getNotifications, markNotificationRead };
