const axios = require('axios');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const asyncHandler = require('express-async-handler');
const prisma = require('../config/db');
const { sendPaymentConfirmationEmail } = require('../utils/email');
const { getSubscriptionPriceKobo, getSubscriptionDurationDays } = require('../utils/settings');

const PAYSTACK_BASE = 'https://api.paystack.co';

/** Validates a coupon code and returns { coupon, discountKobo } or throws. */
async function applyCoupon(code, baseAmountKobo) {
  if (typeof code !== 'string' || !code.trim()) {
    throw Object.assign(new Error('A valid coupon code is required'), { statusCode: 400 });
  }

  const coupon = await prisma.coupon.findUnique({ where: { code: code.trim().toUpperCase() } });

  if (!coupon || !coupon.active) {
    throw Object.assign(new Error('Invalid or inactive coupon code'), { statusCode: 400 });
  }
  if (coupon.expiresAt && coupon.expiresAt < new Date()) {
    throw Object.assign(new Error('This coupon has expired'), { statusCode: 400 });
  }
  if (coupon.usageLimit && coupon.usedCount >= coupon.usageLimit) {
    throw Object.assign(new Error('This coupon has reached its usage limit'), { statusCode: 400 });
  }

  const discountKobo =
    coupon.type === 'PERCENTAGE'
      ? Math.round(baseAmountKobo * (coupon.value / 100))
      : Math.round(coupon.value * 100); // fixed value stored in Naira

  return { coupon, discountKobo: Math.min(discountKobo, baseAmountKobo - 100) }; // never go below ₦1
}

/**
 * @route POST /api/payments/initialize
 * Starts a Paystack transaction and returns the authorization_url the
 * frontend redirects the user to. Price is resolved server-side (Settings
 * override or env default) — the client can never dictate the amount.
 * Optional { couponCode } in the body applies a discount.
 */
const initializePayment = asyncHandler(async (req, res) => {
  const basePrice = await getSubscriptionPriceKobo();
  let finalAmount = basePrice;
  let couponCode = null;
  let discountKobo = 0;

  if (req.body?.couponCode) {
    const { coupon, discountKobo: d } = await applyCoupon(req.body.couponCode, basePrice);
    finalAmount = basePrice - d;
    couponCode = coupon.code;
    discountKobo = d;
  }

  const reference = `sub_${uuidv4()}`;

  const payment = await prisma.payment.create({
    data: {
      userId: req.user.id,
      provider: 'PAYSTACK',
      reference,
      amount: finalAmount,
      currency: 'NGN',
      status: 'PENDING',
      couponCode,
      discountKobo,
    },
  });

  try {
    const response = await axios.post(
      `${PAYSTACK_BASE}/transaction/initialize`,
      {
        email: req.user.email,
        amount: finalAmount,
        reference,
        callback_url: `${process.env.CLIENT_URL}/dashboard/subscription?ref=${reference}`,
        metadata: { userId: req.user.id, purpose: 'subscription', couponCode },
      },
      { headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}` } }
    );

    res.json({
      success: true,
      authorizationUrl: response.data.data.authorization_url,
      reference,
      paymentId: payment.id,
      amount: finalAmount,
      discountKobo,
    });
  } catch (err) {
    console.error('Paystack init error:', err.response?.data || err.message);
    res.status(502).json({ success: false, message: 'Could not initialize payment. Try again.' });
  }
});

/**
 * @route GET /api/payments/verify/:reference
 * Server-side verification (also called as a fallback after redirect,
 * in addition to the webhook, since redirects can be interrupted).
 */
const verifyPayment = asyncHandler(async (req, res) => {
  const { reference } = req.params;

  // Ownership check FIRST — without this, any authenticated user could pass
  // another user's payment reference and trigger state changes on it.
  const existingPayment = await prisma.payment.findUnique({ where: { reference } });
  if (!existingPayment) {
    return res.status(404).json({ success: false, message: 'Payment not found' });
  }
  if (existingPayment.userId !== req.user.id && req.user.role !== 'ADMIN') {
    return res.status(403).json({ success: false, message: 'You do not have access to this payment' });
  }

  const response = await axios.get(`${PAYSTACK_BASE}/transaction/verify/${reference}`, {
    headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}` },
  });

  const { status, amount } = response.data.data;

  if (status !== 'success') {
    await prisma.payment.updateMany({ where: { reference }, data: { status: 'FAILED' } });
    return res.status(400).json({ success: false, message: 'Payment was not successful' });
  }

  const payment = await activateSubscriptionForPayment(reference, amount);
  res.json({ success: true, message: 'Payment verified, subscription activated', payment });
});

/**
 * @route POST /api/payments/webhook
 * Paystack webhook — the authoritative source of truth for payment status.
 * Verifies the X-Paystack-Signature HMAC before trusting the payload.
 */
const paystackWebhook = asyncHandler(async (req, res) => {
  const signature = req.headers['x-paystack-signature'];
  const expected = crypto
    .createHmac('sha512', process.env.PAYSTACK_SECRET_KEY)
    .update(req.body) // raw Buffer — see index.js express.raw() config
    .digest('hex');

  // Timing-safe comparison — a plain !== is vulnerable in principle to a
  // timing side-channel on the signature check that authorizes payment
  // activation. Buffers must be equal length before timingSafeEqual runs,
  // so a missing/malformed header is rejected outright first.
  const signatureBuffer = Buffer.from(String(signature || ''), 'hex');
  const expectedBuffer = Buffer.from(expected, 'hex');
  const isValid =
    signatureBuffer.length === expectedBuffer.length &&
    crypto.timingSafeEqual(signatureBuffer, expectedBuffer);

  if (!isValid) {
    return res.status(401).json({ success: false, message: 'Invalid webhook signature' });
  }

  const event = JSON.parse(req.body.toString());

  if (event.event === 'charge.success') {
    const { reference, amount } = event.data;
    await activateSubscriptionForPayment(reference, amount);
  }

  res.sendStatus(200);
});

/** Shared logic: mark payment SUCCESS, extend/activate subscription, email receipt. */
async function activateSubscriptionForPayment(reference, amountPaid) {
  const payment = await prisma.payment.findUnique({ where: { reference }, include: { user: true } });
  if (!payment) throw Object.assign(new Error('Payment record not found'), { statusCode: 404 });
  if (payment.status === 'SUCCESS') return payment; // idempotent — webhook + verify can both fire

  // The payment record already stores the (possibly discounted) amount that
  // was sent to Paystack at initialize time — compare against that, not the
  // undiscounted base price.
  if (amountPaid < payment.amount) {
    throw Object.assign(new Error('Amount paid does not match expected price'), { statusCode: 400 });
  }

  const durationDays = await getSubscriptionDurationDays();
  const existingSub = await prisma.subscription.findUnique({ where: { userId: payment.userId } });
  const now = new Date();
  const base = existingSub?.expiresAt && existingSub.expiresAt > now ? existingSub.expiresAt : now;
  const expiresAt = new Date(base.getTime() + durationDays * 24 * 60 * 60 * 1000);

  const ops = [
    prisma.payment.update({
      where: { reference },
      data: { status: 'SUCCESS', verifiedAt: now, receiptUrl: `/receipts/${reference}.pdf` },
    }),
    prisma.subscription.upsert({
      where: { userId: payment.userId },
      update: { status: 'ACTIVE', startedAt: existingSub?.startedAt || now, expiresAt },
      create: { userId: payment.userId, status: 'ACTIVE', startedAt: now, expiresAt },
    }),
    prisma.notification.create({
      data: {
        userId: payment.userId,
        title: 'Subscription activated',
        message: `Your premium subscription is active until ${expiresAt.toDateString()}.`,
      },
    }),
  ];

  if (payment.couponCode) {
    ops.push(prisma.coupon.updateMany({ where: { code: payment.couponCode }, data: { usedCount: { increment: 1 } } }));
  }

  const [updatedPayment] = await prisma.$transaction(ops);

  await sendPaymentConfirmationEmail(payment.user.email, {
    amount: amountPaid,
    reference,
    expiresAt,
  }).catch((e) => console.error('Receipt email failed', e));

  return updatedPayment;
}

// @route GET /api/payments/history
const getPaymentHistory = asyncHandler(async (req, res) => {
  const payments = await prisma.payment.findMany({
    where: { userId: req.user.id },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ success: true, payments });
});

// @route POST /api/payments/coupon/validate  { code }
const validateCoupon = asyncHandler(async (req, res) => {
  const basePrice = await getSubscriptionPriceKobo();
  const { discountKobo, coupon } = await applyCoupon(req.body.code, basePrice);
  res.json({
    success: true,
    discountKobo,
    finalAmountKobo: basePrice - discountKobo,
    type: coupon.type,
    value: coupon.value,
  });
});

module.exports = {
  initializePayment,
  verifyPayment,
  paystackWebhook,
  getPaymentHistory,
  validateCoupon,
  activateSubscriptionForPayment,
};
