const asyncHandler = require('express-async-handler');
const prisma = require('../config/db');

// @route GET /api/subscriptions/status
const getStatus = asyncHandler(async (req, res) => {
  let subscription = await prisma.subscription.findUnique({ where: { userId: req.user.id } });

  // Lazily expire — also run this as a daily cron (see /backend/src/jobs) for
  // subscriptions no one has an active session for.
  if (subscription?.status === 'ACTIVE' && subscription.expiresAt < new Date()) {
    subscription = await prisma.subscription.update({
      where: { userId: req.user.id },
      data: { status: 'EXPIRED' },
    });
  }

  res.json({ success: true, subscription: subscription || { status: 'NONE' } });
});

// @route POST /api/subscriptions/cancel-renewal
const cancelAutoRenew = asyncHandler(async (req, res) => {
  const subscription = await prisma.subscription.update({
    where: { userId: req.user.id },
    data: { autoRenew: false },
  });
  res.json({ success: true, subscription });
});

module.exports = { getStatus, cancelAutoRenew };
