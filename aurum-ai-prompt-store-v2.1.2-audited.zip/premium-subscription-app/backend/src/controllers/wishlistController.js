const asyncHandler = require('express-async-handler');
const prisma = require('../config/db');
const { getHasAccess, decorate } = require('./marketplaceController');

// @route GET /api/wishlist
const getWishlist = asyncHandler(async (req, res) => {
  const items = await prisma.wishlist.findMany({
    where: { userId: req.user.id },
    include: { content: true },
    orderBy: { createdAt: 'desc' },
  });
  const hasAccess = await getHasAccess(req.user.id, req.user.role);
  res.json({ success: true, wishlist: items.map((w) => decorate(w.content, hasAccess)) });
});

// @route POST /api/wishlist/:contentId
const addToWishlist = asyncHandler(async (req, res) => {
  await prisma.wishlist.upsert({
    where: { userId_contentId: { userId: req.user.id, contentId: req.params.contentId } },
    update: {},
    create: { userId: req.user.id, contentId: req.params.contentId },
  });
  res.status(201).json({ success: true, message: 'Added to wishlist' });
});

// @route DELETE /api/wishlist/:contentId
const removeFromWishlist = asyncHandler(async (req, res) => {
  await prisma.wishlist.deleteMany({ where: { userId: req.user.id, contentId: req.params.contentId } });
  res.json({ success: true, message: 'Removed from wishlist' });
});

module.exports = { getWishlist, addToWishlist, removeFromWishlist };
