const asyncHandler = require('express-async-handler');
const prisma = require('../config/db');
const { getOrCreateSettings } = require('../utils/settings');

// @route GET /api/settings  (public — used by the frontend to render branding/analytics)
const getPublicSettings = asyncHandler(async (req, res) => {
  const s = await getOrCreateSettings();
  res.json({
    success: true,
    settings: {
      appName: s.appName,
      logoUrl: s.logoUrl,
      primaryColor: s.primaryColor,
      secondaryColor: s.secondaryColor,
      seoTitle: s.seoTitle,
      seoDescription: s.seoDescription,
      contactEmail: s.contactEmail,
      contactPhone: s.contactPhone,
      socialTwitter: s.socialTwitter,
      socialInstagram: s.socialInstagram,
      socialLinkedin: s.socialLinkedin,
      paystackPublicKey: s.paystackPublicKey,
      gaId: s.gaId,
      metaPixelId: s.metaPixelId,
      tiktokPixelId: s.tiktokPixelId,
      membershipPriceKobo: s.membershipPriceKobo,
      membershipDurationDays: s.membershipDurationDays,
    },
  });
});

// @route GET /api/admin/settings  (ADMIN — includes everything)
const getAdminSettings = asyncHandler(async (req, res) => {
  const settings = await getOrCreateSettings();
  res.json({ success: true, settings });
});

// @route PATCH /api/admin/settings  (ADMIN)
// Note: no secret keys (e.g. Paystack secret key, SMTP password) are ever
// accepted here — those remain server-only via environment variables.
const updateSettings = asyncHandler(async (req, res) => {
  const allowedFields = [
    'appName', 'logoUrl', 'primaryColor', 'secondaryColor',
    'seoTitle', 'seoDescription',
    'contactEmail', 'contactPhone', 'socialTwitter', 'socialInstagram', 'socialLinkedin',
    'supportEmailFrom',
    'membershipPriceKobo', 'membershipDurationDays',
    'paystackPublicKey',
    'gaId', 'metaPixelId', 'tiktokPixelId',
  ];

  // membershipPriceKobo/membershipDurationDays feed directly into the live
  // Paystack charge amount and subscription length — validated strictly
  // since bad data here has direct payment-security consequences.
  const positiveIntFields = ['membershipPriceKobo', 'membershipDurationDays'];
  for (const key of positiveIntFields) {
    if (req.body[key] !== undefined && req.body[key] !== null) {
      const n = Number(req.body[key]);
      if (!Number.isFinite(n) || !Number.isInteger(n) || n <= 0) {
        return res.status(400).json({ success: false, message: `${key} must be a positive whole number` });
      }
    }
  }

  const data = {};
  for (const key of allowedFields) {
    if (req.body[key] !== undefined) {
      data[key] = positiveIntFields.includes(key) && req.body[key] !== null ? Number(req.body[key]) : req.body[key];
    }
  }

  await getOrCreateSettings(); // ensure row exists
  const settings = await prisma.settings.update({ where: { id: 'singleton' }, data });
  res.json({ success: true, settings });
});

module.exports = { getPublicSettings, getAdminSettings, updateSettings };
