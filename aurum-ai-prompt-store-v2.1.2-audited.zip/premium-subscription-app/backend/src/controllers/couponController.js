const asyncHandler = require('express-async-handler');
const prisma = require('../config/db');

// @route GET /api/admin/coupons
const listCoupons = asyncHandler(async (req, res) => {
  const coupons = await prisma.coupon.findMany({ orderBy: { createdAt: 'desc' } });
  res.json({ success: true, coupons });
});

// @route POST /api/admin/coupons
const createCoupon = asyncHandler(async (req, res) => {
  const { code, type, value, expiresAt, usageLimit } = req.body;

  if (!code || !type || value === undefined) {
    return res.status(400).json({ success: false, message: 'code, type, and value are required' });
  }
  if (!['PERCENTAGE', 'FIXED'].includes(type)) {
    return res.status(400).json({ success: false, message: 'type must be PERCENTAGE or FIXED' });
  }

  const numericValue = Number(value);
  if (!Number.isFinite(numericValue) || numericValue <= 0) {
    return res.status(400).json({ success: false, message: 'value must be a positive number' });
  }
  if (type === 'PERCENTAGE' && numericValue > 100) {
    return res.status(400).json({ success: false, message: 'Percentage value cannot exceed 100' });
  }

  let numericUsageLimit = null;
  if (usageLimit !== undefined && usageLimit !== null && usageLimit !== '') {
    numericUsageLimit = Number(usageLimit);
    if (!Number.isInteger(numericUsageLimit) || numericUsageLimit <= 0) {
      return res.status(400).json({ success: false, message: 'usageLimit must be a positive whole number' });
    }
  }

  const existing = await prisma.coupon.findUnique({ where: { code: code.trim().toUpperCase() } });
  if (existing) return res.status(409).json({ success: false, message: 'Coupon code already exists' });

  const coupon = await prisma.coupon.create({
    data: {
      code: code.trim().toUpperCase(),
      type,
      value: numericValue,
      expiresAt: expiresAt ? new Date(expiresAt) : null,
      usageLimit: numericUsageLimit,
    },
  });

  res.status(201).json({ success: true, coupon });
});

// @route PATCH /api/admin/coupons/:id
const updateCoupon = asyncHandler(async (req, res) => {
  const { type, value, expiresAt, usageLimit, active } = req.body;

  if (type !== undefined && !['PERCENTAGE', 'FIXED'].includes(type)) {
    return res.status(400).json({ success: false, message: 'type must be PERCENTAGE or FIXED' });
  }

  let numericValue;
  if (value !== undefined) {
    numericValue = Number(value);
    if (!Number.isFinite(numericValue) || numericValue <= 0) {
      return res.status(400).json({ success: false, message: 'value must be a positive number' });
    }
  }

  let numericUsageLimit;
  if (usageLimit !== undefined) {
    numericUsageLimit = usageLimit ? Number(usageLimit) : null;
    if (numericUsageLimit !== null && (!Number.isInteger(numericUsageLimit) || numericUsageLimit <= 0)) {
      return res.status(400).json({ success: false, message: 'usageLimit must be a positive whole number' });
    }
  }

  const coupon = await prisma.coupon.update({
    where: { id: req.params.id },
    data: {
      type,
      value: numericValue,
      expiresAt: expiresAt === undefined ? undefined : expiresAt ? new Date(expiresAt) : null,
      usageLimit: numericUsageLimit,
      active,
    },
  });
  res.json({ success: true, coupon });
});

// @route DELETE /api/admin/coupons/:id
const deleteCoupon = asyncHandler(async (req, res) => {
  await prisma.coupon.delete({ where: { id: req.params.id } });
  res.json({ success: true, message: 'Coupon deleted' });
});

module.exports = { listCoupons, createCoupon, updateCoupon, deleteCoupon };
