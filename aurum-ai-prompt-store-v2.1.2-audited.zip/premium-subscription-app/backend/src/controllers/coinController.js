const asyncHandler = require('express-async-handler');
const prisma = require('../config/db');

// @route POST /api/admin/coins/:userId/add   { amount, reason }
const addCoins = asyncHandler(async (req, res) => {
  const amount = Math.abs(Number(req.body.amount) || 0);
  if (!amount) return res.status(400).json({ success: false, message: 'Amount must be greater than 0' });

  const [user] = await prisma.$transaction([
    prisma.user.update({ where: { id: req.params.userId }, data: { coinBalance: { increment: amount } } }),
    prisma.coinTransaction.create({
      data: { userId: req.params.userId, amount, type: 'ADMIN_ADD', reason: req.body.reason || 'Admin adjustment' },
    }),
  ]);

  res.json({ success: true, coinBalance: user.coinBalance });
});

// @route POST /api/admin/coins/:userId/remove   { amount, reason }
const removeCoins = asyncHandler(async (req, res) => {
  const amount = Math.abs(Number(req.body.amount) || 0);
  if (!amount) return res.status(400).json({ success: false, message: 'Amount must be greater than 0' });

  const target = await prisma.user.findUnique({ where: { id: req.params.userId } });
  if (!target) return res.status(404).json({ success: false, message: 'User not found' });

  const deduction = Math.min(amount, target.coinBalance);

  const [user] = await prisma.$transaction([
    prisma.user.update({ where: { id: req.params.userId }, data: { coinBalance: { decrement: deduction } } }),
    prisma.coinTransaction.create({
      data: { userId: req.params.userId, amount: -deduction, type: 'ADMIN_REMOVE', reason: req.body.reason || 'Admin adjustment' },
    }),
  ]);

  res.json({ success: true, coinBalance: user.coinBalance });
});

// @route GET /api/admin/coins/history?userId=  (global if no userId)
const getCoinHistory = asyncHandler(async (req, res) => {
  const { userId } = req.query;
  const transactions = await prisma.coinTransaction.findMany({
    where: userId ? { userId: String(userId) } : undefined,
    include: { user: { select: { name: true, email: true } } },
    orderBy: { createdAt: 'desc' },
    take: 200,
  });
  res.json({ success: true, transactions });
});

// ---- Reward Rules ----

// @route GET /api/admin/coins/rules
const listRewardRules = asyncHandler(async (req, res) => {
  const rules = await prisma.rewardRule.findMany({ orderBy: { createdAt: 'desc' } });
  res.json({ success: true, rules });
});

// @route POST /api/admin/coins/rules
const createRewardRule = asyncHandler(async (req, res) => {
  const { name, trigger, coinAmount, description, active } = req.body;

  if (typeof name !== 'string' || !name.trim()) {
    return res.status(400).json({ success: false, message: 'name is required' });
  }
  if (typeof trigger !== 'string' || !trigger.trim()) {
    return res.status(400).json({ success: false, message: 'trigger is required' });
  }
  const numericAmount = Number(coinAmount);
  if (!Number.isFinite(numericAmount) || !Number.isInteger(numericAmount) || numericAmount <= 0) {
    return res.status(400).json({ success: false, message: 'coinAmount must be a positive whole number' });
  }

  const rule = await prisma.rewardRule.create({
    data: { name: name.trim(), trigger: trigger.trim(), coinAmount: numericAmount, description, active: active !== false },
  });
  res.status(201).json({ success: true, rule });
});

// @route PATCH /api/admin/coins/rules/:id
const updateRewardRule = asyncHandler(async (req, res) => {
  const { name, trigger, coinAmount, description, active } = req.body;

  if (name !== undefined && (typeof name !== 'string' || !name.trim())) {
    return res.status(400).json({ success: false, message: 'name must be a non-empty string' });
  }
  if (trigger !== undefined && (typeof trigger !== 'string' || !trigger.trim())) {
    return res.status(400).json({ success: false, message: 'trigger must be a non-empty string' });
  }

  let numericAmount;
  if (coinAmount !== undefined) {
    numericAmount = Number(coinAmount);
    if (!Number.isFinite(numericAmount) || !Number.isInteger(numericAmount) || numericAmount <= 0) {
      return res.status(400).json({ success: false, message: 'coinAmount must be a positive whole number' });
    }
  }

  const rule = await prisma.rewardRule.update({
    where: { id: req.params.id },
    data: {
      name: name?.trim(),
      trigger: trigger?.trim(),
      coinAmount: numericAmount,
      description,
      active,
    },
  });
  res.json({ success: true, rule });
});

// @route DELETE /api/admin/coins/rules/:id
const deleteRewardRule = asyncHandler(async (req, res) => {
  await prisma.rewardRule.delete({ where: { id: req.params.id } });
  res.json({ success: true, message: 'Reward rule deleted' });
});

module.exports = {
  addCoins,
  removeCoins,
  getCoinHistory,
  listRewardRules,
  createRewardRule,
  updateRewardRule,
  deleteRewardRule,
};
