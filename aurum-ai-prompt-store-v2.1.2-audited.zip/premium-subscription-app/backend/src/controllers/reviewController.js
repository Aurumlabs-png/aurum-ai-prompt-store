const asyncHandler = require('express-async-handler');
const prisma = require('../config/db');

/**
 * Recomputes Content.rating as the average of its APPROVED reviews.
 * Fixes a data-integrity bug where the review moderation flow never fed
 * back into the displayed rating, leaving it permanently at its 4.8 default
 * regardless of real review activity. Leaves the rating untouched if there
 * are no approved reviews yet, rather than resetting it to 0.
 */
async function recomputeContentRating(contentId) {
  const agg = await prisma.review.aggregate({
    where: { contentId, status: 'APPROVED' },
    _avg: { rating: true },
    _count: true,
  });

  if (agg._count > 0) {
    await prisma.content.update({
      where: { id: contentId },
      data: { rating: Math.round(agg._avg.rating * 10) / 10 }, // one decimal place
    });
  }
}

// @route POST /api/reviews/:contentId  (any authenticated user)
const createReview = asyncHandler(async (req, res) => {
  const { rating, comment } = req.body;
  const numericRating = Number(rating);
  if (!Number.isFinite(numericRating) || numericRating < 1 || numericRating > 5) {
    return res.status(400).json({ success: false, message: 'Rating must be between 1 and 5' });
  }

  const contentExists = await prisma.content.findUnique({ where: { id: req.params.contentId }, select: { id: true } });
  if (!contentExists) {
    return res.status(404).json({ success: false, message: 'Prompt not found' });
  }

  // Upsert against the (userId, contentId) unique constraint — atomic at the
  // database level, so concurrent submissions from the same user can no
  // longer create duplicate review rows (previously a find-then-write race).
  const review = await prisma.review.upsert({
    where: { userId_contentId: { userId: req.user.id, contentId: req.params.contentId } },
    update: { rating: numericRating, comment, status: 'PENDING' },
    create: { userId: req.user.id, contentId: req.params.contentId, rating: numericRating, comment, status: 'PENDING' },
  });

  res.status(201).json({ success: true, review, message: 'Review submitted for approval' });
});

// @route GET /api/reviews/:contentId  (public — approved only)
const getApprovedReviews = asyncHandler(async (req, res) => {
  const reviews = await prisma.review.findMany({
    where: { contentId: req.params.contentId, status: 'APPROVED' },
    include: { user: { select: { name: true, avatarUrl: true } } },
    orderBy: { createdAt: 'desc' },
  });
  res.json({ success: true, reviews });
});

// ---- Admin moderation ----

// @route GET /api/admin/reviews?status=PENDING|APPROVED|REJECTED
const listReviewsAdmin = asyncHandler(async (req, res) => {
  const { status } = req.query;
  const allowedStatuses = ['PENDING', 'APPROVED', 'REJECTED'];
  if (status && !allowedStatuses.includes(String(status))) {
    return res.status(400).json({ success: false, message: 'Invalid status filter' });
  }

  const reviews = await prisma.review.findMany({
    where: status ? { status: String(status) } : undefined,
    include: {
      user: { select: { name: true, email: true } },
      content: { select: { title: true } },
    },
    orderBy: { createdAt: 'desc' },
    take: 200,
  });
  res.json({ success: true, reviews });
});

// @route PATCH /api/admin/reviews/:id/approve
const approveReview = asyncHandler(async (req, res) => {
  const review = await prisma.review.update({ where: { id: req.params.id }, data: { status: 'APPROVED' } });
  await recomputeContentRating(review.contentId);
  res.json({ success: true, review });
});

// @route PATCH /api/admin/reviews/:id/reject
const rejectReview = asyncHandler(async (req, res) => {
  const review = await prisma.review.update({ where: { id: req.params.id }, data: { status: 'REJECTED' } });
  // If this review was previously APPROVED and counted toward the average,
  // recompute so the rating doesn't stay inflated by a now-rejected review.
  await recomputeContentRating(review.contentId);
  res.json({ success: true, review });
});

// @route DELETE /api/admin/reviews/:id
const deleteReview = asyncHandler(async (req, res) => {
  const review = await prisma.review.delete({ where: { id: req.params.id } });
  await recomputeContentRating(review.contentId);
  res.json({ success: true, message: 'Review deleted' });
});

module.exports = {
  createReview,
  getApprovedReviews,
  listReviewsAdmin,
  approveReview,
  rejectReview,
  deleteReview,
};
