const axios = require('axios');
const asyncHandler = require('express-async-handler');
const prisma = require('../config/db');

// @route GET /api/admin/subscribers
const getSubscribers = asyncHandler(async (req, res) => {
  const { status, q } = req.query; // optional filter: ACTIVE | EXPIRED | NONE, and search
  const allowedStatuses = ['NONE', 'ACTIVE', 'EXPIRED', 'CANCELLED'];
  if (status && !allowedStatuses.includes(String(status))) {
    return res.status(400).json({ success: false, message: 'Invalid subscription status filter' });
  }

  const users = await prisma.user.findMany({
    where: {
      role: 'USER',
      ...(status && { subscription: { status: String(status) } }),
      ...(q && {
        OR: [
          { name: { contains: String(q), mode: 'insensitive' } },
          { email: { contains: String(q), mode: 'insensitive' } },
        ],
      }),
    },
    select: {
      id: true,
      name: true,
      email: true,
      isEmailVerified: true,
      status: true,
      coinBalance: true,
      createdAt: true,
      subscription: true,
    },
    orderBy: { createdAt: 'desc' },
  });

  res.json({ success: true, subscribers: users });
});

// @route GET /api/admin/users/:id — full profile for the admin user-detail view
const getUserDetail = asyncHandler(async (req, res) => {
  const user = await prisma.user.findUnique({
    where: { id: req.params.id },
    select: {
      id: true, name: true, email: true, role: true, status: true, statusReason: true,
      isEmailVerified: true, coinBalance: true, createdAt: true, subscription: true,
    },
  });
  if (!user) return res.status(404).json({ success: false, message: 'User not found' });

  const [payments, downloads, coinTransactions] = await Promise.all([
    prisma.payment.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'desc' }, take: 50 }),
    prisma.download.findMany({
      where: { userId: user.id },
      include: { content: { select: { title: true, category: true } } },
      orderBy: { downloadedAt: 'desc' },
      take: 50,
    }),
    prisma.coinTransaction.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'desc' }, take: 50 }),
  ]);

  res.json({ success: true, user, payments, downloads, coinTransactions });
});

// @route PATCH /api/admin/users/:id/suspend   { reason }
const suspendUser = asyncHandler(async (req, res) => {
  const user = await prisma.user.update({
    where: { id: req.params.id },
    data: { status: 'SUSPENDED', statusReason: req.body.reason || 'Suspended by admin' },
  });
  res.json({ success: true, user: { id: user.id, status: user.status } });
});

// @route PATCH /api/admin/users/:id/ban   { reason }
const banUser = asyncHandler(async (req, res) => {
  const user = await prisma.user.update({
    where: { id: req.params.id },
    data: { status: 'BANNED', statusReason: req.body.reason || 'Banned by admin' },
  });
  res.json({ success: true, user: { id: user.id, status: user.status } });
});

// @route PATCH /api/admin/users/:id/reactivate
const reactivateUser = asyncHandler(async (req, res) => {
  const user = await prisma.user.update({
    where: { id: req.params.id },
    data: { status: 'ACTIVE', statusReason: null },
  });
  res.json({ success: true, user: { id: user.id, status: user.status } });
});

// @route DELETE /api/admin/users/:id
const deleteUser = asyncHandler(async (req, res) => {
  await prisma.user.delete({ where: { id: req.params.id } });
  res.json({ success: true, message: 'User removed' });
});

/**
 * Shared revenue computation used by both getRevenue and getDashboardStats
 * (previously duplicated in both, each pulling full Payment rows into memory
 * just to sum a number). The total uses a DB-level aggregate; only the two
 * columns actually needed for the monthly breakdown are selected.
 */
async function getRevenueSummary() {
  const [{ _sum, _count }, slimPayments] = await Promise.all([
    prisma.payment.aggregate({ where: { status: 'SUCCESS' }, _sum: { amount: true }, _count: true }),
    prisma.payment.findMany({ where: { status: 'SUCCESS' }, select: { amount: true, createdAt: true } }),
  ]);

  const byMonth = {};
  for (const p of slimPayments) {
    const key = p.createdAt.toISOString().slice(0, 7); // YYYY-MM
    byMonth[key] = (byMonth[key] || 0) + p.amount;
  }
  const monthly = Object.entries(byMonth).sort().map(([month, kobo]) => ({ month, naira: kobo / 100 }));

  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);
  const monthlySalesKobo = slimPayments
    .filter((p) => p.createdAt >= startOfMonth)
    .reduce((sum, p) => sum + p.amount, 0);

  return {
    totalRevenueNaira: (_sum.amount || 0) / 100,
    totalTransactions: _count,
    monthlySalesNaira: monthlySalesKobo / 100,
    monthly,
  };
}

// @route GET /api/admin/revenue
const getRevenue = asyncHandler(async (req, res) => {
  const { totalRevenueNaira, totalTransactions, monthly } = await getRevenueSummary();
  res.json({ success: true, totalRevenueNaira, totalTransactions, monthly });
});

// @route GET /api/admin/analytics
const getAnalytics = asyncHandler(async (req, res) => {
  const [totalUsers, activeSubscribers, totalContent, totalViews] = await Promise.all([
    prisma.user.count({ where: { role: 'USER' } }),
    prisma.subscription.count({ where: { status: 'ACTIVE', expiresAt: { gt: new Date() } } }),
    prisma.content.count(),
    prisma.content.aggregate({ _sum: { views: true } }),
  ]);

  res.json({
    success: true,
    analytics: {
      totalUsers,
      activeSubscribers,
      conversionRate: totalUsers ? ((activeSubscribers / totalUsers) * 100).toFixed(1) : '0.0',
      totalContent,
      totalViews: totalViews._sum.views || 0,
    },
  });
});

// @route GET /api/admin/dashboard — the full "Dashboard Home" payload
const getDashboardStats = asyncHandler(async (req, res) => {
  const [revenue, totalUsers, activeSubscribers, totalCoinsIssued, totalCoinsBalance, topPrompts, recentPayments] =
    await Promise.all([
      getRevenueSummary(),
      prisma.user.count({ where: { role: 'USER' } }),
      prisma.subscription.count({ where: { status: 'ACTIVE', expiresAt: { gt: new Date() } } }),
      prisma.coinTransaction.aggregate({ where: { type: { in: ['ADMIN_ADD', 'REWARD'] } }, _sum: { amount: true } }),
      prisma.user.aggregate({ _sum: { coinBalance: true } }),
      prisma.content.findMany({ orderBy: { downloadCount: 'desc' }, take: 5 }),
      prisma.payment.findMany({
        include: { user: { select: { name: true, email: true } } },
        orderBy: { createdAt: 'desc' },
        take: 8,
      }),
    ]);

  res.json({
    success: true,
    stats: {
      totalRevenueNaira: revenue.totalRevenueNaira,
      monthlySalesNaira: revenue.monthlySalesNaira,
      totalUsers,
      activeSubscribers,
      totalCoinsIssued: totalCoinsIssued._sum.amount || 0,
      totalCoinsOutstanding: totalCoinsBalance._sum.coinBalance || 0,
    },
    growth: revenue.monthly.slice(-6),
    topPrompts: topPrompts.map((p) => ({ id: p.id, title: p.title, category: p.category, downloadCount: p.downloadCount, rating: p.rating })),
    recentTransactions: recentPayments,
  });
});

// @route GET /api/admin/export/subscribers.csv
const exportSubscribersCsv = asyncHandler(async (req, res) => {
  const users = await prisma.user.findMany({
    where: { role: 'USER' },
    include: { subscription: true },
    orderBy: { createdAt: 'desc' },
  });

  // Prevents CSV/formula injection: user-controlled fields (name, email) are
  // set at signup with no character restrictions, so a value starting with
  // =, +, -, @, or a tab/CR would otherwise be interpreted as a formula by
  // Excel/Sheets when an admin opens the export — even inside quotes.
  // Prefixing with a single quote neutralizes this per OWASP guidance.
  const sanitizeCsvField = (value) => {
    const str = String(value);
    return /^[=+\-@\t\r]/.test(str) ? `'${str}` : str;
  };

  const header = 'Name,Email,Status,Expires At,Joined\n';
  const rows = users
    .map((u) =>
      [
        u.name,
        u.email,
        u.subscription?.status || 'NONE',
        u.subscription?.expiresAt ? u.subscription.expiresAt.toISOString() : '',
        u.createdAt.toISOString(),
      ]
        .map((v) => `"${sanitizeCsvField(v).replace(/"/g, '""')}"`)
        .join(',')
    )
    .join('\n');

  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', 'attachment; filename="subscribers.csv"');
  res.send(header + rows);
});

// @route GET /api/admin/payments
const getAllPayments = asyncHandler(async (req, res) => {
  const payments = await prisma.payment.findMany({
    include: { user: { select: { name: true, email: true } } },
    orderBy: { createdAt: 'desc' },
    take: 200,
  });
  res.json({ success: true, payments });
});

// @route POST /api/admin/payments/:id/refund   { reason }
// Attempts a real Paystack refund; falls back to a local-only refund record
// (useful in test mode, where Paystack's refund API may reject sandbox
// transactions) so the admin flow always completes and stays truthful about
// what actually happened via the `paystackRefunded` flag in the response.
const refundPayment = asyncHandler(async (req, res) => {
  const payment = await prisma.payment.findUnique({ where: { id: req.params.id } });
  if (!payment) return res.status(404).json({ success: false, message: 'Payment not found' });
  if (payment.status !== 'SUCCESS') {
    return res.status(400).json({ success: false, message: 'Only successful payments can be refunded' });
  }

  let paystackRefunded = false;
  try {
    await axios.post(
      'https://api.paystack.co/refund',
      { transaction: payment.reference },
      { headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}` } }
    );
    paystackRefunded = true;
  } catch (err) {
    console.error('Paystack refund API call failed (recording local refund only):', err.response?.data || err.message);
  }

  const updated = await prisma.payment.update({
    where: { id: payment.id },
    data: { status: 'REFUNDED', refundedAt: new Date(), refundReason: req.body.reason || 'Refunded by admin' },
  });

  // Revoke the subscription this payment funded, if still active
  await prisma.subscription.updateMany({
    where: { userId: payment.userId, status: 'ACTIVE' },
    data: { status: 'CANCELLED' },
  });

  res.json({ success: true, payment: updated, paystackRefunded });
});

module.exports = {
  getSubscribers,
  getUserDetail,
  suspendUser,
  banUser,
  reactivateUser,
  deleteUser,
  getRevenue,
  getAnalytics,
  getDashboardStats,
  exportSubscribersCsv,
  getAllPayments,
  refundPayment,
};
