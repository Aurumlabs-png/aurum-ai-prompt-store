# API Documentation

Base URL (local): `http://localhost:5000/api`

Authentication uses an httpOnly JWT cookie set on login/signup. All
authenticated requests must be made `withCredentials: true` (already
configured in `frontend/lib/api.ts`). A Bearer token is also accepted via
`Authorization: Bearer <token>` for non-browser clients.

All responses follow the shape `{ success: boolean, message?: string, ...data }`.

---

## Auth — `/api/auth`

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/signup` | — | `{ name, email, password }` → creates user, sends verification email, sets cookie |
| POST | `/login` | — | `{ email, password }` → sets cookie |
| POST | `/logout` | — | Clears auth cookie |
| GET | `/verify-email?token=` | — | Verifies email from emailed link |
| POST | `/forgot-password` | — | `{ email }` → sends reset link (always 200, no email enumeration) |
| POST | `/reset-password` | — | `{ token, password }` → sets new password |
| GET | `/me` | ✅ | Returns current `user` and `subscription` |

## Users — `/api/users` (all require auth)

| Method | Endpoint | Description |
|---|---|---|
| PATCH | `/profile` | `{ name, avatarUrl }` |
| PATCH | `/password` | `{ currentPassword, newPassword }` |
| PATCH | `/dark-mode` | `{ darkMode: boolean }` |
| GET | `/notifications` | Last 50 notifications |
| PATCH | `/notifications/:id/read` | Marks one as read |

## Subscriptions — `/api/subscriptions` (auth required)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/status` | Current subscription; lazily flips to `EXPIRED` if past `expiresAt` |
| POST | `/cancel-renewal` | Turns off auto-renew |

## Payments — `/api/payments`

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/initialize` | ✅ | Starts a Paystack transaction for the current subscription price (DB override via Website Settings, else env default). Optional `{ couponCode }` applies a discount server-side. Rate-limited. |
| GET | `/verify/:reference` | ✅ (owner or ADMIN) | Verifies a transaction server-side and activates the subscription (idempotent). Returns `403` if the reference belongs to a different user, `404` if it doesn't exist. |
| POST | `/webhook` | — (HMAC-verified, timing-safe) | Paystack calls this on `charge.success`; source of truth for activation |
| GET | `/history` | ✅ | Current user's payment records |
| POST | `/coupon/validate` | ✅ | `{ code }` — previews the discount for a coupon without charging. Rate-limited to prevent code brute-forcing. |

## Content — `/api/content`

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/?limit=` | optional | Lists content, newest first, capped at `limit` (default 50, max 100). `fileUrl` is `null` and `locked: true` for premium items if the requester lacks an active subscription |
| GET | `/:id` | ✅ + active subscription | Full content record, increments view count |
| POST | `/` | ✅ ADMIN | `multipart/form-data`: `title, description, type, category, tags, isPremium, isFeatured, isTrending, isBestSeller, isVerified, file` — uploads to Cloudinary. `type` is validated against the enum before upload. |
| PATCH | `/:id` | ✅ ADMIN | Update title/description/category/tags/isPremium/badges |
| DELETE | `/:id` | ✅ ADMIN | Remove content |

`type` is one of `TEXT | IMAGE | VIDEO | PDF | AUDIO` — validated server-side; an invalid value now returns a clean `400` instead of a raw 500.

## Marketplace — `/api/marketplace` (v2.0)

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| GET | `/prompts` | optional | `?q=&category=&type=&tag=&featured=&sort=newest\|trending\|bestseller\|rating&page=&limit=` — search, filter, sort, paginate. `type` is validated against the `ContentType` enum (`400` if invalid); `limit` is clamped to `1–50`. |
| GET | `/trending` | optional | Top trending/best-seller prompts |
| GET | `/prompts/:id` | optional | Full detail + `related` prompts + `wishlisted`/`inCart` flags for the current user |

Each prompt includes computed `badges: { trending, bestSeller, verified, featured, isNew }` — `isNew` is true for items created in the last 14 days. Locked (premium, no active subscription) items have `fileUrl: null` and `locked: true`.

## Wishlist — `/api/wishlist` (auth required)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | Current user's saved prompts |
| POST | `/:contentId` | Save a prompt |
| DELETE | `/:contentId` | Remove a saved prompt |

## Cart — `/api/cart` (auth required)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/` | Current cart contents |
| POST | `/:contentId` | Add a prompt to cart |
| DELETE | `/:contentId` | Remove from cart |
| POST | `/checkout` | Requires an active subscription (all-access model — no per-item pricing). Logs each carted prompt as unlocked and clears the cart. Returns `402` with `requiresSubscription: true` if the user isn't subscribed yet. |

## Downloads — `/api/downloads` (auth required)

| Method | Endpoint | Description |
|---|---|---|
| POST | `/:contentId` | Secure download — requires an active subscription (`requireActiveSubscription` middleware). Logs the event, increments the prompt's download count, returns the real `fileUrl`. |
| GET | `/history` | Full download / purchase history for the current user |

---

---

# v2.1 — Admin Dashboard

All endpoints below require `role: ADMIN` (via `restrictTo('ADMIN')`), mounted under `/api/admin`.

## Dashboard Home
| Method | Endpoint | Description |
|---|---|---|
| GET | `/dashboard` | Combined payload: revenue, monthly sales, active users, premium members, coin stats, top-selling prompts, recent transactions, 6-month growth series |

## User Management
| Method | Endpoint | Description |
|---|---|---|
| GET | `/subscribers?q=&status=` | Search/filter users |
| GET | `/users/:id` | Full profile: payments, downloads, coin transactions |
| PATCH | `/users/:id/suspend` `{ reason }` | Suspend (blocks login) |
| PATCH | `/users/:id/ban` `{ reason }` | Ban (blocks login) |
| PATCH | `/users/:id/reactivate` | Restore to ACTIVE |
| DELETE | `/users/:id` | Remove user |

Suspended/banned users are rejected at both `/api/auth/login` and the `protect` middleware, so an existing session is also cut off immediately.

## Coins Management
| Method | Endpoint | Description |
|---|---|---|
| POST | `/coins/:userId/add` `{ amount, reason }` | Credit coins |
| POST | `/coins/:userId/remove` `{ amount, reason }` | Debit coins (floors at 0) |
| GET | `/coins/history?userId=` | Global or per-user ledger |
| GET/POST/PATCH/DELETE | `/coins/rules` | Reward rule CRUD (trigger, coin amount, active toggle) |

## Coupons
| Method | Endpoint | Description |
|---|---|---|
| GET/POST/PATCH/DELETE | `/coupons` | CRUD — `type: PERCENTAGE\|FIXED`, `expiresAt`, `usageLimit` |

Coupons are validated and applied live in `POST /api/payments/initialize` via `{ couponCode }` — discount is computed server-side and the discounted amount is what's actually sent to Paystack.

## Reviews
| Method | Endpoint | Description |
|---|---|---|
| GET | `/reviews?status=` | List by moderation status |
| PATCH | `/reviews/:id/approve` \| `/reject` | Moderate |
| DELETE | `/reviews/:id` | Remove |

Public-facing: `GET/POST /api/reviews/:contentId` (submit + list approved reviews for a prompt).

## Website Settings
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/settings` (public) | Safe subset: branding, SEO, contact, social links, analytics IDs, Paystack public key |
| GET | `/admin/settings` | Full settings row |
| PATCH | `/admin/settings` | Update branding, SEO, contact, social, membership pricing/duration, analytics IDs, Paystack public key |

Membership price/duration set here override the `.env` defaults immediately — no redeploy needed. Secrets (Paystack secret key, SMTP password) are **never** stored in the database; they stay in server environment variables only.

## Orders & Payments
| Method | Endpoint | Description |
|---|---|---|
| GET | `/payments` | All transactions |
| POST | `/payments/:id/refund` `{ reason }` | Attempts a real Paystack refund call; falls back to a local-only refund record if the API call fails (e.g. sandbox limitations), and always cancels the associated subscription |

---

## Admin — `/api/admin` (all require ADMIN role)

| Method | Endpoint | Description |
|---|---|---|
| GET | `/subscribers?status=` | List users with subscription info, optional status filter |
| DELETE | `/users/:id` | Remove a user |
| GET | `/revenue` | Total revenue, transaction count, monthly breakdown |
| GET | `/analytics` | Total users, active subscribers, conversion rate, content count, views |
| GET | `/export/subscribers.csv` | Downloads subscriber list as CSV |
| GET | `/payments` | Last 200 payments across all users |

---

## Error format

```json
{ "success": false, "message": "Human-readable error description" }
```

Common status codes: `400` validation, `401` not authenticated, `402`
subscription required, `403` insufficient role / not the resource owner,
`404` not found, `409` conflict (e.g. duplicate email, coupon code, or a
unique-constraint violation), `429` rate limited, `500` unexpected server error.

As of the backend audit, known Prisma error codes are translated into the
status codes above instead of falling through as raw `500`s — a missing
record (`P2025`) becomes `404`, a unique-constraint violation (`P2002`)
becomes `409`, and a foreign-key violation (`P2003`, e.g. referencing
deleted content) becomes `400`. See `backend/src/middleware/errorHandler.js`.
