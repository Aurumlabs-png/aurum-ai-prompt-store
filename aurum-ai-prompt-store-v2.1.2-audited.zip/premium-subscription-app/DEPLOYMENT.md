# Deployment Guide

This guide deploys the **frontend to Vercel** and the **backend + PostgreSQL
to Railway** (Render works the same way — steps are near-identical).

---

## 1. Push to GitHub

```bash
git init
git add .
git commit -m "Initial commit — Aurum premium subscription platform"
git remote add origin <your-repo-url>
git push -u origin main
```

---

## 2. Backend + Database on Railway

1. Create a new Railway project → **Deploy from GitHub repo** → select the repo, set root directory to `/backend`.
2. Add a **PostgreSQL** plugin to the project. Railway auto-injects `DATABASE_URL`.
3. In the backend service's **Variables** tab, add everything from `backend/.env.example`:
   - `JWT_SECRET`, `JWT_REFRESH_SECRET`, `COOKIE_SECRET` — generate with `openssl rand -hex 32`
   - `CLIENT_URL` — your future Vercel URL (e.g. `https://aurum.vercel.app`)
   - `PAYSTACK_SECRET_KEY`, `PAYSTACK_PUBLIC_KEY`
   - `SMTP_*` and `EMAIL_FROM`
   - `CLOUDINARY_*`
4. Set the **Start Command** to:
   ```
   npx prisma migrate deploy && npm start
   ```
5. Deploy. Note the generated public URL, e.g. `https://aurum-backend.up.railway.app`.
6. Run the seed script once via Railway's shell (or a one-off command) to create the admin account:
   ```
   npm run seed
   ```

### Render alternative
Same steps, but: create a **PostgreSQL** instance first (copy its connection
string into `DATABASE_URL`), then a **Web Service** pointing at `/backend`
with build command `npm install && npx prisma generate` and start command
`npx prisma migrate deploy && npm start`.

---

## 3. Frontend on Vercel

1. Import the same GitHub repo into Vercel → set **root directory** to `/frontend`.
2. Framework preset: Next.js (auto-detected).
3. Environment variable:
   - `NEXT_PUBLIC_API_URL = https://aurum-backend.up.railway.app/api`
4. Deploy. Vercel gives you a URL like `https://aurum.vercel.app`.
5. Go back to Railway and update `CLIENT_URL` to this exact URL, then redeploy
   the backend (needed for CORS and email links to work correctly).

---

## 4. Paystack Webhook

In your [Paystack dashboard](https://dashboard.paystack.com) → Settings →
API Keys & Webhooks, set the webhook URL to:

```
https://aurum-backend.up.railway.app/api/payments/webhook
```

Switch from test to live keys only once you've fully tested the flow with
Paystack test cards.

---

## 5. Post-deploy checklist

- [ ] Sign up a test user, confirm the verification email arrives and works
- [ ] Complete a test payment with a Paystack test card, confirm the
      subscription activates and the receipt email arrives
- [ ] Log in as admin (seeded account), change the password immediately
- [ ] Upload one piece of each content type and confirm locked/unlocked
      states behave correctly for a non-subscribed vs subscribed user
- [ ] Set up a daily cron (Railway Cron Jobs, or Render Cron) to call
      `node src/jobs/expireSubscriptions.js` so lapsed subscriptions expire
      even for users who don't log in
- [ ] Rotate all secrets (`JWT_SECRET`, etc.) to freshly generated values —
      never reuse the placeholders from `.env.example`
- [ ] Confirm `NODE_ENV=production` is set on the backend (enables secure
      cookies and hides stack traces from error responses)

---

## Custom domains

Both Vercel and Railway support attaching custom domains under their
respective project settings — point your DNS `CNAME`/`A` records as
instructed there, then update `CLIENT_URL` and `NEXT_PUBLIC_API_URL`
to match.
