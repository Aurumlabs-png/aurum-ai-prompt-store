# Changelog

All notable changes to the Aurum AI Prompt Store project are documented here.

## [2.1.2] — Frontend QA Audit

A QA audit pass focused exclusively on frontend correctness, responsiveness,
and accessibility. No features were added and no visual redesign was
performed; every change below is a fix to existing, already-shipped UI
behavior. See `FRONTEND_AUDIT_REPORT.md` for full details, severity ratings,
and reasoning.

### Fixed — Critical
- **Mobile navigation was completely broken.** The user dashboard and admin
  panel sidebars were `hidden md:flex` with no mobile fallback of any kind —
  a logged-in user on a phone had no way to navigate, view their account, or
  log out. Added a mobile menu to both, reusing the pattern already
  established in the landing page's navbar.

### Fixed — High
- Wrapped `useSearchParams()` usage in `Suspense` boundaries on
  `reset-password`, `verify-email`, and `dashboard/subscription` —
  previously unguarded, which Next.js 14 documents as a build-breaking
  pattern.
- Added error handling to ~19 data-fetching call sites that previously had
  no `.catch()` — a failed request silently rendered as an empty state
  instead of surfacing an error to the user.

### Fixed — Medium
- Dark mode toggle now reflects the user's actual saved preference on load
  (was hardcoded to always start "off") and uses proper `role="switch"`
  semantics. Actual theme-switching was not implemented — see the audit
  report's deferred items.
- Added skeleton loading placeholders (matching the existing card style) to
  the dashboard, marketplace, and wishlist grids, replacing plain "Loading…"
  text.
- Added a 300ms debounce to marketplace search — was firing a request on
  every keystroke.
- Fixed a popup-blocker-prone `window.open()` call in the prompt download
  flow by opening the tab synchronously on click instead of after the async
  request resolves.
- Aligned the prompt detail page's wishlist/cart toggle behavior with the
  marketplace listing page's optimistic-update pattern for consistency.
- Added the missing `REFUNDED` payment status to the user payment history
  page's type and color mapping (previously silently unstyled).
- Added a "back to login" link to two previously dead-end states (password
  reset confirmation, email verification failure).
- Fixed stale root metadata (`<title>`/description still described the
  product's pre-pivot generic positioning) and removed a leftover
  emerald-green body background from before the black/gold re-theme.
- Adjusted two admin grids' tablet breakpoint so 2-column layouts activate
  at `md` instead of `lg`, better using tablet-width screens.

### Fixed — Accessibility
- Added `aria-expanded`/`aria-controls` to all collapsible menu/accordion
  triggers (mobile nav toggles, FAQ accordion).
- Added `aria-hidden="true"` to purely decorative background/floating
  elements on the landing page.
- Added `aria-pressed` to wishlist/cart toggle buttons.
- Added screen-reader-only `<label>` elements and correct `autoComplete`
  values to every auth and profile form input (previously placeholder-only).
- Added `aria-busy` to buttons during async submission.

### Documentation
- Added `FRONTEND_AUDIT_REPORT.md` — full findings, fixes, deferred items
  (with reasoning), and production-readiness assessment.
- Updated this changelog.

---

## [2.1.1] — Backend & Security Audit

A QA audit pass focused exclusively on backend correctness and security. No
features were added or redesigned; every change below is a fix to existing,
already-shipped behavior. See `AUDIT_REPORT_BACKEND.md` for full details,
severity ratings, and reasoning.

### Security
- **Fixed a critical authentication bypass** in `GET /api/auth/verify-email` —
  a request with no `token` query param could verify an arbitrary account due
  to Prisma silently dropping `undefined` filter conditions.
- **Fixed broken object-level authorization** in `GET /api/payments/verify/:reference`
  — added an ownership check so only the payment's owner (or an admin) can
  trigger verification/state changes on it.
- **Fixed CSV/formula injection** in the subscriber export — user-controlled
  `name`/`email` fields are now sanitized before being written to
  `subscribers.csv`, preventing a malicious registered user from planting a
  payload that executes when an admin opens the file in Excel/Sheets.
- Applied the same `undefined`-filter fix to `forgotPassword` and
  `resetPassword` after a full codebase sweep for the same bug pattern.
- Hardened JWT verification with an explicit algorithm allow-list (`HS256`).
- Switched the Paystack webhook signature check to a timing-safe comparison.
- Added rate limiting to `POST /api/payments/coupon/validate` to prevent
  coupon-code brute-forcing.
- Removed the unused, unmaintained `csurf` dependency and dead
  `signRefreshToken`/`JWT_REFRESH_*` code that was never wired into any flow.

### Fixed
- Added a DB-level unique constraint on `Review(userId, contentId)` and
  switched review submission to an atomic `upsert`, closing a race condition
  that could create duplicate reviews.
- `Content.rating` is now recomputed from approved reviews on
  approve/reject/delete — previously stuck at a static default regardless of
  real review activity.
- Added input validation (type/finiteness/range checks) to every endpoint
  that previously passed unvalidated numeric or enum input to Prisma,
  including: coupon `value`/`usageLimit`, membership pricing/duration
  settings (which feed directly into live Paystack charges), reward rule
  `coinAmount`, content `type`, marketplace search `type`/`limit`, profile
  `name`, and password-change `currentPassword`.
- Added a `trust proxy` setting — without it, `express-rate-limit` v7 breaks
  behind the exact reverse-proxy deployment (Railway/Render) this project's
  own deployment guide recommends.

### Changed / Refactored (no behavior change)
- Consolidated a duplicated `optionalAuth` middleware (previously copy-pasted
  in two route files) into a single shared export.
- Extracted a shared `getRevenueSummary()` helper, replacing duplicated
  monthly-revenue aggregation logic in `getRevenue` and `getDashboardStats`;
  switched to a DB-level `aggregate()` for totals instead of pulling every
  successful payment row into memory.
- Extracted a shared `parseTags()` helper, replacing duplicated tag-parsing
  logic in content create/update.
- `GET /api/admin/subscribers?status=` now filters at the database level
  instead of fetching every user and filtering in JavaScript.
- `GET /api/content` now caps results (default 50, max 100) instead of
  returning the entire table.

### Documentation
- Updated `API_DOCS.md` for all endpoint behavior changes above.
- Added `AUDIT_REPORT_BACKEND.md` — full findings, fixes, deferred items
  (with reasoning), and production-readiness assessment.
- Updated `backend/.env.example` to remove dead refresh-token variables and
  clarify that subscription price/duration can be overridden from the admin
  Website Settings panel.

---

## [2.1.0] — Professional Admin Dashboard
Dashboard Home (revenue, growth charts, top prompts), Prompt Management
(tags, Featured badge), User Management (search/suspend/ban), Coins
Management, Membership pricing, Orders & refunds, Coupons, Reviews
moderation, Analytics integration panels (GA/Meta/TikTok), Website Settings.

## [2.0.0] — Prompt Marketplace
Search/filter/sort listing, categories, trending/best-seller/verified/new
badges, prompt detail with preview, wishlist, cart, secure downloads,
download history, related prompts. Landing page redesigned to a black/gold
AI Prompt Store theme.

## [1.0.0] — Initial Release
Full-stack premium subscription platform: auth, JWT sessions, Paystack
subscription billing, admin content upload, user dashboard.
