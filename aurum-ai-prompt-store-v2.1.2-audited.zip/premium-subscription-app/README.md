# Aurum — Premium Content Subscription Platform

A production-ready, full-stack premium content platform. Users subscribe for
**₦1,000/month** to unlock a locked library of text, images, video, audio, and
PDF content. Built with Next.js, Express, PostgreSQL/Prisma, and Paystack.

![status](https://img.shields.io/badge/status-ready--to--deploy-d4af37)

---

## ✨ Features

**Users**
Sign up · Login · Forgot/reset password · Email verification · Dashboard ·
Profile management · Subscription status · Payment history · Change password ·
Dark mode · Notifications

**Admin**
Secure role-gated dashboard · Upload/edit/delete content (text, image, video,
PDF, audio) · Manage subscribers (view/remove/export CSV) · Revenue &
analytics dashboards with charts · Payment log

**Platform**
JWT auth in httpOnly cookies · Role-based access control · Bcrypt password
hashing · Rate limiting · CSRF-safe cookie config · XSS/HPP/injection
sanitization · Paystack payment integration with signed webhook verification ·
Automatic subscription activation & expiry · Email receipts and notifications

---

## 🏗 Tech Stack

| Layer      | Technology |
|------------|------------|
| Frontend   | Next.js 14 (App Router), React 18, TypeScript, Tailwind CSS, Framer Motion |
| Backend    | Node.js, Express.js |
| Database   | PostgreSQL + Prisma ORM |
| Storage    | Cloudinary (media uploads) |
| Payments   | Paystack (Flutterwave/Stripe swap-in ready — see `paymentController.js`) |
| Deployment | Vercel (frontend) + Railway/Render (backend + Postgres) |

---

## 📁 Project Structure

```
premium-subscription-app/
├── backend/
│   ├── prisma/
│   │   ├── schema.prisma      # DB models: User, Subscription, Payment, Content, Notification
│   │   └── seed.js            # creates a default admin account
│   ├── src/
│   │   ├── config/db.js       # Prisma client singleton
│   │   ├── middleware/        # auth, RBAC, rate limiting, error handling
│   │   ├── controllers/       # auth, payment, subscription, content, user, admin
│   │   ├── routes/            # REST endpoints per resource
│   │   ├── jobs/               # subscription-expiry cron
│   │   ├── utils/             # JWT + email helpers
│   │   └── index.js           # app entrypoint
│   └── .env.example
└── frontend/
    ├── app/                   # Next.js App Router pages
    │   ├── (landing) page.tsx, login, signup, forgot/reset-password, verify-email
    │   ├── dashboard/         # user area: overview, subscription, payments, profile
    │   ├── admin/             # admin area: overview, content, subscribers, revenue
    │   └── premium/[id]/      # gated content viewer
    ├── components/            # landing, dashboard, admin UI pieces
    └── lib/                   # api client, auth context, utils
```

---

## 🚀 Local Setup

### 1. Prerequisites
- Node.js 18+
- A PostgreSQL database (local, or a free instance on Railway/Neon/Supabase)
- A [Paystack](https://paystack.com) test account (free) for payment keys
- (Optional) Cloudinary account for media storage, SMTP credentials for email

### 2. Backend

```bash
cd backend
cp .env.example .env      # fill in DATABASE_URL, JWT secrets, Paystack keys, SMTP, Cloudinary
npm install
npx prisma migrate dev --name init
npm run seed               # creates admin@premiumplatform.com / ChangeMe123!
npm run dev                 # http://localhost:5000
```

### 3. Frontend

```bash
cd frontend
cp .env.local.example .env.local
npm install
npm run dev                 # http://localhost:3000
```

Visit `http://localhost:3000`, sign up as a user, or log in as the seeded
admin to upload content and view analytics.

> ⚠️ **Change the seeded admin password immediately** in a real deployment.

---

## 💳 Payments (Paystack)

1. Grab your test keys from the [Paystack dashboard](https://dashboard.paystack.com/#/settings/developer).
2. Set `PAYSTACK_SECRET_KEY` / `PAYSTACK_PUBLIC_KEY` in `backend/.env`.
3. In the Paystack dashboard, add a webhook URL pointing to:
   `https://your-backend-domain.com/api/payments/webhook`
4. Test with Paystack's test cards (e.g. `4084 0840 8408 4081`).

The webhook is the source of truth for activation; the frontend also calls
`/api/payments/verify/:reference` after redirect back from checkout as a
fallback in case the webhook is delayed.

Swapping to **Flutterwave** or **Stripe** only requires rewriting
`backend/src/controllers/paymentController.js` — the rest of the app
(subscription model, frontend flow) is provider-agnostic.

---

## 🔐 Security Notes

- Passwords hashed with bcrypt (cost factor 12)
- JWT stored in an httpOnly, sameSite cookie — not accessible to JS (XSS-safe)
- All Prisma queries are parameterized — no raw SQL string building anywhere
- `helmet`, `hpp`, `xss-clean`, `express-mongo-sanitize` on every request
- Auth and payment endpoints have stricter rate limits than the rest of the API
- Webhook payloads are verified against Paystack's HMAC-SHA512 signature
  before being trusted
- Admin routes are protected by both JWT auth and role middleware

Before going to production, also add: HTTPS everywhere (handled by
Vercel/Railway by default), a Web Application Firewall or Cloudflare in front
of the API, and a secrets manager instead of committing `.env` files.

---

## 📄 Further Docs

- [`API_DOCS.md`](./API_DOCS.md) — full REST API reference
- [`DEPLOYMENT.md`](./DEPLOYMENT.md) — step-by-step Vercel + Railway deployment
- [`AUDIT_REPORT_BACKEND.md`](./AUDIT_REPORT_BACKEND.md) — backend & security QA audit: findings, fixes, deferred items, production-readiness status
- [`FRONTEND_AUDIT_REPORT.md`](./FRONTEND_AUDIT_REPORT.md) — frontend QA audit: findings, fixes, deferred items, production-readiness status
- [`CHANGELOG.md`](./CHANGELOG.md) — version history

---

## 🧭 Roadmap Ideas

- Multi-tier plans (monthly/yearly)
- Stripe support for international cards
- Push notifications
- Content search & tagging
- Refund handling
