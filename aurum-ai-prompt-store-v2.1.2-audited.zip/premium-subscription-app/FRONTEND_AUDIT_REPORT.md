# Aurum AI Prompt Store — Frontend QA Audit Report

**Scope:** Landing page, authentication pages, user dashboard, prompt detail
page, search & filters, wishlist, cart, mobile/tablet/desktop responsiveness,
accessibility, loading/skeleton/empty/error states, toast notifications, UI
consistency, component reusability, dark mode, performance, SEO, code quality.

**Explicitly out of scope:** Backend/database/API changes (audited and fixed
in a prior pass — see `AUDIT_REPORT_BACKEND.md`). No features were added and
no visual redesign was performed — every change below is a fix to existing,
already-shipped UI behavior.

---

## 1. Problems Found & Fixed

### 🔴 Critical — Mobile Usability

| # | Issue | Fix |
|---|---|---|
| 1 | **The entire dashboard and admin panel were unnavigable on mobile.** Both `Sidebar.tsx` (user dashboard) and `AdminSidebar.tsx` were `hidden md:flex` with **no fallback of any kind** below the 768px breakpoint — no hamburger menu, no nav links, no way to see account info, and no way to log out. A logged-in user on a phone could reach `/dashboard` but had no way to navigate away from the first page they landed on except by editing the URL directly. | Added a mobile top bar + slide-down nav panel to both sidebars, using the exact pattern already established in the landing page's `Navbar.tsx` (not a new UI pattern — reusing the app's own existing mobile-menu convention). Desktop behavior (`md:flex`) is byte-for-byte unchanged. |

### 🟠 High — Build-Breaking / Systemic

| # | Issue | Fix |
|---|---|---|
| 2 | **`useSearchParams()` used without a `Suspense` boundary** in `reset-password`, `verify-email`, and `dashboard/subscription`. This is documented to fail (or force a client-only bailout on) `next build` in Next.js 14's App Router. | Isolated the `useSearchParams()` call into a small inner component wrapped in `<Suspense>` in all three pages. |
| 3 | **Silent failure on initial data load across ~19 files.** Every list/detail page fetched its data with `api.get(...).then(...).finally(...)` and **no `.catch()`** — a failed request (network error, expired session edge case, 500) silently resolved to "no data" instead of surfacing an error, misleading the user into thinking their wishlist/cart/history/etc. was genuinely empty. | Added `.catch(() => toast.error(...))` to every affected fetch across both the user dashboard and the entire admin panel. (Two secondary, non-critical background syncs — wishlist/cart ID prefetch on the marketplace listing — were given a silent `.catch(() => {})` instead of a toast, since surfacing an error for a background enhancement fetch would be noisier than useful; this still fixes the underlying unhandled-promise-rejection bug.) |

### 🟡 Medium

| # | Issue | Fix |
|---|---|---|
| 4 | **Dark mode toggle was non-functional and lied about its own state.** `tailwind.config.ts` declares `darkMode: 'class'`, but there are zero `dark:` variant classes anywhere in the codebase and the toggle never applied any class to `<html>`. On top of that, the toggle's initial state was hardcoded to `useState(false)` — it never read the user's actual saved preference, so it reset to "off" on every page load regardless of what was stored. | Fixed the state-accuracy bug: the `User` type now carries `darkMode` (the backend already returned it via `/api/auth/me`; the frontend simply wasn't consuming it), and the toggle initializes from the real saved value, with a rollback-on-failure. Added proper `role="switch"`/`aria-checked` semantics. **Did not** implement actual light/dark theming — see Deferred #1. |
| 5 | **No skeleton loaders anywhere** — every grid of content showed plain "Loading…" text. | Added a reusable `SkeletonCard`/`SkeletonGrid` component matching the existing glass-card visual language (same shape, same theme — a pulsing placeholder, not a new design), applied to the dashboard, marketplace, and wishlist grids (the three most-visited content grids). |
| 6 | **Search input had no debounce** — fired a network request on every keystroke. | Added a standard 300ms debounce; category/sort/pagination clicks remain instant. |
| 7 | **`window.open()` called after an `await` in the download flow** — many browsers' popup blockers silently block `window.open()` calls that aren't the direct synchronous result of a click, treating an async gap as disqualifying. | Open the tab synchronously on click (`window.open('', '_blank')`), then set `.location.href` once the signed download URL resolves; closes the blank tab if the request fails. |
| 8 | **Inconsistent optimistic-update UX for the same action.** The marketplace listing page updates wishlist/cart state optimistically (instant UI feedback, rollback on failure); the prompt detail page updated state only *after* the network round-trip completed for the identical action. | Aligned the detail page to the same optimistic pattern for consistency. |
| 9 | **`REFUNDED` payment status had no color mapping** on the user's payment history page — the type only declared `PENDING \| SUCCESS \| FAILED` even though the backend audit added `REFUNDED` to the enum. A refunded payment would silently render with no status styling. | Added `REFUNDED` to both the type and the color map. |
| 10 | **Dead-end error/success states with no way forward.** The forgot-password "check your inbox" success state and the verify-email "invalid or expired link" error state both had no navigation option — just static text. | Added a "Back to login" link to both. |
| 11 | **Stale `PromptCard` TypeScript type** — the component's `badges` prop type didn't declare `featured`, even though the backend has returned it since v2.1. Not a runtime bug (JS doesn't enforce this), but a genuine type-safety gap that could mask a real mismatch later. | Added `featured: boolean` to the type. |
| 12 | **Stale, pre-pivot SEO metadata.** Root layout's `<title>`/description still read "Aurum — Premium Content Platform / Exclusive premium content for subscribers" — leftover copy from before the product became the AI Prompt Store. This is the single most search/share-visible text on the whole site and didn't match the actual product. | Updated to reflect the real product positioning already used throughout the rest of the app (Hero, Navbar, etc.). |
| 13 | **Leftover emerald-green body background** (`bg-emerald-radial`) from before the black/gold re-theme — invisible in normal use since every page sets its own `bg-black`, but could flash through during iOS Safari's rubber-band overscroll or on short-content pages. Confirmed genuinely vestigial (only reference in the entire codebase besides its own Tailwind config definition). | Changed to `bg-black` to match the actual current theme. |
| 14 | **Two tablet-responsiveness gaps** — two grids (`admin` dashboard home, `admin/users/[id]`) jumped from 1 column straight to 2 columns only at the `lg` (1024px) breakpoint, leaving tablets (768–1023px) under-using available width for no reason (both were already going to show 2 columns at `lg` — no visual change at desktop, just an earlier, more appropriate breakpoint). | Changed the breakpoint to `md`. |

### 🟢 Low — Accessibility

| # | Issue | Fix |
|---|---|---|
| 15 | Mobile menu toggles (landing Navbar, both sidebars) had no `aria-expanded`/`aria-controls`, so screen reader users couldn't tell whether the menu was open. | Added both attributes consistently. |
| 16 | FAQ accordion buttons had no `aria-expanded`/`aria-controls`, same issue. | Fixed with matching `id`/`aria-controls` per panel. |
| 17 | Decorative background blur elements and floating demo cards (landing Hero, Pricing, FeaturedPrompts) had no `aria-hidden`, so screen readers would announce redundant/confusing decorative content interspersed with the real page content. | Added `aria-hidden="true"` to all purely decorative elements. |
| 18 | Wishlist/cart toggle buttons (on `PromptCard` and the prompt detail page) had no `aria-pressed`, so their on/off state wasn't communicated to assistive tech. | Added `aria-pressed` reflecting live state. |
| 19 | Every auth form (login, signup, forgot-password, reset-password) and the profile page's forms had placeholder-only inputs with no associated `<label>` and no `autoComplete` attributes — the latter breaks password manager integration for everyone, not just screen reader users. | Added `sr-only` labels (no visual change) and correct `autoComplete` values (`email`, `current-password`, `new-password`, `name`) throughout. |
| 20 | Submit buttons had no `aria-busy` during async operations. | Added `aria-busy={loading}` alongside the existing `disabled` state across all the forms touched above. |
| 21 | Footer newsletter form: icon-only submit button had no `aria-label`, and the email input had no label. | Fixed both (`aria-label` + `sr-only` label). |

---

## 2. Problems Found but Deferred (with reasoning)

1. **Dark mode has no actual light theme.** As fixed above, the toggle now
   accurately reflects and persists the user's preference, but toggling it
   still changes nothing visually — the app has exactly one theme. Building
   a real light theme means adding `dark:` variants across dozens of
   components, which is new visual design work, explicitly out of scope for
   a "do not redesign" QA pass.

2. **Coins Balance is invisible anywhere in the user-facing dashboard.**
   Verified: `/api/auth/me` does not return `coinBalance` to the requesting
   user (only admins can see a user's balance, via a separate ADMIN-only
   endpoint). This audit's scope was explicitly frontend-only, continuing
   from an already-audited, fixed backend baseline — exposing this would
   require a backend change (adding `coinBalance` to the `protect`
   middleware's user select), which is outside this pass.

3. **Hardcoded "₦1,000" pricing text** appears in the landing Hero, landing
   Pricing section, the dashboard subscription page, and the cart page, even
   though the backend (per the prior audit) supports admin-configurable
   membership pricing via Website Settings. If an admin changes the price,
   this text becomes stale. Deferred consistently with the same boundary
   reasoning as #2: fetching a live value from `/api/settings` and wiring it
   into four separate pages is a new data-flow that touches product behavior,
   not a pure UI fix, and risks scope creep into "new functionality."

4. **No favicon/app icon exists anywhere in the project.** Confirmed via a
   full search of `app/` — no `favicon.ico`, `icon.png`, or equivalent.
   Browser tabs and search results show a generic/blank icon. Not fixed
   because there is no logo asset in the repository to generate one from,
   and manufacturing a placeholder icon would mean inventing a visual asset
   rather than fixing existing UI — flagged for the team to supply a real
   brand icon.

5. **`Sidebar.tsx` and `AdminSidebar.tsx` are now substantially similar**
   (both gained near-identical mobile-menu logic in this pass, on top of
   already-similar desktop logic). A shared base component would reduce
   duplication. Not refactored in this pass — the two components have
   different link sets, different logout placements, and one has an
   `overflow-y-auto` the other doesn't; extracting a clean shared base late
   in an audit, with no remaining verification budget, carries more
   regression risk than the duplication currently costs. Flagged as a
   reasonable follow-up refactor, not attempted here.

6. **Legacy `/premium/[id]` route.** Superseded by `/marketplace/[id]` since
   the v2.0 marketplace module, but still present and directly reachable. It
   already has correct loading/error handling and now inherits the corrected
   black body background, so it isn't broken — just orphaned from navigation.
   Left in place per "do not remove existing features."

---

## 3. Verified Clean (no issues found)

- All admin/dashboard tables already wrap in `overflow-x-auto` for mobile
  horizontal scrolling — checked all 9 table-containing pages.
- No unbalanced JSX/braces/parens across any touched file (automated sweep).
- Empty states throughout (wishlist, cart, downloads, payment history,
  admin lists) already show clear, actionable messaging — no fixes needed.
- Toast notifications (via `sonner`) are already used consistently for
  action feedback (create/update/delete/approve/reject/etc.) across the
  entire admin panel and user dashboard.

## 4. Production Readiness Status

**Frontend: substantially more production-ready than before this audit.**
The mobile-navigation fix alone (#1) resolves what was effectively a
platform-breaking defect for any mobile user attempting to manage their
account or subscription. The `Suspense` fix (#2) removes a real risk of
`next build` failing outright in CI/deployment. All other fixes are
correctness/consistency/accessibility improvements with no behavior change
to existing, working flows.

**Recommended before public launch:**
1. Supply a real favicon/app icon (Deferred #4).
2. Decide whether dark mode should be fully implemented or the toggle
   removed — currently correct-but-inert, which is a reasonable interim
   state but not a final one (Deferred #1).
3. Wire dynamic membership pricing into the four pages that still hardcode
   it, if admin-configurable pricing is a feature the team intends to use
   (Deferred #3).
4. Run a Lighthouse/axe-core pass in a real browser — this audit was a
   static code review; automated tooling would catch runtime-only issues
   (actual color contrast ratios, real tab-order, etc.) that aren't visible
   from source alone.
