'use client';

import Link from 'next/link';
import { Lock, Star, Heart, ShoppingCart, TrendingUp, Award, Sparkles, FileText, Video, Music, ImageIcon, FileDown } from 'lucide-react';
import { cn } from '@/lib/utils';

export type Prompt = {
  id: string;
  title: string;
  description?: string;
  category: string;
  type: 'TEXT' | 'IMAGE' | 'VIDEO' | 'PDF' | 'AUDIO';
  rating: number;
  downloadCount: number;
  locked: boolean;
  badges: { trending: boolean; bestSeller: boolean; verified: boolean; featured: boolean; isNew: boolean };
};

const iconFor = { TEXT: FileText, IMAGE: ImageIcon, VIDEO: Video, PDF: FileDown, AUDIO: Music };

interface Props {
  prompt: Prompt;
  wishlisted?: boolean;
  inCart?: boolean;
  onToggleWishlist?: (id: string) => void;
  onToggleCart?: (id: string) => void;
}

export default function PromptCard({ prompt, wishlisted, inCart, onToggleWishlist, onToggleCart }: Props) {
  const Icon = iconFor[prompt.type];

  return (
    <div className="glass-card group relative flex flex-col border-gold-500/10">
      {/* badges */}
      <div className="absolute left-4 top-4 flex flex-wrap gap-1.5">
        {prompt.badges.bestSeller && (
          <span className="flex items-center gap-1 rounded-full bg-gold-500/90 px-2.5 py-1 text-[10px] font-semibold text-black">
            <Award className="h-3 w-3" /> Best Seller
          </span>
        )}
        {prompt.badges.trending && (
          <span className="flex items-center gap-1 rounded-full bg-rose-500/90 px-2.5 py-1 text-[10px] font-semibold text-white">
            <TrendingUp className="h-3 w-3" /> Trending
          </span>
        )}
        {prompt.badges.isNew && (
          <span className="flex items-center gap-1 rounded-full bg-emerald-500/90 px-2.5 py-1 text-[10px] font-semibold text-white">
            <Sparkles className="h-3 w-3" /> New
          </span>
        )}
      </div>

      {onToggleWishlist && (
        <button
          onClick={() => onToggleWishlist(prompt.id)}
          aria-pressed={wishlisted}
          className="absolute right-4 top-4 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-black/50 backdrop-blur-sm transition-colors hover:bg-black/70"
          aria-label="Toggle wishlist"
        >
          <Heart className={cn('h-4 w-4', wishlisted ? 'fill-rose-500 text-rose-500' : 'text-neutral-300')} />
        </button>
      )}

      <Link href={`/marketplace/${prompt.id}`} className="mt-10 flex flex-1 flex-col">
        <div className="flex items-center gap-2">
          <Icon className="h-4 w-4 text-gold-400" />
          <span className="rounded-full bg-gold-500/10 px-2.5 py-0.5 text-[11px] font-medium text-gold-400">
            {prompt.category}
          </span>
          {prompt.badges.verified && (
            <span className="flex items-center gap-1 text-[11px] text-gold-400">
              <Award className="h-3 w-3" /> Gold Verified
            </span>
          )}
        </div>

        <h3 className="mt-3 font-display text-lg font-semibold text-neutral-50 line-clamp-2">{prompt.title}</h3>
        {prompt.description && (
          <p className="mt-1 line-clamp-2 text-sm text-neutral-400">{prompt.description}</p>
        )}

        <div className="mt-4 flex items-center justify-between text-xs text-neutral-500">
          <span className="flex items-center gap-1">
            <Star className="h-3.5 w-3.5 fill-gold-500 text-gold-500" /> {prompt.rating.toFixed(1)}
          </span>
          <span>{prompt.downloadCount} unlocks</span>
        </div>
      </Link>

      <div className="mt-4 flex items-center gap-2 border-t border-white/10 pt-4">
        {prompt.locked ? (
          <Link href="/dashboard/subscription" className="btn-outline flex-1 !py-2 text-xs">
            <Lock className="h-3.5 w-3.5" /> Unlock
          </Link>
        ) : (
          <Link href={`/marketplace/${prompt.id}`} className="btn-gold flex-1 !py-2 text-xs">
            View Prompt
          </Link>
        )}
        {onToggleCart && (
          <button
            onClick={() => onToggleCart(prompt.id)}
            aria-pressed={inCart}
            className={cn(
              'flex h-9 w-9 shrink-0 items-center justify-center rounded-full border transition-colors',
              inCart ? 'border-gold-500 bg-gold-500/10 text-gold-400' : 'border-white/10 text-neutral-400 hover:border-gold-500/40'
            )}
            aria-label="Toggle cart"
          >
            <ShoppingCart className="h-4 w-4" />
          </button>
        )}
      </div>
    </div>
  );
}
