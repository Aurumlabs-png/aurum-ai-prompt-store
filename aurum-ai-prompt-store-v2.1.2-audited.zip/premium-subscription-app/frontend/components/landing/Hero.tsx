'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { Sparkles, ArrowRight, Zap, ShieldCheck, Star } from 'lucide-react';

const floatingPrompts = [
  { label: 'Midjourney — Cinematic Portraits', top: '8%', left: '2%', delay: 0 },
  { label: 'ChatGPT — Sales Copy Engine', top: '62%', left: '0%', delay: 0.4 },
  { label: 'Claude — Research Synthesizer', top: '20%', right: '0%', delay: 0.2 },
  { label: 'DALL·E — Brand Moodboards', top: '68%', right: '2%', delay: 0.6 },
];

export default function Hero() {
  return (
    <section className="relative flex min-h-screen items-center justify-center overflow-hidden bg-black px-6 pt-32">
      <div aria-hidden="true" className="pointer-events-none absolute left-1/2 top-0 h-[36rem] w-[36rem] -translate-x-1/2 rounded-full bg-gold-500/10 blur-[120px]" />
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(212,175,55,0.08),transparent_60%)]" />
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:56px_56px] [mask-image:radial-gradient(ellipse_60%_60%_at_50%_20%,black,transparent)]" />

      {floatingPrompts.map((p) => (
        <motion.div
          key={p.label}
          aria-hidden="true"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: [0, -10, 0] }}
          transition={{ opacity: { duration: 0.8, delay: p.delay }, y: { duration: 5, repeat: Infinity, delay: p.delay } }}
          style={{ top: p.top, left: p.left, right: p.right }}
          className="glass absolute hidden max-w-[220px] rounded-xl px-4 py-3 text-xs text-neutral-300 lg:block"
        >
          <span className="mb-1 flex items-center gap-1.5 text-gold-400">
            <Sparkles className="h-3 w-3" /> Featured Prompt
          </span>
          {p.label}
        </motion.div>
      ))}

      <div className="relative z-10 mx-auto max-w-3xl text-center">
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="glass mx-auto mb-8 inline-flex items-center gap-2 rounded-full border-gold-500/20 px-4 py-1.5 text-xs text-gold-400"
        >
          <Zap className="h-3.5 w-3.5" />
          500+ battle-tested prompts, updated weekly
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="font-display text-5xl font-bold leading-[1.1] text-neutral-50 md:text-7xl"
        >
          The Prompt Vault
          <span className="block text-transparent bg-clip-text bg-gold-gradient bg-[length:200%_auto] animate-shimmer">
            for Serious Creators
          </span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mx-auto mt-6 max-w-xl text-lg text-neutral-400"
        >
          Hand-crafted, tested prompts for ChatGPT, Claude, Midjourney &amp;
          more — organized by category, unlocked instantly when you subscribe.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row"
        >
          <Link href="/signup" className="btn-gold group">
            Unlock the Vault — ₦1,000/mo
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
          <a href="#prompts" className="btn-outline">
            Browse Prompts
          </a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="mt-14 flex flex-wrap items-center justify-center gap-x-8 gap-y-3 text-xs text-neutral-500"
        >
          <span className="flex items-center gap-1.5"><ShieldCheck className="h-4 w-4 text-gold-500" /> Secure Paystack checkout</span>
          <span className="flex items-center gap-1.5"><Star className="h-4 w-4 text-gold-500" /> 4.9/5 from 2,300+ members</span>
          <span className="flex items-center gap-1.5"><Sparkles className="h-4 w-4 text-gold-500" /> New drops every week</span>
        </motion.div>
      </div>
    </section>
  );
}
