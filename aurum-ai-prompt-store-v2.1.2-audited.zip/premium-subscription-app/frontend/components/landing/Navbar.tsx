'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Crown, Menu, X } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';

const navLinks = [
  { href: '#categories', label: 'Categories' },
  { href: '#prompts', label: 'Prompts' },
  { href: '#pricing', label: 'Pricing' },
  { href: '#testimonials', label: 'Reviews' },
  { href: '#faq', label: 'FAQ' },
];

export default function Navbar() {
  const { user } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <header className="fixed top-0 z-50 w-full px-4 pt-4">
      <nav
        className={`mx-auto flex max-w-6xl items-center justify-between rounded-2xl border border-gold-500/10 px-5 py-3 backdrop-blur-xl transition-all duration-300 md:px-6 ${
          scrolled ? 'bg-black/70 shadow-gold border-gold-500/20' : 'bg-black/30'
        }`}
      >
        <Link href="/" className="flex items-center gap-2">
          <Crown className="h-6 w-6 text-gold-500" />
          <span className="font-display text-xl font-bold tracking-wide text-gold-400">Aurum</span>
        </Link>

        <div className="hidden items-center gap-8 text-sm text-neutral-300 md:flex">
          {navLinks.map((l) => (
            <a key={l.href} href={l.href} className="transition-colors hover:text-gold-400">
              {l.label}
            </a>
          ))}
        </div>

        <div className="hidden items-center gap-3 md:flex">
          {user ? (
            <Link href={user.role === 'ADMIN' ? '/admin' : '/dashboard'} className="btn-gold !px-5 !py-2 text-sm">
              Dashboard
            </Link>
          ) : (
            <>
              <Link href="/login" className="text-sm text-neutral-300 transition-colors hover:text-gold-400">
                Log in
              </Link>
              <Link href="/signup" className="btn-gold !px-5 !py-2 text-sm">
                Get Started
              </Link>
            </>
          )}
        </div>

        <button
          onClick={() => setOpen((v) => !v)}
          className="text-gold-400 md:hidden"
          aria-label="Toggle menu"
          aria-expanded={open}
          aria-controls="mobile-nav-menu"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-nav-menu"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
            className="mx-auto mt-2 max-w-6xl overflow-hidden rounded-2xl border border-gold-500/10 bg-black/90 backdrop-blur-xl md:hidden"
          >
            <div className="flex flex-col gap-1 p-4">
              {navLinks.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="rounded-lg px-3 py-2.5 text-sm text-neutral-300 hover:bg-gold-500/10 hover:text-gold-400"
                >
                  {l.label}
                </a>
              ))}
              <div className="mt-2 flex flex-col gap-2 border-t border-white/10 pt-3">
                {user ? (
                  <Link href={user.role === 'ADMIN' ? '/admin' : '/dashboard'} className="btn-gold text-center text-sm">
                    Dashboard
                  </Link>
                ) : (
                  <>
                    <Link href="/login" className="btn-outline text-center text-sm">Log in</Link>
                    <Link href="/signup" className="btn-gold text-center text-sm">Get Started</Link>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
