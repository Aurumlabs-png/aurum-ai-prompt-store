'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { Check, X, Crown } from 'lucide-react';

const freeFeatures = [
  { label: 'Browse all categories', included: true },
  { label: 'Preview prompt titles & tags', included: true },
  { label: 'Full prompt text & variables', included: false },
  { label: 'Weekly new drops', included: false },
  { label: 'Download & copy prompts', included: false },
];

const proFeatures = [
  { label: 'Browse all categories', included: true },
  { label: 'Full access to 500+ prompts', included: true },
  { label: 'Full prompt text & variables', included: true },
  { label: 'Weekly new drops', included: true },
  { label: 'Download & copy prompts', included: true },
  { label: 'Priority support', included: true },
];

export default function Pricing() {
  return (
    <section id="pricing" className="relative bg-black px-6 py-24">
      <div aria-hidden="true" className="pointer-events-none absolute left-1/2 top-0 h-72 w-72 -translate-x-1/2 rounded-full bg-gold-500/10 blur-[120px]" />

      <div className="relative mx-auto max-w-5xl">
        <div className="text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-gold-500">Membership</p>
          <h2 className="section-title mt-3">Simple, honest pricing</h2>
          <p className="mx-auto mt-4 max-w-xl text-neutral-400">
            One plan. Everything unlocked. No hidden tiers.
          </p>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-6 md:grid-cols-2 md:items-center">
          {/* Free tier */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="rounded-2xl border border-white/10 bg-white/[0.02] p-8"
          >
            <p className="text-sm text-neutral-400">Free</p>
            <div className="mt-3 flex items-end gap-1">
              <span className="font-display text-4xl font-bold text-neutral-100">₦0</span>
              <span className="mb-1 text-neutral-500">/forever</span>
            </div>
            <ul className="mt-8 space-y-3 text-left text-sm">
              {freeFeatures.map((f) => (
                <li key={f.label} className="flex items-start gap-2">
                  {f.included ? (
                    <Check className="mt-0.5 h-4 w-4 shrink-0 text-neutral-400" />
                  ) : (
                    <X className="mt-0.5 h-4 w-4 shrink-0 text-neutral-600" />
                  )}
                  <span className={f.included ? 'text-neutral-300' : 'text-neutral-600 line-through'}>{f.label}</span>
                </li>
              ))}
            </ul>
            <Link href="/signup" className="btn-outline mt-8 w-full">Start free</Link>
          </motion.div>

          {/* Pro / paid tier — the real plan */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="relative overflow-hidden rounded-2xl border border-gold-500/40 bg-gradient-to-b from-gold-500/[0.08] to-transparent p-8 shadow-gold"
          >
            <div className="absolute inset-x-0 top-0 h-1 bg-gold-gradient" />
            <span className="absolute right-6 top-6 flex items-center gap-1 rounded-full bg-gold-500/15 px-3 py-1 text-[11px] font-medium text-gold-400">
              <Crown className="h-3 w-3" /> Most popular
            </span>

            <p className="text-sm text-gold-400">Aurum Pro</p>
            <div className="mt-3 flex items-end gap-1">
              <span className="font-display text-5xl font-bold text-neutral-50">₦1,000</span>
              <span className="mb-1 text-neutral-400">/month</span>
            </div>

            <ul className="mt-8 space-y-3 text-left text-sm text-neutral-200">
              {proFeatures.map((f) => (
                <li key={f.label} className="flex items-start gap-2">
                  <Check className="mt-0.5 h-4 w-4 shrink-0 text-emerald-400" />
                  {f.label}
                </li>
              ))}
            </ul>

            <Link href="/signup" className="btn-gold mt-8 w-full">Subscribe Now</Link>
            <p className="mt-3 text-center text-xs text-neutral-500">Secure checkout via Paystack · Cancel anytime</p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
