'use client';

import { motion } from 'framer-motion';
import { UserPlus, CreditCard, Unlock, Sparkles } from 'lucide-react';

const steps = [
  { icon: UserPlus, title: 'Create your account', desc: 'Sign up in under a minute — no credit card required to browse.' },
  { icon: CreditCard, title: 'Subscribe securely', desc: 'Pay ₦1,000/month via Paystack. Cancel or renew anytime.' },
  { icon: Unlock, title: 'Unlock the full vault', desc: 'Instant access to every prompt, every category, forever updated.' },
  { icon: Sparkles, title: 'Create at a higher level', desc: 'Copy, tweak, and ship — tested prompts that actually perform.' },
];

export default function Features() {
  return (
    <section className="relative bg-black px-6 py-24">
      <div className="mx-auto max-w-6xl text-center">
        <p className="text-xs uppercase tracking-[0.3em] text-gold-500">How it works</p>
        <h2 className="section-title mt-3">From sign-up to shipped, in minutes</h2>

        <div className="mt-16 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((s, i) => (
            <motion.div
              key={s.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="relative flex flex-col items-center text-center"
            >
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl border border-gold-500/20 bg-gold-500/5">
                <s.icon className="h-6 w-6 text-gold-400" />
              </div>
              <span className="mb-2 font-display text-2xl font-bold text-gold-500/40">0{i + 1}</span>
              <h3 className="font-semibold text-neutral-100">{s.title}</h3>
              <p className="mt-2 text-sm text-neutral-400">{s.desc}</p>

              {i < steps.length - 1 && (
                <div className="absolute right-[-1rem] top-7 hidden h-px w-8 bg-gradient-to-r from-gold-500/30 to-transparent lg:block" />
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
