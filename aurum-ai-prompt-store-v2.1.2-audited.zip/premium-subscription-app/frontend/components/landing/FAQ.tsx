'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown } from 'lucide-react';

const faqs = [
  { q: 'What exactly am I getting for ₦1,000?', a: 'Full access to every prompt in the vault — 500+ and growing — across all categories, updated weekly, for as long as your subscription stays active.' },
  { q: 'Can I cancel anytime?', a: 'Yes. There\'s no lock-in contract. You can stop auto-renewal from your dashboard at any time and keep access until your current period ends.' },
  { q: 'Which AI tools are the prompts for?', a: 'ChatGPT, Claude, Midjourney, DALL·E, and general-purpose prompts that work across most large language models.' },
  { q: 'How do I pay?', a: 'Payments are processed securely through Paystack. We never see or store your card details.' },
  { q: 'Do you add new prompts regularly?', a: 'Yes — new prompts are added weekly across all categories, and active subscribers get notified when fresh drops land.' },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative bg-black px-6 py-24">
      <div className="mx-auto max-w-3xl">
        <div className="text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-gold-500">Questions</p>
          <h2 className="section-title mt-3">Frequently asked</h2>
        </div>

        <div className="mt-12 space-y-3">
          {faqs.map((f, i) => (
            <div key={f.q} className="overflow-hidden rounded-2xl border border-white/10 bg-white/[0.02]">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="flex w-full items-center justify-between px-5 py-4 text-left"
                aria-expanded={open === i}
                aria-controls={`faq-panel-${i}`}
              >
                <span className="text-sm font-medium text-neutral-100">{f.q}</span>
                <ChevronDown className={`h-4 w-4 shrink-0 text-gold-400 transition-transform ${open === i ? 'rotate-180' : ''}`} />
              </button>
              <AnimatePresence>
                {open === i && (
                  <motion.div
                    id={`faq-panel-${i}`}
                    role="region"
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.25 }}
                  >
                    <p className="px-5 pb-4 text-sm leading-relaxed text-neutral-400">{f.a}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
