'use client';

import { motion } from 'framer-motion';
import { PenTool, Code2, Palette, Briefcase, GraduationCap, Megaphone } from 'lucide-react';

const categories = [
  { icon: Megaphone, name: 'Marketing & Copywriting', count: 120 },
  { icon: Code2, name: 'Coding & Development', count: 95 },
  { icon: Palette, name: 'Art & Midjourney', count: 140 },
  { icon: Briefcase, name: 'Business & Strategy', count: 80 },
  { icon: PenTool, name: 'Writing & Content', count: 110 },
  { icon: GraduationCap, name: 'Education & Research', count: 65 },
];

export default function Categories() {
  return (
    <section id="categories" className="relative bg-black px-6 py-24">
      <div className="mx-auto max-w-6xl">
        <div className="text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-gold-500">Browse by category</p>
          <h2 className="section-title mt-3">Prompts for every craft</h2>
          <p className="mx-auto mt-4 max-w-xl text-neutral-400">
            Six curated categories, hundreds of prompts, one subscription.
          </p>
        </div>

        <div className="mt-14 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          {categories.map((c, i) => (
            <motion.div
              key={c.name}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.06 }}
              className="group flex flex-col items-center rounded-2xl border border-gold-500/10 bg-white/[0.02] p-5 text-center transition-all duration-300 hover:-translate-y-1 hover:border-gold-500/40 hover:bg-gold-500/5"
            >
              <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-xl bg-gold-500/10 transition-colors group-hover:bg-gold-500/20">
                <c.icon className="h-5 w-5 text-gold-400" />
              </div>
              <p className="text-sm font-medium text-neutral-200">{c.name}</p>
              <p className="mt-1 text-xs text-neutral-500">{c.count} prompts</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
