'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { Lock, Star, ArrowRight } from 'lucide-react';

const prompts = [
  {
    title: 'The Perfect Cold Email',
    category: 'Marketing',
    rating: 4.9,
    preview: 'Write a cold outreach email that opens with a pattern-interrupt hook, references [prospect pain point]...',
  },
  {
    title: 'Cinematic Character Portrait',
    category: 'Midjourney',
    rating: 5.0,
    preview: 'Ultra-detailed cinematic portrait, dramatic rim lighting, 85mm lens, shot on film, subject: [description]...',
  },
  {
    title: 'Full-Stack Code Reviewer',
    category: 'Development',
    rating: 4.8,
    preview: 'Act as a senior staff engineer reviewing this pull request for security, performance, and readability...',
  },
  {
    title: 'Investor Pitch Refiner',
    category: 'Business',
    rating: 4.9,
    preview: 'Rewrite this pitch deck narrative to lead with traction, sharpen the ask, and address investor objections...',
  },
  {
    title: 'SEO Blog Architect',
    category: 'Writing',
    rating: 4.7,
    preview: 'Plan a 2,000-word SEO-optimized article targeting [keyword] with a scroll-stopping intro and structured H2s...',
  },
  {
    title: 'Research Paper Synthesizer',
    category: 'Education',
    rating: 4.9,
    preview: 'Summarize these three research papers into a single literature review, highlighting contradictions...',
  },
];

export default function FeaturedPrompts() {
  return (
    <section id="prompts" className="relative bg-black px-6 py-24">
      <div aria-hidden="true" className="pointer-events-none absolute left-1/2 top-1/2 h-96 w-96 -translate-x-1/2 -translate-y-1/2 rounded-full bg-gold-500/5 blur-[140px]" />

      <div className="relative mx-auto max-w-6xl">
        <div className="text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-gold-500">Members-only vault</p>
          <h2 className="section-title mt-3">Featured prompts</h2>
          <p className="mx-auto mt-4 max-w-xl text-neutral-400">
            A preview of what's inside. Subscribe to unlock the full prompt, variables, and usage notes.
          </p>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {prompts.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.08 }}
              className="glass-card relative flex flex-col overflow-hidden border-gold-500/10"
            >
              <div className="flex items-start justify-between">
                <span className="rounded-full bg-gold-500/10 px-3 py-1 text-[11px] font-medium text-gold-400">
                  {p.category}
                </span>
                <span className="flex items-center gap-1 text-xs text-neutral-400">
                  <Star className="h-3.5 w-3.5 fill-gold-500 text-gold-500" /> {p.rating}
                </span>
              </div>

              <h3 className="mt-4 font-display text-lg font-semibold text-neutral-50">{p.title}</h3>

              {/* blurred preview — glassmorphism lock effect */}
              <div className="relative mt-3 flex-1 overflow-hidden rounded-xl">
                <p className="select-none text-sm leading-relaxed text-neutral-400 blur-[3px]">{p.preview}</p>
                <div className="absolute inset-0 flex items-end justify-center bg-gradient-to-t from-black/80 via-black/20 to-transparent pb-2">
                  <span className="flex items-center gap-1.5 rounded-full border border-gold-500/30 bg-black/60 px-3 py-1 text-[11px] text-gold-400 backdrop-blur-sm">
                    <Lock className="h-3 w-3" /> Unlock with membership
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link href="/signup" className="btn-gold group inline-flex">
            See all 500+ prompts
            <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
          </Link>
        </div>
      </div>
    </section>
  );
}
