'use client';

import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Amaka O.',
    role: 'Freelance Copywriter',
    quote: 'The marketing prompts alone paid for a year of membership in one client project. Genuinely the best ₦1,000 I spend monthly.',
  },
  {
    name: 'David K.',
    role: 'Indie Game Artist',
    quote: 'The Midjourney prompt library changed how fast I can concept characters. New drops every week keep it fresh.',
  },
  {
    name: 'Priya S.',
    role: 'Startup Founder',
    quote: 'Our whole team uses the business & strategy prompts for investor updates. Clean, well-organized, no fluff.',
  },
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="relative bg-black px-6 py-24">
      <div className="mx-auto max-w-6xl">
        <div className="text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-gold-500">Loved by creators</p>
          <h2 className="section-title mt-3">What members are saying</h2>
        </div>

        <div className="mt-14 grid grid-cols-1 gap-6 md:grid-cols-3">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="glass-card border-gold-500/10 text-left"
            >
              <Quote className="h-6 w-6 text-gold-500/40" />
              <p className="mt-4 text-sm leading-relaxed text-neutral-300">&ldquo;{t.quote}&rdquo;</p>
              <div className="mt-6 flex items-center justify-between border-t border-white/10 pt-4">
                <div>
                  <p className="text-sm font-semibold text-neutral-100">{t.name}</p>
                  <p className="text-xs text-neutral-500">{t.role}</p>
                </div>
                <div className="flex gap-0.5">
                  {Array.from({ length: 5 }).map((_, idx) => (
                    <Star key={idx} className="h-3.5 w-3.5 fill-gold-500 text-gold-500" />
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
