'use client';

import Link from 'next/link';
import { Crown, Twitter, Instagram, Linkedin, Mail } from 'lucide-react';
import { useState } from 'react';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  return (
    <footer className="relative border-t border-white/10 bg-black px-6 pt-16">
      <div className="mx-auto max-w-6xl">
        <div className="grid grid-cols-1 gap-10 pb-12 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2">
              <Crown className="h-6 w-6 text-gold-500" />
              <span className="font-display text-xl font-bold text-gold-400">Aurum</span>
            </div>
            <p className="mt-4 max-w-xs text-sm text-neutral-400">
              The premium prompt vault for creators, marketers, developers, and
              founders who want AI output that actually performs.
            </p>
            <form
              onSubmit={(e) => { e.preventDefault(); setSubscribed(true); }}
              className="mt-6 flex max-w-sm gap-2"
            >
              <label htmlFor="footer-newsletter-email" className="sr-only">Email address</label>
              <input
                id="footer-newsletter-email"
                required
                type="email"
                placeholder="you@email.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="input-field !py-2 text-sm"
              />
              <button type="submit" aria-label="Subscribe to newsletter" className="btn-gold !px-4 !py-2 text-sm whitespace-nowrap">
                <Mail className="h-4 w-4" />
              </button>
            </form>
            {subscribed && <p className="mt-2 text-xs text-emerald-400">Thanks — you're on the list.</p>}
          </div>

          <div>
            <p className="text-sm font-semibold text-neutral-200">Product</p>
            <ul className="mt-4 space-y-2 text-sm text-neutral-400">
              <li><a href="#categories" className="hover:text-gold-400">Categories</a></li>
              <li><a href="#prompts" className="hover:text-gold-400">Prompts</a></li>
              <li><a href="#pricing" className="hover:text-gold-400">Pricing</a></li>
              <li><a href="#faq" className="hover:text-gold-400">FAQ</a></li>
            </ul>
          </div>

          <div>
            <p className="text-sm font-semibold text-neutral-200">Company</p>
            <ul className="mt-4 space-y-2 text-sm text-neutral-400">
              <li><Link href="/login" className="hover:text-gold-400">Log in</Link></li>
              <li><Link href="/signup" className="hover:text-gold-400">Sign up</Link></li>
              <li><a href="#" className="hover:text-gold-400">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-gold-400">Terms of Service</a></li>
            </ul>
          </div>
        </div>

        <div className="flex flex-col items-center justify-between gap-4 border-t border-white/10 py-6 text-xs text-neutral-500 sm:flex-row">
          <p>&copy; {new Date().getFullYear()} Aurum. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <a href="#" aria-label="Twitter" className="hover:text-gold-400"><Twitter className="h-4 w-4" /></a>
            <a href="#" aria-label="Instagram" className="hover:text-gold-400"><Instagram className="h-4 w-4" /></a>
            <a href="#" aria-label="LinkedIn" className="hover:text-gold-400"><Linkedin className="h-4 w-4" /></a>
          </div>
        </div>
      </div>
    </footer>
  );
}
