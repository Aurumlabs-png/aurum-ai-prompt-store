'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Crown, LayoutDashboard, Upload, Users, DollarSign, LogOut,
  Coins, CreditCard, Tag, Star, BarChart3, Settings as SettingsIcon, Menu, X,
} from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { cn } from '@/lib/utils';

const links = [
  { href: '/admin', label: 'Dashboard Home', icon: LayoutDashboard },
  { href: '/admin/content', label: 'Prompt Management', icon: Upload },
  { href: '/admin/users', label: 'User Management', icon: Users },
  { href: '/admin/coins', label: 'Coins Management', icon: Coins },
  { href: '/admin/membership', label: 'Membership', icon: CreditCard },
  { href: '/admin/orders', label: 'Orders & Payments', icon: DollarSign },
  { href: '/admin/coupons', label: 'Coupons', icon: Tag },
  { href: '/admin/reviews', label: 'Reviews', icon: Star },
  { href: '/admin/marketing-analytics', label: 'Analytics', icon: BarChart3 },
  { href: '/admin/settings', label: 'Website Settings', icon: SettingsIcon },
];

export default function AdminSidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  const doLogout = async () => { await logout(); router.push('/'); };
  const isActive = (href: string) => pathname === href || (href !== '/admin' && pathname.startsWith(href));

  const navLinks = (
    <nav className="flex-1 space-y-1">
      {links.map((l) => (
        <Link
          key={l.href}
          href={l.href}
          onClick={() => setOpen(false)}
          className={cn(
            'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors',
            isActive(l.href) ? 'bg-gold-500/10 text-gold-400' : 'text-neutral-400 hover:bg-white/5 hover:text-neutral-200'
          )}
        >
          <l.icon className="h-4 w-4 shrink-0" />
          {l.label}
        </Link>
      ))}
    </nav>
  );

  return (
    <>
      {/* Desktop sidebar — unchanged from before */}
      <aside className="glass fixed inset-y-0 left-0 z-40 hidden w-64 flex-col overflow-y-auto p-6 md:flex">
        <Link href="/" className="mb-2 flex items-center gap-2">
          <Crown className="h-6 w-6 text-gold-500" />
          <span className="font-display text-xl font-bold text-gold-500">Aurum</span>
        </Link>
        <p className="mb-8 text-xs uppercase tracking-widest text-neutral-500">Admin Panel</p>

        {navLinks}

        <div className="border-t border-white/10 pt-4">
          <p className="truncate text-sm text-neutral-300">{user?.name}</p>
          <button
            onClick={doLogout}
            className="mt-4 flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm text-neutral-400 hover:bg-white/5 hover:text-red-400"
          >
            <LogOut className="h-4 w-4" /> Log out
          </button>
        </div>
      </aside>

      {/* Mobile top bar — same fix as the user dashboard Sidebar: the admin
          panel was previously completely unnavigable below the md breakpoint. */}
      <header className="glass fixed inset-x-0 top-0 z-40 flex items-center justify-between px-4 py-3 md:hidden">
        <Link href="/admin" className="flex items-center gap-2">
          <Crown className="h-5 w-5 text-gold-500" />
          <span className="font-display text-lg font-bold text-gold-500">Aurum Admin</span>
        </Link>
        <button
          onClick={() => setOpen((v) => !v)}
          className="text-gold-400"
          aria-label="Toggle navigation menu"
          aria-expanded={open}
          aria-controls="mobile-admin-nav"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-admin-nav"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
            className="glass fixed inset-x-0 top-[57px] z-40 max-h-[calc(100vh-57px)] overflow-y-auto md:hidden"
          >
            <div className="flex flex-col gap-1 p-4">
              {navLinks}
              <div className="mt-2 border-t border-white/10 pt-3">
                <p className="truncate px-3 text-sm text-neutral-300">{user?.name}</p>
                <button
                  onClick={doLogout}
                  className="mt-2 flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm text-neutral-400 hover:bg-white/5 hover:text-red-400"
                >
                  <LogOut className="h-4 w-4" /> Log out
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
