/**
 * Pulsing placeholder shaped like a real glass-card content tile. Used
 * wherever a grid of prompt/content cards is loading, so the layout doesn't
 * jump once real content arrives and the wait doesn't read as a blank page.
 */
export function SkeletonCard() {
  return (
    <div className="glass-card animate-pulse">
      <div className="h-6 w-6 rounded bg-white/10" />
      <div className="mt-3 h-4 w-3/4 rounded bg-white/10" />
      <div className="mt-2 h-3 w-full rounded bg-white/5" />
      <div className="mt-1 h-3 w-2/3 rounded bg-white/5" />
    </div>
  );
}

export function SkeletonGrid({ count = 6 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3" role="status" aria-label="Loading content">
      {Array.from({ length: count }).map((_, i) => (
        <SkeletonCard key={i} />
      ))}
    </div>
  );
}
