'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Crown, LayoutDashboard, CreditCard, User, LogOut, Receipt, Store, Heart, ShoppingCart, DownloadCloud, Menu, X } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { cn } from '@/lib/utils';

const links = [
  { href: '/dashboard', label: 'Overview', icon: LayoutDashboard },
  { href: '/marketplace', label: 'Marketplace', icon: Store },
  { href: '/dashboard/wishlist', label: 'Wishlist', icon: Heart },
  { href: '/dashboard/cart', label: 'Cart', icon: ShoppingCart },
  { href: '/dashboard/downloads', label: 'Downloads', icon: DownloadCloud },
  { href: '/dashboard/subscription', label: 'Subscription', icon: CreditCard },
  { href: '/dashboard/payment-history', label: 'Payment History', icon: Receipt },
  { href: '/dashboard/profile', label: 'Profile', icon: User },
];

export default function Sidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  const doLogout = async () => { await logout(); router.push('/'); };

  const navLinks = (
    <nav className="flex-1 space-y-1">
      {links.map((l) => {
        const active = pathname === l.href;
        return (
          <Link
            key={l.href}
            href={l.href}
            onClick={() => setOpen(false)}
            className={cn(
              'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm transition-colors',
              active ? 'bg-gold-500/10 text-gold-400' : 'text-neutral-400 hover:bg-white/5 hover:text-neutral-200'
            )}
          >
            <l.icon className="h-4 w-4" />
            {l.label}
          </Link>
        );
      })}
    </nav>
  );

  return (
    <>
      {/* Desktop sidebar — unchanged from before */}
      <aside className="glass fixed inset-y-0 left-0 z-40 hidden w-64 flex-col p-6 md:flex">
        <Link href="/" className="mb-10 flex items-center gap-2">
          <Crown className="h-6 w-6 text-gold-500" />
          <span className="font-display text-xl font-bold text-gold-500">Aurum</span>
        </Link>

        {navLinks}

        <div className="border-t border-white/10 pt-4">
          <p className="truncate text-sm text-neutral-300">{user?.name}</p>
          <p className="truncate text-xs text-neutral-500">{user?.email}</p>
          <button
            onClick={doLogout}
            className="mt-4 flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm text-neutral-400 hover:bg-white/5 hover:text-red-400"
          >
            <LogOut className="h-4 w-4" /> Log out
          </button>
        </div>
      </aside>

      {/* Mobile top bar — the dashboard was previously unnavigable on mobile,
          since the sidebar above is hidden below the md breakpoint with no
          fallback. Mirrors the landing page Navbar's mobile menu pattern. */}
      <header className="glass fixed inset-x-0 top-0 z-40 flex items-center justify-between px-4 py-3 md:hidden">
        <Link href="/dashboard" className="flex items-center gap-2">
          <Crown className="h-5 w-5 text-gold-500" />
          <span className="font-display text-lg font-bold text-gold-500">Aurum</span>
        </Link>
        <button
          onClick={() => setOpen((v) => !v)}
          className="text-gold-400"
          aria-label="Toggle navigation menu"
          aria-expanded={open}
          aria-controls="mobile-dashboard-nav"
        >
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-dashboard-nav"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.25 }}
            className="glass fixed inset-x-0 top-[57px] z-40 overflow-hidden md:hidden"
          >
            <div className="flex flex-col gap-1 p-4">
              {navLinks}
              <div className="mt-2 border-t border-white/10 pt-3">
                <p className="truncate px-3 text-sm text-neutral-300">{user?.name}</p>
                <p className="truncate px-3 text-xs text-neutral-500">{user?.email}</p>
                <button
                  onClick={doLogout}
                  className="mt-2 flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm text-neutral-400 hover:bg-white/5 hover:text-red-400"
                >
                  <LogOut className="h-4 w-4" /> Log out
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
