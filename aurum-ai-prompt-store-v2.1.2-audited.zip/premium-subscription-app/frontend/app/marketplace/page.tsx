'use client';

import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import { Search, SlidersHorizontal, Crown, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth-context';
import PromptCard, { Prompt } from '@/components/marketplace/PromptCard';
import { SkeletonGrid } from '@/components/ui/Skeleton';

const sorts = [
  { value: 'newest', label: 'Newest' },
  { value: 'trending', label: 'Trending' },
  { value: 'bestseller', label: 'Best Sellers' },
  { value: 'rating', label: 'Top Rated' },
];

export default function MarketplacePage() {
  const { user } = useAuth();
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [q, setQ] = useState('');
  const [debouncedQ, setDebouncedQ] = useState('');
  const [category, setCategory] = useState('All');
  const [sort, setSort] = useState('newest');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [cartIds, setCartIds] = useState<Set<string>>(new Set());
  const [wishlistIds, setWishlistIds] = useState<Set<string>>(new Set());

  // Debounce free-text search so typing doesn't fire a request per keystroke
  // — category/sort/page changes below are discrete clicks and stay instant.
  useEffect(() => {
    const t = setTimeout(() => setDebouncedQ(q), 300);
    return () => clearTimeout(t);
  }, [q]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await api.get('/marketplace/prompts', {
        params: { q: debouncedQ || undefined, category, sort, page, limit: 9 },
      });
      setPrompts(data.prompts);
      setCategories(['All', ...data.categories]);
      setTotalPages(data.totalPages);
    } catch {
      toast.error('Could not load prompts');
    } finally {
      setLoading(false);
    }
  }, [debouncedQ, category, sort, page]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    if (!user) return;
    api.get('/wishlist').then(({ data }) => setWishlistIds(new Set(data.wishlist.map((w: Prompt) => w.id)))).catch(() => {});
    api.get('/cart').then(({ data }) => setCartIds(new Set(data.cart.map((c: Prompt) => c.id)))).catch(() => {});
  }, [user]);

  const toggleWishlist = async (id: string) => {
    if (!user) return toast.error('Log in to save prompts to your wishlist');
    const isSaved = wishlistIds.has(id);
    setWishlistIds((prev) => {
      const next = new Set(prev);
      isSaved ? next.delete(id) : next.add(id);
      return next;
    });
    try {
      isSaved ? await api.delete(`/wishlist/${id}`) : await api.post(`/wishlist/${id}`);
    } catch {
      toast.error('Something went wrong');
    }
  };

  const toggleCart = async (id: string) => {
    if (!user) return toast.error('Log in to add prompts to your cart');
    const isIn = cartIds.has(id);
    setCartIds((prev) => {
      const next = new Set(prev);
      isIn ? next.delete(id) : next.add(id);
      return next;
    });
    try {
      isIn ? await api.delete(`/cart/${id}`) : await api.post(`/cart/${id}`);
      toast.success(isIn ? 'Removed from cart' : 'Added to cart');
    } catch {
      toast.error('Something went wrong');
    }
  };

  return (
    <main className="min-h-screen bg-black px-6 pb-20 pt-28">
      <div className="mx-auto max-w-6xl">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Crown className="h-6 w-6 text-gold-500" />
            <span className="font-display text-xl font-bold text-gold-400">Aurum</span>
          </Link>
          {user ? (
            <div className="flex items-center gap-3 text-sm">
              <Link href="/dashboard/wishlist" className="text-neutral-400 hover:text-gold-400">Wishlist</Link>
              <Link href="/dashboard/cart" className="text-neutral-400 hover:text-gold-400">Cart</Link>
              <Link href="/dashboard" className="btn-gold !px-4 !py-2 text-xs">Dashboard</Link>
            </div>
          ) : (
            <Link href="/login" className="btn-gold !px-4 !py-2 text-xs">Log in</Link>
          )}
        </div>

        <div className="mt-10 text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-gold-500">The vault</p>
          <h1 className="section-title mt-3">Prompt Marketplace</h1>
          <p className="mx-auto mt-3 max-w-xl text-neutral-400">Search, filter, and unlock premium prompts across every category.</p>
        </div>

        {/* search + sort */}
        <div className="mt-10 flex flex-col gap-3 sm:flex-row">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-500" />
            <input
              value={q}
              onChange={(e) => { setPage(1); setQ(e.target.value); }}
              placeholder="Search prompts, e.g. 'cold email', 'portrait'..."
              className="input-field !pl-11"
            />
          </div>
          <div className="relative">
            <SlidersHorizontal className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-500" />
            <select
              value={sort}
              onChange={(e) => { setPage(1); setSort(e.target.value); }}
              className="input-field w-full !pl-10 sm:w-48"
            >
              {sorts.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
            </select>
          </div>
        </div>

        {/* category filters */}
        <div className="mt-4 flex flex-wrap gap-2">
          {categories.map((c) => (
            <button
              key={c}
              onClick={() => { setPage(1); setCategory(c); }}
              className={`rounded-full border px-4 py-1.5 text-xs transition-colors ${
                category === c
                  ? 'border-gold-500 bg-gold-500/10 text-gold-400'
                  : 'border-white/10 text-neutral-400 hover:border-gold-500/30'
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        {/* grid */}
        <div className="mt-10">
          {loading ? (
            <SkeletonGrid count={6} />
          ) : prompts.length === 0 ? (
            <p className="py-20 text-center text-neutral-500">No prompts match your search.</p>
          ) : (
            <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {prompts.map((p) => (
                <PromptCard
                  key={p.id}
                  prompt={p}
                  wishlisted={wishlistIds.has(p.id)}
                  inCart={cartIds.has(p.id)}
                  onToggleWishlist={toggleWishlist}
                  onToggleCart={toggleCart}
                />
              ))}
            </div>
          )}
        </div>

        {totalPages > 1 && (
          <nav aria-label="Marketplace pagination" className="mt-10 flex items-center justify-center gap-2">
            {Array.from({ length: totalPages }).map((_, i) => (
              <button
                key={i}
                onClick={() => setPage(i + 1)}
                aria-label={`Page ${i + 1}`}
                aria-current={page === i + 1 ? 'page' : undefined}
                className={`h-9 w-9 rounded-full text-sm ${page === i + 1 ? 'bg-gold-gradient text-black font-semibold' : 'text-neutral-400 hover:bg-white/5'}`}
              >
                {i + 1}
              </button>
            ))}
          </nav>
        )}
      </div>
    </main>
  );
}
