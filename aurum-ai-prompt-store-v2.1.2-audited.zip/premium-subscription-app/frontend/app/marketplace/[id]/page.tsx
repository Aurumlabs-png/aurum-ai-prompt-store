'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Lock, Star, Heart, ShoppingCart, DownloadCloud, Award, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth-context';
import PromptCard, { Prompt } from '@/components/marketplace/PromptCard';

type Detail = Prompt & { fileUrl: string | null; views: number };

export default function PromptDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { user } = useAuth();
  const [prompt, setPrompt] = useState<Detail | null>(null);
  const [related, setRelated] = useState<Prompt[]>([]);
  const [wishlisted, setWishlisted] = useState(false);
  const [inCart, setInCart] = useState(false);
  const [loading, setLoading] = useState(true);
  const [downloading, setDownloading] = useState(false);

  const load = () => {
    setLoading(true);
    api
      .get(`/marketplace/prompts/${id}`)
      .then(({ data }) => {
        setPrompt(data.prompt);
        setRelated(data.related);
        setWishlisted(data.wishlisted);
        setInCart(data.inCart);
      })
      .catch(() => toast.error('Could not load this prompt'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [id]);

  const toggleWishlist = async () => {
    if (!user) return toast.error('Log in to save this prompt');
    const next = !wishlisted;
    setWishlisted(next); // optimistic — consistent with the marketplace listing page's pattern
    try {
      next ? await api.post(`/wishlist/${id}`) : await api.delete(`/wishlist/${id}`);
    } catch {
      setWishlisted(!next);
      toast.error('Something went wrong');
    }
  };

  const toggleCart = async () => {
    if (!user) return toast.error('Log in to add this prompt to your cart');
    const next = !inCart;
    setInCart(next);
    try {
      next ? await api.post(`/cart/${id}`) : await api.delete(`/cart/${id}`);
      toast.success(next ? 'Added to cart' : 'Removed from cart');
    } catch {
      setInCart(!next);
      toast.error('Something went wrong');
    }
  };

  const download = async () => {
    if (!user) return toast.error('Log in to download this prompt');
    setDownloading(true);
    // Open the tab synchronously on the click, before the await — many
    // browsers' popup blockers silently block window.open() calls made
    // after an async gap, treating them as not directly user-initiated.
    const newTab = window.open('', '_blank');
    try {
      const { data } = await api.post(`/downloads/${id}`);
      if (newTab) newTab.location.href = data.fileUrl;
      toast.success('Download unlocked');
    } catch (err: any) {
      newTab?.close();
      toast.error(err.response?.data?.message || 'Subscribe to download this prompt');
    } finally {
      setDownloading(false);
    }
  };

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center bg-black"><Loader2 className="h-6 w-6 animate-spin text-gold-400" /></div>;
  }
  if (!prompt) {
    return <div className="flex min-h-screen items-center justify-center bg-black text-neutral-400">Prompt not found.</div>;
  }

  return (
    <main className="min-h-screen bg-black px-6 pb-20 pt-28">
      <div className="mx-auto max-w-4xl">
        <Link href="/marketplace" className="mb-6 inline-flex items-center gap-2 text-sm text-neutral-400 hover:text-gold-400">
          <ArrowLeft className="h-4 w-4" /> Back to marketplace
        </Link>

        <div className="glass-card border-gold-500/10">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full bg-gold-500/10 px-3 py-1 text-xs font-medium text-gold-400">{prompt.category}</span>
            {prompt.badges.verified && (
              <span className="flex items-center gap-1 text-xs text-gold-400"><Award className="h-3.5 w-3.5" /> Gold Verified</span>
            )}
            {prompt.badges.bestSeller && <span className="rounded-full bg-gold-500/90 px-2.5 py-1 text-[10px] font-semibold text-black">Best Seller</span>}
            {prompt.badges.trending && <span className="rounded-full bg-rose-500/90 px-2.5 py-1 text-[10px] font-semibold text-white">Trending</span>}
            {prompt.badges.isNew && <span className="rounded-full bg-emerald-500/90 px-2.5 py-1 text-[10px] font-semibold text-white">New</span>}
          </div>

          <h1 className="mt-4 font-display text-3xl font-bold text-neutral-50">{prompt.title}</h1>
          <p className="mt-2 text-neutral-400">{prompt.description}</p>

          <div className="mt-4 flex items-center gap-4 text-sm text-neutral-500">
            <span className="flex items-center gap-1"><Star className="h-4 w-4 fill-gold-500 text-gold-500" /> {prompt.rating.toFixed(1)}</span>
            <span>{prompt.downloadCount} unlocks</span>
            <span>{prompt.views} views</span>
          </div>

          {/* preview / full content */}
          <div className="relative mt-8 overflow-hidden rounded-xl border border-white/10 bg-white/[0.02] p-6">
            {prompt.locked ? (
              <>
                <p className="select-none text-sm leading-relaxed text-neutral-400 blur-[3px]">
                  This is a preview of the full prompt text, variables, and usage notes. Subscribe to reveal the
                  complete, ready-to-use version with all customizable fields and example outputs...
                </p>
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-black/70 backdrop-blur-sm">
                  <Lock className="h-6 w-6 text-gold-400" />
                  <p className="text-sm text-neutral-300">Subscribe to unlock the full prompt</p>
                  <Link href="/dashboard/subscription" className="btn-gold !px-5 !py-2 text-sm">Unlock — ₦1,000/mo</Link>
                </div>
              </>
            ) : (
              <p className="text-sm leading-relaxed text-neutral-200">
                Full prompt content is available via secure download below. Click "Secure Download" to fetch the file.
              </p>
            )}
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            {prompt.locked ? (
              <Link href="/dashboard/subscription" className="btn-gold"><Lock className="h-4 w-4" /> Unlock Prompt</Link>
            ) : (
              <button onClick={download} disabled={downloading} className="btn-gold">
                {downloading ? <Loader2 className="h-4 w-4 animate-spin" /> : <DownloadCloud className="h-4 w-4" />}
                Secure Download
              </button>
            )}
            <button onClick={toggleWishlist} aria-pressed={wishlisted} className="btn-outline">
              <Heart className={wishlisted ? 'h-4 w-4 fill-rose-500 text-rose-500' : 'h-4 w-4'} />
              {wishlisted ? 'Saved' : 'Save to Wishlist'}
            </button>
            <button onClick={toggleCart} aria-pressed={inCart} className="btn-outline">
              <ShoppingCart className="h-4 w-4" /> {inCart ? 'In Cart' : 'Add to Cart'}
            </button>
          </div>
        </div>

        {related.length > 0 && (
          <div className="mt-14">
            <h2 className="font-display text-xl font-semibold text-neutral-100">Related prompts</h2>
            <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
              {related.map((r) => <PromptCard key={r.id} prompt={r} />)}
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
