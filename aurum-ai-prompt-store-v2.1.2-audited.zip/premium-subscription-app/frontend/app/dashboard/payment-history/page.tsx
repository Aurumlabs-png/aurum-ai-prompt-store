'use client';

import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

type Payment = {
  id: string;
  reference: string;
  amount: number;
  status: 'PENDING' | 'SUCCESS' | 'FAILED' | 'REFUNDED';
  createdAt: string;
};

const statusColor = { SUCCESS: 'text-emerald-400', PENDING: 'text-gold-400', FAILED: 'text-red-400', REFUNDED: 'text-neutral-400' };

export default function PaymentHistoryPage() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/payments/history').then(({ data }) => setPayments(data.payments)).catch(() => toast.error('Could not load payment history')).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-neutral-50">Payment History</h1>

      <div className="glass-card mt-6 overflow-x-auto">
        {loading ? (
          <p className="text-neutral-500">Loading…</p>
        ) : payments.length === 0 ? (
          <p className="text-neutral-500">No payments yet.</p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-white/10 text-neutral-400">
                <th className="pb-3">Reference</th>
                <th className="pb-3">Amount</th>
                <th className="pb-3">Status</th>
                <th className="pb-3">Date</th>
              </tr>
            </thead>
            <tbody>
              {payments.map((p) => (
                <tr key={p.id} className="border-b border-white/5 text-neutral-200">
                  <td className="py-3 font-mono text-xs">{p.reference}</td>
                  <td className="py-3">₦{(p.amount / 100).toLocaleString()}</td>
                  <td className={`py-3 font-medium ${statusColor[p.status]}`}>{p.status}</td>
                  <td className="py-3 text-neutral-400">{new Date(p.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
