'use client';

import { Loader2 } from 'lucide-react';
import Sidebar from '@/components/dashboard/Sidebar';
import { useAuth } from '@/lib/auth-context';

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { loading } = useAuth();

  // Prevents a flash of "NONE"/empty state on every dashboard page while the
  // initial /auth/me call is still in flight — previously each page rendered
  // immediately with subscription/user still null, then popped to the real
  // values once the request resolved.
  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-gold-400" />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Sidebar />
      <main className="pt-20 md:pl-64 md:pt-0">
        <div className="mx-auto max-w-5xl px-6 py-10">{children}</div>
      </main>
    </div>
  );
}
