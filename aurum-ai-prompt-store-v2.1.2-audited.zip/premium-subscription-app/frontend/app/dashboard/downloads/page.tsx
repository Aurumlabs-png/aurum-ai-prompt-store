'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { DownloadCloud } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

type DownloadRecord = {
  id: string;
  downloadedAt: string;
  content: { id: string; title: string; type: string; category: string };
};

export default function DownloadHistoryPage() {
  const [downloads, setDownloads] = useState<DownloadRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/downloads/history').then(({ data }) => setDownloads(data.downloads)).catch(() => toast.error('Could not load download history')).finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-neutral-50">Download History</h1>
      <p className="mt-1 text-neutral-400">Every prompt you've unlocked and downloaded — your purchase history.</p>

      <div className="glass-card mt-8 overflow-x-auto">
        {loading ? (
          <p className="text-neutral-500">Loading…</p>
        ) : downloads.length === 0 ? (
          <p className="text-neutral-500">No downloads yet. Unlock a prompt from the marketplace to see it here.</p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-white/10 text-neutral-400">
                <th className="pb-3">Prompt</th>
                <th className="pb-3">Category</th>
                <th className="pb-3">Type</th>
                <th className="pb-3">Downloaded</th>
                <th className="pb-3"></th>
              </tr>
            </thead>
            <tbody>
              {downloads.map((d) => (
                <tr key={d.id} className="border-b border-white/5 text-neutral-200">
                  <td className="flex items-center gap-2 py-3">
                    <DownloadCloud className="h-4 w-4 text-gold-400" /> {d.content.title}
                  </td>
                  <td className="py-3 text-neutral-400">{d.content.category}</td>
                  <td className="py-3 text-neutral-400">{d.content.type}</td>
                  <td className="py-3 text-neutral-400">{new Date(d.downloadedAt).toLocaleString()}</td>
                  <td className="py-3">
                    <Link href={`/marketplace/${d.content.id}`} className="text-gold-400 hover:underline">View</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
