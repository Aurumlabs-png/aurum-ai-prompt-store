'use client';

import { useState } from 'react';
import { Loader2, Moon, Sun } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth-context';

export default function ProfilePage() {
  const { user, refresh } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [savingProfile, setSavingProfile] = useState(false);

  const [pwForm, setPwForm] = useState({ currentPassword: '', newPassword: '' });
  const [savingPw, setSavingPw] = useState(false);

  // Initialized from the user's actual saved preference (returned by
  // /api/auth/me) instead of always starting at `false` regardless of what
  // was previously saved — the dashboard layout now blocks rendering until
  // auth has resolved, so `user` is guaranteed to be populated here.
  const [darkMode, setDarkMode] = useState(user?.darkMode ?? false);

  const saveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingProfile(true);
    try {
      await api.patch('/users/profile', { name });
      await refresh();
      toast.success('Profile updated');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally {
      setSavingProfile(false);
    }
  };

  const savePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingPw(true);
    try {
      await api.patch('/users/password', pwForm);
      toast.success('Password changed');
      setPwForm({ currentPassword: '', newPassword: '' });
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Password change failed');
    } finally {
      setSavingPw(false);
    }
  };

  const toggleDarkMode = async () => {
    const next = !darkMode;
    setDarkMode(next);
    try {
      await api.patch('/users/dark-mode', { darkMode: next });
    } catch {
      toast.error('Could not save preference');
      setDarkMode(!next); // revert on failure so the switch doesn't lie about what's actually saved
    }
  };

  return (
    <div className="space-y-8">
      <h1 className="font-display text-3xl font-bold text-neutral-50">Profile</h1>

      <form onSubmit={saveProfile} className="glass-card space-y-4">
        <h2 className="font-semibold text-neutral-100">Basic information</h2>
        <label htmlFor="profile-name" className="sr-only">Full name</label>
        <input
          id="profile-name"
          name="name"
          autoComplete="name"
          className="input-field"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Full name"
        />
        <label htmlFor="profile-email" className="sr-only">Email address</label>
        <input id="profile-email" className="input-field opacity-60" value={user?.email} disabled />
        <button disabled={savingProfile} aria-busy={savingProfile} className="btn-gold">
          {savingProfile && <Loader2 className="h-4 w-4 animate-spin" />}
          Save changes
        </button>
      </form>

      <form onSubmit={savePassword} className="glass-card space-y-4">
        <h2 className="font-semibold text-neutral-100">Change password</h2>
        <label htmlFor="current-password" className="sr-only">Current password</label>
        <input
          id="current-password"
          name="current-password"
          type="password"
          required
          autoComplete="current-password"
          placeholder="Current password"
          className="input-field"
          value={pwForm.currentPassword}
          onChange={(e) => setPwForm({ ...pwForm, currentPassword: e.target.value })}
        />
        <label htmlFor="new-password" className="sr-only">New password</label>
        <input
          id="new-password"
          name="new-password"
          type="password"
          required
          minLength={8}
          autoComplete="new-password"
          placeholder="New password"
          className="input-field"
          value={pwForm.newPassword}
          onChange={(e) => setPwForm({ ...pwForm, newPassword: e.target.value })}
        />
        <button disabled={savingPw} aria-busy={savingPw} className="btn-gold">
          {savingPw && <Loader2 className="h-4 w-4 animate-spin" />}
          Update password
        </button>
      </form>

      <div className="glass-card flex items-center justify-between">
        <div className="flex items-center gap-3">
          {darkMode ? <Moon className="h-5 w-5 text-gold-400" /> : <Sun className="h-5 w-5 text-gold-400" />}
          <div>
            <p className="font-semibold text-neutral-100">Dark mode</p>
            <p className="text-xs text-neutral-500">Aurum is dark-themed by default across the app.</p>
          </div>
        </div>
        <button
          onClick={toggleDarkMode}
          role="switch"
          aria-checked={darkMode}
          aria-label="Toggle dark mode"
          className={`h-6 w-11 rounded-full transition-colors ${darkMode ? 'bg-gold-500' : 'bg-white/10'}`}
        >
          <span className={`block h-5 w-5 translate-y-0.5 rounded-full bg-white transition-transform ${darkMode ? 'translate-x-5' : 'translate-x-0.5'}`} />
        </button>
      </div>
    </div>
  );
}
