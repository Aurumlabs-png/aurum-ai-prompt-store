'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Lock, PlayCircle, FileText, Music, ImageIcon, FileDown, Store, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth-context';
import { SkeletonGrid } from '@/components/ui/Skeleton';

type ContentItem = {
  id: string;
  title: string;
  description?: string;
  type: 'TEXT' | 'IMAGE' | 'VIDEO' | 'PDF' | 'AUDIO';
  thumbnailUrl?: string;
  locked: boolean;
};

const iconFor = {
  TEXT: FileText,
  IMAGE: ImageIcon,
  VIDEO: PlayCircle,
  PDF: FileDown,
  AUDIO: Music,
};

export default function DashboardHome() {
  const { user, subscription } = useAuth();
  const [content, setContent] = useState<ContentItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/content').then(({ data }) => setContent(data.content)).catch(() => toast.error('Could not load content')).finally(() => setLoading(false));
  }, []);

  const isActive = subscription?.status === 'ACTIVE';

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-neutral-50">Welcome back, {user?.name?.split(' ')[0]}</h1>

      {!isActive && (
        <div className="glass-card mt-6 flex items-center justify-between border-gold-500/30">
          <div>
            <p className="font-semibold text-gold-400">You don't have an active subscription</p>
            <p className="text-sm text-neutral-400">Subscribe for ₦1,000 to unlock all premium content.</p>
          </div>
          <Link href="/dashboard/subscription" className="btn-gold !px-5 !py-2 text-sm whitespace-nowrap">
            Subscribe
          </Link>
        </div>
      )}

      <div className="mt-10 mb-4 flex items-center justify-between">
        <h2 className="font-display text-xl font-semibold text-neutral-100">Recent Prompts</h2>
        <Link href="/marketplace" className="flex items-center gap-1.5 text-sm text-gold-400 hover:underline">
          <Store className="h-4 w-4" /> Browse full marketplace <ArrowRight className="h-3.5 w-3.5" />
        </Link>
      </div>

      {loading ? (
        <SkeletonGrid count={3} />
      ) : content.length === 0 ? (
        <p className="text-neutral-500">No content has been uploaded yet.</p>
      ) : (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {content.map((item) => {
            const Icon = iconFor[item.type];
            return (
              <Link
                key={item.id}
                href={item.locked ? '/dashboard/subscription' : `/marketplace/${item.id}`}
                className="glass-card relative flex flex-col"
              >
                {item.locked && (
                  <span className="absolute right-4 top-4 flex h-8 w-8 items-center justify-center rounded-full bg-black/40">
                    <Lock className="h-4 w-4 text-gold-400" />
                  </span>
                )}
                <Icon className="h-6 w-6 text-gold-400" />
                <h3 className="mt-3 font-semibold text-neutral-100">{item.title}</h3>
                {item.description && <p className="mt-1 line-clamp-2 text-sm text-neutral-400">{item.description}</p>}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
