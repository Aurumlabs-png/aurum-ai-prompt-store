'use client';

import { Suspense, useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import { CheckCircle2, Loader2, ShieldCheck } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth-context';

function PaymentRefVerifier({ onVerified }: { onVerified: () => void }) {
  const searchParams = useSearchParams();
  const [verifying, setVerifying] = useState(false);

  // If Paystack redirected back with a reference, verify it automatically.
  useEffect(() => {
    const ref = searchParams.get('ref');
    if (!ref) return;
    setVerifying(true);
    api
      .get(`/payments/verify/${ref}`)
      .then(async () => {
        toast.success('Payment verified — subscription activated!');
        onVerified();
      })
      .catch((err) => toast.error(err.response?.data?.message || 'Verification failed'))
      .finally(() => setVerifying(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  if (!verifying) return null;
  return (
    <div role="status" className="glass-card mt-6 flex items-center gap-3 text-neutral-300">
      <Loader2 className="h-4 w-4 animate-spin text-gold-400" /> Verifying your payment…
    </div>
  );
}

export default function SubscriptionPage() {
  const { subscription, refresh } = useAuth();
  const [loading, setLoading] = useState(false);

  const handleSubscribe = async () => {
    setLoading(true);
    try {
      const { data } = await api.post('/payments/initialize');
      window.location.href = data.authorizationUrl; // redirect to Paystack checkout
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Could not start payment');
      setLoading(false);
    }
  };

  const isActive = subscription?.status === 'ACTIVE';

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-neutral-50">Subscription</h1>

      <Suspense fallback={null}>
        <PaymentRefVerifier onVerified={refresh} />
      </Suspense>

      <div className="glass-card mt-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-neutral-400">Current status</p>
            <p className={`mt-1 text-xl font-semibold ${isActive ? 'text-emerald-400' : 'text-gold-400'}`}>
              {subscription?.status || 'NONE'}
            </p>
          </div>
          {isActive && <CheckCircle2 className="h-8 w-8 text-emerald-400" />}
        </div>

        {isActive && subscription?.expiresAt && (
          <p className="mt-4 text-sm text-neutral-400">
            Renews / expires on <b className="text-neutral-200">{new Date(subscription.expiresAt).toDateString()}</b>
          </p>
        )}

        <div className="mt-6 flex items-center gap-2 text-xs text-neutral-500">
          <ShieldCheck className="h-4 w-4 text-emerald-400" />
          Payments are processed securely by Paystack. We never store your card details.
        </div>

        <button onClick={handleSubscribe} disabled={loading} aria-busy={loading} className="btn-gold mt-6 w-full">
          {loading && <Loader2 className="h-4 w-4 animate-spin" />}
          {isActive ? 'Renew Subscription — ₦1,000' : 'Subscribe Now — ₦1,000'}
        </button>
      </div>
    </div>
  );
}
