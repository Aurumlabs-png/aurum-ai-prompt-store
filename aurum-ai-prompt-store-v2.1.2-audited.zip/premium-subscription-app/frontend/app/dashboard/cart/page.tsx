'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Loader2, ShoppingCart } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth-context';
import PromptCard, { Prompt } from '@/components/marketplace/PromptCard';
import { SkeletonGrid } from '@/components/ui/Skeleton';

export default function CartPage() {
  const { subscription, refresh } = useAuth();
  const [items, setItems] = useState<Prompt[]>([]);
  const [loading, setLoading] = useState(true);
  const [checkingOut, setCheckingOut] = useState(false);

  const load = () => api.get('/cart').then(({ data }) => setItems(data.cart)).catch(() => toast.error('Could not load your cart')).finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  const remove = async (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
    try {
      await api.delete(`/cart/${id}`);
    } catch {
      toast.error('Something went wrong');
      load();
    }
  };

  const checkout = async () => {
    setCheckingOut(true);
    try {
      const { data } = await api.post('/cart/checkout');
      toast.success(data.message);
      setItems([]);
      await refresh();
    } catch (err: any) {
      if (err.response?.data?.requiresSubscription) {
        toast.error('Subscribe to unlock everything in your cart');
      } else {
        toast.error(err.response?.data?.message || 'Checkout failed');
      }
    } finally {
      setCheckingOut(false);
    }
  };

  const isActive = subscription?.status === 'ACTIVE';

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-neutral-50">Your Cart</h1>
      <p className="mt-1 text-neutral-400">Prompts queued up to unlock.</p>

      {loading ? (
        <div className="mt-8"><SkeletonGrid count={3} /></div>
      ) : items.length === 0 ? (
        <p className="mt-8 text-neutral-500">Your cart is empty — browse the marketplace to add prompts.</p>
      ) : (
        <>
          <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((p) => (
              <PromptCard key={p.id} prompt={p} inCart onToggleCart={remove} />
            ))}
          </div>

          <div className="glass-card mt-8 flex flex-col items-center justify-between gap-4 sm:flex-row">
            <div>
              <p className="font-semibold text-neutral-100">{items.length} prompt(s) in cart</p>
              <p className="text-sm text-neutral-400">
                {isActive
                  ? 'Your subscription is active — checkout unlocks these instantly.'
                  : 'An active subscription unlocks everything in your cart.'}
              </p>
            </div>
            {isActive ? (
              <button onClick={checkout} disabled={checkingOut} aria-busy={checkingOut} className="btn-gold whitespace-nowrap">
                {checkingOut ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShoppingCart className="h-4 w-4" />}
                Checkout & Unlock
              </button>
            ) : (
              <Link href="/dashboard/subscription" className="btn-gold whitespace-nowrap">
                Subscribe — ₦1,000/mo
              </Link>
            )}
          </div>
        </>
      )}
    </div>
  );
}
