'use client';

import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { api } from '@/lib/api';
import PromptCard, { Prompt } from '@/components/marketplace/PromptCard';
import { SkeletonGrid } from '@/components/ui/Skeleton';

export default function WishlistPage() {
  const [items, setItems] = useState<Prompt[]>([]);
  const [loading, setLoading] = useState(true);

  const load = () => api.get('/wishlist').then(({ data }) => setItems(data.wishlist)).catch(() => toast.error('Could not load your wishlist')).finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  const remove = async (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
    try {
      await api.delete(`/wishlist/${id}`);
      toast.success('Removed from wishlist');
    } catch {
      toast.error('Something went wrong');
      load();
    }
  };

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-neutral-50">Wishlist</h1>
      <p className="mt-1 text-neutral-400">Prompts you've saved for later.</p>

      {loading ? (
        <div className="mt-8"><SkeletonGrid count={3} /></div>
      ) : items.length === 0 ? (
        <p className="mt-8 text-neutral-500">Your wishlist is empty — browse the marketplace to save prompts.</p>
      ) : (
        <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((p) => (
            <PromptCard key={p.id} prompt={p} wishlisted onToggleWishlist={remove} />
          ))}
        </div>
      )}
    </div>
  );
}
