'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Lock } from 'lucide-react';
import { api } from '@/lib/api';

type Content = {
  id: string;
  title: string;
  description?: string;
  type: 'TEXT' | 'IMAGE' | 'VIDEO' | 'PDF' | 'AUDIO';
  fileUrl: string;
};

export default function PremiumContentPage() {
  const { id } = useParams<{ id: string }>();
  const [content, setContent] = useState<Content | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get(`/content/${id}`)
      .then(({ data }) => setContent(data.content))
      .catch((err) => setError(err.response?.data?.message || 'Unable to load content'))
      .finally(() => setLoading(false));
  }, [id]);

  return (
    <div className="mx-auto max-w-4xl px-6 py-10">
      <Link href="/dashboard" className="mb-6 inline-flex items-center gap-2 text-sm text-neutral-400 hover:text-gold-400">
        <ArrowLeft className="h-4 w-4" /> Back to dashboard
      </Link>

      {loading && <p className="text-neutral-500">Loading…</p>}

      {error && (
        <div className="glass-card flex flex-col items-center gap-3 py-16 text-center">
          <Lock className="h-8 w-8 text-gold-400" />
          <p className="text-neutral-300">{error}</p>
          <Link href="/dashboard/subscription" className="btn-gold !px-5 !py-2 text-sm">
            Subscribe to unlock
          </Link>
        </div>
      )}

      {content && (
        <div className="glass-card">
          <h1 className="font-display text-2xl font-bold text-neutral-50">{content.title}</h1>
          {content.description && <p className="mt-2 text-neutral-400">{content.description}</p>}

          <div className="mt-6">
            {content.type === 'VIDEO' && (
              <video controls className="w-full rounded-xl" src={content.fileUrl} />
            )}
            {content.type === 'AUDIO' && (
              <audio controls className="w-full" src={content.fileUrl} />
            )}
            {content.type === 'IMAGE' && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={content.fileUrl} alt={content.title} className="w-full rounded-xl" />
            )}
            {content.type === 'PDF' && (
              <a href={content.fileUrl} target="_blank" rel="noreferrer" className="btn-gold">
                Open PDF
              </a>
            )}
            {content.type === 'TEXT' && (
              <a href={content.fileUrl} target="_blank" rel="noreferrer" className="btn-gold">
                Read full text
              </a>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
