'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Search, ShieldOff, ShieldAlert, ShieldCheck, Eye } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

type Subscriber = {
  id: string;
  name: string;
  email: string;
  status: 'ACTIVE' | 'SUSPENDED' | 'BANNED';
  coinBalance: number;
  subscription?: { status: string; expiresAt?: string };
};

const statusPill: Record<string, string> = {
  ACTIVE: 'bg-emerald-500/10 text-emerald-400',
  SUSPENDED: 'bg-gold-500/10 text-gold-400',
  BANNED: 'bg-red-500/10 text-red-400',
};

export default function AdminUsersPage() {
  const [users, setUsers] = useState<Subscriber[]>([]);
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    api.get('/admin/subscribers', { params: { q: q || undefined } }).then(({ data }) => setUsers(data.subscribers)).catch(() => toast.error('Could not load users')).finally(() => setLoading(false));
  };

  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
  }, [q]);

  const act = async (id: string, action: 'suspend' | 'ban' | 'reactivate') => {
    try {
      await api.patch(`/admin/users/${id}/${action}`);
      toast.success(`User ${action}d`);
      setUsers((prev) => prev.map((u) => (u.id === id ? { ...u, status: action === 'reactivate' ? 'ACTIVE' : action === 'suspend' ? 'SUSPENDED' : 'BANNED' } : u)));
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Action failed');
    }
  };

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-neutral-50">User Management</h1>
      <p className="mt-1 text-neutral-400">Search, view, and moderate members.</p>

      <div className="relative mt-6 max-w-md">
        <Search className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-neutral-500" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by name or email…" className="input-field !pl-11" />
      </div>

      <div className="glass-card mt-6 overflow-x-auto">
        {loading ? (
          <p className="text-neutral-500">Loading…</p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-white/10 text-neutral-400">
                <th className="pb-3">Name</th>
                <th className="pb-3">Email</th>
                <th className="pb-3">Membership</th>
                <th className="pb-3">Coins</th>
                <th className="pb-3">Status</th>
                <th className="pb-3"></th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-b border-white/5 text-neutral-200">
                  <td className="py-3">{u.name}</td>
                  <td className="py-3 text-neutral-400">{u.email}</td>
                  <td className="py-3 text-neutral-400">{u.subscription?.status || 'NONE'}</td>
                  <td className="py-3 text-neutral-400">{u.coinBalance}</td>
                  <td className="py-3">
                    <span className={`rounded-full px-2.5 py-1 text-[11px] font-medium ${statusPill[u.status]}`}>{u.status}</span>
                  </td>
                  <td className="py-3">
                    <div className="flex items-center gap-2">
                      <Link href={`/admin/users/${u.id}`} className="text-neutral-500 hover:text-gold-400" title="View profile">
                        <Eye className="h-4 w-4" />
                      </Link>
                      {u.status !== 'SUSPENDED' && (
                        <button onClick={() => act(u.id, 'suspend')} className="text-neutral-500 hover:text-gold-400" title="Suspend">
                          <ShieldAlert className="h-4 w-4" />
                        </button>
                      )}
                      {u.status !== 'BANNED' && (
                        <button onClick={() => act(u.id, 'ban')} className="text-neutral-500 hover:text-red-400" title="Ban">
                          <ShieldOff className="h-4 w-4" />
                        </button>
                      )}
                      {u.status !== 'ACTIVE' && (
                        <button onClick={() => act(u.id, 'reactivate')} className="text-neutral-500 hover:text-emerald-400" title="Reactivate">
                          <ShieldCheck className="h-4 w-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
