'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, ShieldOff, ShieldAlert, ShieldCheck, Coins, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

type Detail = {
  user: {
    id: string; name: string; email: string; status: string; statusReason?: string;
    coinBalance: number; createdAt: string; isEmailVerified: boolean;
    subscription?: { status: string; expiresAt?: string };
  };
  payments: { id: string; reference: string; amount: number; status: string; createdAt: string }[];
  downloads: { id: string; downloadedAt: string; content: { title: string; category: string } }[];
  coinTransactions: { id: string; amount: number; type: string; reason: string; createdAt: string }[];
};

const statusPill: Record<string, string> = {
  ACTIVE: 'bg-emerald-500/10 text-emerald-400',
  SUSPENDED: 'bg-gold-500/10 text-gold-400',
  BANNED: 'bg-red-500/10 text-red-400',
};

export default function AdminUserDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [data, setData] = useState<Detail | null>(null);
  const [coinAmount, setCoinAmount] = useState('');
  const [coinReason, setCoinReason] = useState('');
  const [adjusting, setAdjusting] = useState(false);

  const load = () => api.get(`/admin/users/${id}`).then(({ data }) => setData(data)).catch(() => toast.error('Could not load user details'));

  useEffect(() => { load(); }, [id]);

  const act = async (action: 'suspend' | 'ban' | 'reactivate') => {
    try {
      await api.patch(`/admin/users/${id}/${action}`);
      toast.success(`User ${action}d`);
      load();
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Action failed');
    }
  };

  const adjustCoins = async (direction: 'add' | 'remove') => {
    const amount = Number(coinAmount);
    if (!amount || amount <= 0) return toast.error('Enter a valid coin amount');
    setAdjusting(true);
    try {
      await api.post(`/admin/coins/${id}/${direction}`, { amount, reason: coinReason || undefined });
      toast.success(`Coins ${direction === 'add' ? 'added' : 'removed'}`);
      setCoinAmount('');
      setCoinReason('');
      load();
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Could not adjust coins');
    } finally {
      setAdjusting(false);
    }
  };

  if (!data) return <p className="text-neutral-500">Loading…</p>;
  const { user, payments, downloads, coinTransactions } = data;

  return (
    <div>
      <Link href="/admin/users" className="mb-6 inline-flex items-center gap-2 text-sm text-neutral-400 hover:text-gold-400">
        <ArrowLeft className="h-4 w-4" /> Back to users
      </Link>

      <div className="glass-card flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <h1 className="font-display text-2xl font-bold text-neutral-50">{user.name}</h1>
          <p className="text-neutral-400">{user.email}</p>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <span className={`rounded-full px-2.5 py-1 text-[11px] font-medium ${statusPill[user.status]}`}>{user.status}</span>
            <span className="text-xs text-neutral-500">Membership: {user.subscription?.status || 'NONE'}</span>
            {user.subscription?.expiresAt && (
              <span className="text-xs text-neutral-500">until {new Date(user.subscription.expiresAt).toLocaleDateString()}</span>
            )}
          </div>
          {user.statusReason && <p className="mt-1 text-xs text-neutral-500">Reason: {user.statusReason}</p>}
        </div>

        <div className="flex gap-2">
          {user.status !== 'SUSPENDED' && (
            <button onClick={() => act('suspend')} className="btn-outline !py-2 text-xs"><ShieldAlert className="h-3.5 w-3.5" /> Suspend</button>
          )}
          {user.status !== 'BANNED' && (
            <button onClick={() => act('ban')} className="btn-outline !py-2 text-xs !border-red-500/40 !text-red-400"><ShieldOff className="h-3.5 w-3.5" /> Ban</button>
          )}
          {user.status !== 'ACTIVE' && (
            <button onClick={() => act('reactivate')} className="btn-gold !py-2 text-xs"><ShieldCheck className="h-3.5 w-3.5" /> Reactivate</button>
          )}
        </div>
      </div>

      {/* Coin balance + adjustment */}
      <div className="glass-card mt-6">
        <div className="flex items-center gap-2">
          <Coins className="h-5 w-5 text-gold-400" />
          <p className="font-semibold text-neutral-100">Coin Balance: {user.coinBalance}</p>
        </div>
        <div className="mt-4 flex flex-wrap items-end gap-3">
          <div>
            <label className="mb-1 block text-xs text-neutral-500">Amount</label>
            <input type="number" min={1} value={coinAmount} onChange={(e) => setCoinAmount(e.target.value)} className="input-field w-32" />
          </div>
          <div className="flex-1 min-w-[200px]">
            <label className="mb-1 block text-xs text-neutral-500">Reason (optional)</label>
            <input value={coinReason} onChange={(e) => setCoinReason(e.target.value)} className="input-field" placeholder="e.g. loyalty reward" />
          </div>
          <button onClick={() => adjustCoins('add')} disabled={adjusting} className="btn-gold !py-2.5 text-xs">
            {adjusting && <Loader2 className="h-3.5 w-3.5 animate-spin" />} Add Coins
          </button>
          <button onClick={() => adjustCoins('remove')} disabled={adjusting} className="btn-outline !py-2.5 text-xs">
            Remove Coins
          </button>
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="glass-card overflow-x-auto">
          <p className="mb-4 font-semibold text-neutral-100">Purchase History</p>
          {payments.length === 0 ? (
            <p className="text-sm text-neutral-500">No payments yet.</p>
          ) : (
            <table className="w-full text-left text-xs">
              <tbody>
                {payments.map((p) => (
                  <tr key={p.id} className="border-b border-white/5 text-neutral-300">
                    <td className="py-2">{p.reference}</td>
                    <td className="py-2">₦{(p.amount / 100).toLocaleString()}</td>
                    <td className="py-2">{p.status}</td>
                    <td className="py-2 text-neutral-500">{new Date(p.createdAt).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        <div className="glass-card overflow-x-auto">
          <p className="mb-4 font-semibold text-neutral-100">Download History</p>
          {downloads.length === 0 ? (
            <p className="text-sm text-neutral-500">No downloads yet.</p>
          ) : (
            <table className="w-full text-left text-xs">
              <tbody>
                {downloads.map((d) => (
                  <tr key={d.id} className="border-b border-white/5 text-neutral-300">
                    <td className="py-2">{d.content.title}</td>
                    <td className="py-2 text-neutral-500">{d.content.category}</td>
                    <td className="py-2 text-neutral-500">{new Date(d.downloadedAt).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      <div className="glass-card mt-6 overflow-x-auto">
        <p className="mb-4 font-semibold text-neutral-100">Coin Transaction History</p>
        {coinTransactions.length === 0 ? (
          <p className="text-sm text-neutral-500">No coin transactions yet.</p>
        ) : (
          <table className="w-full text-left text-xs">
            <tbody>
              {coinTransactions.map((c) => (
                <tr key={c.id} className="border-b border-white/5 text-neutral-300">
                  <td className={`py-2 font-medium ${c.amount >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{c.amount >= 0 ? '+' : ''}{c.amount}</td>
                  <td className="py-2">{c.type}</td>
                  <td className="py-2 text-neutral-500">{c.reason}</td>
                  <td className="py-2 text-neutral-500">{new Date(c.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
