'use client';

import { useEffect, useState } from 'react';
import { Loader2, RotateCcw } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

type Payment = {
  id: string;
  reference: string;
  amount: number;
  status: 'PENDING' | 'SUCCESS' | 'FAILED' | 'REFUNDED';
  couponCode?: string;
  discountKobo: number;
  createdAt: string;
  user: { name: string; email: string };
};

const statusColor: Record<string, string> = {
  SUCCESS: 'text-emerald-400', PENDING: 'text-gold-400', FAILED: 'text-red-400', REFUNDED: 'text-neutral-400',
};

export default function OrdersPage() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [refundingId, setRefundingId] = useState<string | null>(null);

  const load = () => api.get('/admin/payments').then(({ data }) => setPayments(data.payments)).catch(() => toast.error('Could not load payments')).finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  const refund = async (id: string) => {
    const reason = prompt('Refund reason (optional):') || undefined;
    setRefundingId(id);
    try {
      const { data } = await api.post(`/admin/payments/${id}/refund`, { reason });
      toast.success(data.paystackRefunded ? 'Refunded via Paystack' : 'Marked as refunded (Paystack API call failed — verify manually)');
      setPayments((prev) => prev.map((p) => (p.id === id ? { ...p, status: 'REFUNDED' } : p)));
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Refund failed');
    } finally {
      setRefundingId(null);
    }
  };

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-neutral-50">Orders & Payments</h1>
      <p className="mt-1 text-neutral-400">Every Paystack transaction, with refund controls.</p>

      <div className="glass-card mt-6 overflow-x-auto">
        {loading ? (
          <p className="text-neutral-500">Loading…</p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-white/10 text-neutral-400">
                <th className="pb-3">User</th>
                <th className="pb-3">Reference</th>
                <th className="pb-3">Amount</th>
                <th className="pb-3">Coupon</th>
                <th className="pb-3">Status</th>
                <th className="pb-3">Date</th>
                <th className="pb-3"></th>
              </tr>
            </thead>
            <tbody>
              {payments.map((p) => (
                <tr key={p.id} className="border-b border-white/5 text-neutral-200">
                  <td className="py-3">
                    <p>{p.user?.name}</p>
                    <p className="text-xs text-neutral-500">{p.user?.email}</p>
                  </td>
                  <td className="py-3 font-mono text-xs text-neutral-400">{p.reference}</td>
                  <td className="py-3">₦{(p.amount / 100).toLocaleString()}</td>
                  <td className="py-3 text-xs text-neutral-400">
                    {p.couponCode ? `${p.couponCode} (-₦${(p.discountKobo / 100).toLocaleString()})` : '—'}
                  </td>
                  <td className={`py-3 font-medium ${statusColor[p.status]}`}>{p.status}</td>
                  <td className="py-3 text-neutral-400">{new Date(p.createdAt).toLocaleDateString()}</td>
                  <td className="py-3">
                    {p.status === 'SUCCESS' && (
                      <button
                        onClick={() => refund(p.id)}
                        disabled={refundingId === p.id}
                        className="flex items-center gap-1 text-xs text-neutral-500 hover:text-red-400"
                      >
                        {refundingId === p.id ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RotateCcw className="h-3.5 w-3.5" />}
                        Refund
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
