'use client';

import { useEffect, useState } from 'react';
import { Loader2, Save } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

const empty = {
  appName: '', logoUrl: '', primaryColor: '#d4af37', secondaryColor: '#000000',
  seoTitle: '', seoDescription: '',
  contactEmail: '', contactPhone: '', socialTwitter: '', socialInstagram: '', socialLinkedin: '',
  supportEmailFrom: '', paystackPublicKey: '',
};

export default function WebsiteSettingsPage() {
  const [form, setForm] = useState(empty);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get('/admin/settings').then(({ data }) => {
      const s = data.settings;
      setForm({
        appName: s.appName || '', logoUrl: s.logoUrl || '',
        primaryColor: s.primaryColor || '#d4af37', secondaryColor: s.secondaryColor || '#000000',
        seoTitle: s.seoTitle || '', seoDescription: s.seoDescription || '',
        contactEmail: s.contactEmail || '', contactPhone: s.contactPhone || '',
        socialTwitter: s.socialTwitter || '', socialInstagram: s.socialInstagram || '', socialLinkedin: s.socialLinkedin || '',
        supportEmailFrom: s.supportEmailFrom || '', paystackPublicKey: s.paystackPublicKey || '',
      });
    }).catch(() => toast.error('Could not load settings')).finally(() => setLoading(false));
  }, []);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.patch('/admin/settings', form);
      toast.success('Settings saved');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Could not save settings');
    } finally {
      setSaving(false);
    }
  };

  const set = (key: keyof typeof empty) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm({ ...form, [key]: e.target.value });

  if (loading) return <p className="text-neutral-500">Loading…</p>;

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-neutral-50">Website Settings</h1>
      <p className="mt-1 text-neutral-400">Branding, SEO, contact details, and payment configuration.</p>

      <form onSubmit={save} className="mt-8 space-y-6">
        <section className="glass-card space-y-4">
          <h2 className="font-semibold text-neutral-100">Branding & Theme</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label className="mb-1 block text-xs text-neutral-500">App Name</label>
              <input className="input-field" value={form.appName} onChange={set('appName')} />
            </div>
            <div>
              <label className="mb-1 block text-xs text-neutral-500">Logo URL</label>
              <input className="input-field" value={form.logoUrl} onChange={set('logoUrl')} placeholder="https://…" />
            </div>
            <div>
              <label className="mb-1 block text-xs text-neutral-500">Primary Color</label>
              <div className="flex items-center gap-2">
                <input type="color" value={form.primaryColor} onChange={set('primaryColor')} className="h-10 w-14 rounded-lg border border-white/10 bg-transparent" />
                <input className="input-field" value={form.primaryColor} onChange={set('primaryColor')} />
              </div>
            </div>
            <div>
              <label className="mb-1 block text-xs text-neutral-500">Secondary Color</label>
              <div className="flex items-center gap-2">
                <input type="color" value={form.secondaryColor} onChange={set('secondaryColor')} className="h-10 w-14 rounded-lg border border-white/10 bg-transparent" />
                <input className="input-field" value={form.secondaryColor} onChange={set('secondaryColor')} />
              </div>
            </div>
          </div>
        </section>

        <section className="glass-card space-y-4">
          <h2 className="font-semibold text-neutral-100">SEO</h2>
          <div>
            <label className="mb-1 block text-xs text-neutral-500">SEO Title</label>
            <input className="input-field" value={form.seoTitle} onChange={set('seoTitle')} />
          </div>
          <div>
            <label className="mb-1 block text-xs text-neutral-500">SEO Description</label>
            <textarea rows={3} className="input-field" value={form.seoDescription} onChange={set('seoDescription')} />
          </div>
        </section>

        <section className="glass-card space-y-4">
          <h2 className="font-semibold text-neutral-100">Contact Information</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <input className="input-field" placeholder="Contact email" value={form.contactEmail} onChange={set('contactEmail')} />
            <input className="input-field" placeholder="Contact phone" value={form.contactPhone} onChange={set('contactPhone')} />
          </div>
        </section>

        <section className="glass-card space-y-4">
          <h2 className="font-semibold text-neutral-100">Social Media Links</h2>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
            <input className="input-field" placeholder="Twitter / X URL" value={form.socialTwitter} onChange={set('socialTwitter')} />
            <input className="input-field" placeholder="Instagram URL" value={form.socialInstagram} onChange={set('socialInstagram')} />
            <input className="input-field" placeholder="LinkedIn URL" value={form.socialLinkedin} onChange={set('socialLinkedin')} />
          </div>
        </section>

        <section className="glass-card space-y-4">
          <h2 className="font-semibold text-neutral-100">Email Settings</h2>
          <div>
            <label className="mb-1 block text-xs text-neutral-500">"From" address for outgoing emails</label>
            <input className="input-field" placeholder="Aurum <no-reply@yourapp.com>" value={form.supportEmailFrom} onChange={set('supportEmailFrom')} />
          </div>
          <p className="text-xs text-neutral-500">
            SMTP host, port, and credentials are configured server-side via environment variables for security and are not editable here.
          </p>
        </section>

        <section className="glass-card space-y-4">
          <h2 className="font-semibold text-neutral-100">Payment Settings</h2>
          <div>
            <label className="mb-1 block text-xs text-neutral-500">Paystack Public Key</label>
            <input className="input-field" placeholder="pk_live_… or pk_test_…" value={form.paystackPublicKey} onChange={set('paystackPublicKey')} />
          </div>
          <p className="text-xs text-neutral-500">
            Your Paystack <b>secret</b> key and webhook secret are never stored in the database — they stay
            in server environment variables only, for security. Update them via your hosting provider's
            environment settings.
          </p>
        </section>

        <button disabled={saving} className="btn-gold">
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Save All Settings
        </button>
      </form>
    </div>
  );
}
