'use client';

import { Loader2 } from 'lucide-react';
import AdminSidebar from '@/components/admin/AdminSidebar';
import { useAuth } from '@/lib/auth-context';

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { loading } = useAuth();

  // Same rationale as dashboard/layout.tsx — avoids a flash of empty/wrong
  // state on every admin page while the initial auth check is in flight.
  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-gold-400" />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <AdminSidebar />
      <main className="pt-20 md:pl-64 md:pt-0">
        <div className="mx-auto max-w-6xl px-6 py-10">{children}</div>
      </main>
    </div>
  );
}
