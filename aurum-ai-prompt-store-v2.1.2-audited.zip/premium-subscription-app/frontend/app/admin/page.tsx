'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { Users, TrendingUp, Coins, Crown, Wallet, Award, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

type Dashboard = {
  stats: {
    totalRevenueNaira: number;
    monthlySalesNaira: number;
    totalUsers: number;
    activeSubscribers: number;
    totalCoinsIssued: number;
    totalCoinsOutstanding: number;
  };
  growth: { month: string; naira: number }[];
  topPrompts: { id: string; title: string; category: string; downloadCount: number; rating: number }[];
  recentTransactions: {
    id: string; reference: string; amount: number; status: string; createdAt: string;
    user: { name: string; email: string };
  }[];
};

const statusColor: Record<string, string> = {
  SUCCESS: 'text-emerald-400', PENDING: 'text-gold-400', FAILED: 'text-red-400', REFUNDED: 'text-neutral-400',
};

export default function AdminDashboardHome() {
  const [data, setData] = useState<Dashboard | null>(null);

  useEffect(() => {
    api.get('/admin/dashboard').then(({ data }) => setData(data)).catch(() => toast.error('Could not load dashboard data'));
  }, []);

  const cards = [
    { label: 'Total Revenue', value: data ? `₦${data.stats.totalRevenueNaira.toLocaleString()}` : '—', icon: TrendingUp },
    { label: 'Monthly Sales', value: data ? `₦${data.stats.monthlySalesNaira.toLocaleString()}` : '—', icon: Wallet },
    { label: 'Active Users', value: data?.stats.totalUsers ?? '—', icon: Users },
    { label: 'Premium Members', value: data?.stats.activeSubscribers ?? '—', icon: Crown },
    { label: 'Coins Issued', value: data?.stats.totalCoinsIssued ?? '—', icon: Coins },
    { label: 'Coins Outstanding', value: data?.stats.totalCoinsOutstanding ?? '—', icon: Coins },
  ];

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-neutral-50">Dashboard Home</h1>
      <p className="mt-1 text-neutral-400">A full snapshot of revenue, growth, and platform health.</p>

      <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map((c) => (
          <div key={c.label} className="glass-card">
            <div className="flex items-center justify-between">
              <p className="text-sm text-neutral-400">{c.label}</p>
              <c.icon className="h-4 w-4 text-gold-400" />
            </div>
            <p className="mt-3 font-display text-2xl font-bold text-neutral-50">{c.value}</p>
          </div>
        ))}
      </div>

      <div className="glass-card mt-6 h-80">
        <p className="mb-4 font-semibold text-neutral-100">Revenue growth (last 6 months)</p>
        {data && data.growth.length > 0 ? (
          <ResponsiveContainer width="100%" height="90%">
            <AreaChart data={data.growth}>
              <defs>
                <linearGradient id="goldFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#d4af37" stopOpacity={0.4} />
                  <stop offset="100%" stopColor="#d4af37" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="month" stroke="#9ca3af" fontSize={12} />
              <YAxis stroke="#9ca3af" fontSize={12} />
              <Tooltip contentStyle={{ background: '#0b0b0b', border: '1px solid rgba(212,175,55,0.3)' }} />
              <Area type="monotone" dataKey="naira" stroke="#d4af37" fill="url(#goldFill)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-neutral-500">No revenue data yet.</p>
        )}
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 md:grid-cols-2">
        <div className="glass-card">
          <div className="mb-4 flex items-center justify-between">
            <p className="font-semibold text-neutral-100">Top-Selling Prompts</p>
            <Link href="/admin/content" className="text-xs text-gold-400 hover:underline">Manage <ArrowRight className="inline h-3 w-3" /></Link>
          </div>
          {data?.topPrompts.length ? (
            <ul className="space-y-3">
              {data.topPrompts.map((p, i) => (
                <li key={p.id} className="flex items-center justify-between text-sm">
                  <span className="flex items-center gap-2 text-neutral-200">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-gold-500/10 text-xs text-gold-400">{i + 1}</span>
                    {p.title}
                  </span>
                  <span className="flex items-center gap-1 text-neutral-500">
                    <Award className="h-3.5 w-3.5 text-gold-500" /> {p.downloadCount} unlocks
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-neutral-500">No prompts yet.</p>
          )}
        </div>

        <div className="glass-card">
          <div className="mb-4 flex items-center justify-between">
            <p className="font-semibold text-neutral-100">Recent Transactions</p>
            <Link href="/admin/orders" className="text-xs text-gold-400 hover:underline">View all <ArrowRight className="inline h-3 w-3" /></Link>
          </div>
          {data?.recentTransactions.length ? (
            <ul className="space-y-3 text-sm">
              {data.recentTransactions.map((t) => (
                <li key={t.id} className="flex items-center justify-between">
                  <div>
                    <p className="text-neutral-200">{t.user?.name || 'Unknown'}</p>
                    <p className="text-xs text-neutral-500">{new Date(t.createdAt).toLocaleDateString()}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-neutral-200">₦{(t.amount / 100).toLocaleString()}</p>
                    <p className={`text-xs font-medium ${statusColor[t.status]}`}>{t.status}</p>
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-neutral-500">No transactions yet.</p>
          )}
        </div>
      </div>
    </div>
  );
}
