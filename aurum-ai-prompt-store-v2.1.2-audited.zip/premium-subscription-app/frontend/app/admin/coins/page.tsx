'use client';

import { useEffect, useState } from 'react';
import { Plus, Trash2, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

type Rule = { id: string; name: string; trigger: string; coinAmount: number; description?: string; active: boolean };
type Tx = { id: string; amount: number; type: string; reason: string; createdAt: string; user: { name: string; email: string } };

const TRIGGERS = ['SIGNUP', 'SUBSCRIBE', 'REFERRAL', 'REVIEW', 'FIRST_DOWNLOAD'];

export default function CoinsManagementPage() {
  const [rules, setRules] = useState<Rule[]>([]);
  const [history, setHistory] = useState<Tx[]>([]);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState({ name: '', trigger: 'SIGNUP', coinAmount: '', description: '' });
  const [creating, setCreating] = useState(false);

  const load = () => {
    setLoading(true);
    Promise.all([api.get('/admin/coins/rules'), api.get('/admin/coins/history')])
      .then(([r, h]) => { setRules(r.data.rules); setHistory(h.data.transactions); })
      .catch(() => toast.error('Could not load coins data'))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const createRule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.coinAmount) return toast.error('Name and coin amount are required');
    setCreating(true);
    try {
      await api.post('/admin/coins/rules', { ...form, coinAmount: Number(form.coinAmount) });
      toast.success('Reward rule created');
      setForm({ name: '', trigger: 'SIGNUP', coinAmount: '', description: '' });
      load();
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Could not create rule');
    } finally {
      setCreating(false);
    }
  };

  const toggleActive = async (rule: Rule) => {
    setRules((prev) => prev.map((r) => (r.id === rule.id ? { ...r, active: !r.active } : r)));
    try {
      await api.patch(`/admin/coins/rules/${rule.id}`, { active: !rule.active });
    } catch {
      toast.error('Could not update rule');
      load();
    }
  };

  const removeRule = async (id: string) => {
    if (!confirm('Delete this reward rule?')) return;
    try {
      await api.delete(`/admin/coins/rules/${id}`);
      setRules((prev) => prev.filter((r) => r.id !== id));
    } catch {
      toast.error('Could not delete rule');
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-neutral-50">Coins Management</h1>
        <p className="mt-1 text-neutral-400">
          Configure automatic reward rules and audit every coin adjustment. To add or remove coins for a
          specific member, open their profile from <span className="text-gold-400">User Management</span>.
        </p>
      </div>

      <form onSubmit={createRule} className="glass-card space-y-4">
        <h2 className="font-semibold text-neutral-100">New reward rule</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <input placeholder="Rule name" className="input-field" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <select className="input-field" value={form.trigger} onChange={(e) => setForm({ ...form, trigger: e.target.value })}>
            {TRIGGERS.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
          <input type="number" min={1} placeholder="Coin amount" className="input-field" value={form.coinAmount} onChange={(e) => setForm({ ...form, coinAmount: e.target.value })} />
        </div>
        <input placeholder="Description (optional)" className="input-field" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        <button disabled={creating} className="btn-gold">
          {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          Create Rule
        </button>
      </form>

      <div className="glass-card overflow-x-auto">
        <h2 className="mb-4 font-semibold text-neutral-100">Reward Rules</h2>
        {loading ? (
          <p className="text-neutral-500">Loading…</p>
        ) : rules.length === 0 ? (
          <p className="text-neutral-500">No reward rules yet.</p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-white/10 text-neutral-400">
                <th className="pb-3">Name</th>
                <th className="pb-3">Trigger</th>
                <th className="pb-3">Coins</th>
                <th className="pb-3">Active</th>
                <th className="pb-3"></th>
              </tr>
            </thead>
            <tbody>
              {rules.map((r) => (
                <tr key={r.id} className="border-b border-white/5 text-neutral-200">
                  <td className="py-3">{r.name}</td>
                  <td className="py-3 text-neutral-400">{r.trigger}</td>
                  <td className="py-3 text-gold-400">+{r.coinAmount}</td>
                  <td className="py-3">
                    <button
                      onClick={() => toggleActive(r)}
                      className={`h-5 w-9 rounded-full transition-colors ${r.active ? 'bg-gold-500' : 'bg-white/10'}`}
                    >
                      <span className={`block h-4 w-4 translate-y-0.5 rounded-full bg-white transition-transform ${r.active ? 'translate-x-4' : 'translate-x-0.5'}`} />
                    </button>
                  </td>
                  <td className="py-3">
                    <button onClick={() => removeRule(r.id)} className="text-neutral-500 hover:text-red-400"><Trash2 className="h-4 w-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <div className="glass-card overflow-x-auto">
        <h2 className="mb-4 font-semibold text-neutral-100">Global Coin History</h2>
        {history.length === 0 ? (
          <p className="text-neutral-500">No coin transactions yet.</p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-white/10 text-neutral-400">
                <th className="pb-3">User</th>
                <th className="pb-3">Amount</th>
                <th className="pb-3">Type</th>
                <th className="pb-3">Reason</th>
                <th className="pb-3">Date</th>
              </tr>
            </thead>
            <tbody>
              {history.map((h) => (
                <tr key={h.id} className="border-b border-white/5 text-neutral-200">
                  <td className="py-3">{h.user?.name}</td>
                  <td className={`py-3 font-medium ${h.amount >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{h.amount >= 0 ? '+' : ''}{h.amount}</td>
                  <td className="py-3 text-neutral-400">{h.type}</td>
                  <td className="py-3 text-neutral-400">{h.reason}</td>
                  <td className="py-3 text-neutral-500">{new Date(h.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
