'use client';

import { useEffect, useState } from 'react';
import { Check, X, Trash2, Star } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

type Review = {
  id: string; rating: number; comment?: string; status: string; createdAt: string;
  user: { name: string; email: string };
  content: { title: string };
};

const tabs = ['PENDING', 'APPROVED', 'REJECTED'];

export default function ReviewsPage() {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [tab, setTab] = useState('PENDING');
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    api.get('/admin/reviews', { params: { status: tab } }).then(({ data }) => setReviews(data.reviews)).catch(() => toast.error('Could not load reviews')).finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [tab]);

  const act = async (id: string, action: 'approve' | 'reject' | 'delete') => {
    try {
      if (action === 'delete') {
        await api.delete(`/admin/reviews/${id}`);
      } else {
        await api.patch(`/admin/reviews/${id}/${action}`);
      }
      toast.success(`Review ${action === 'delete' ? 'deleted' : action + 'd'}`);
      setReviews((prev) => prev.filter((r) => r.id !== id));
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Action failed');
    }
  };

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-neutral-50">Reviews</h1>
      <p className="mt-1 text-neutral-400">Moderate member reviews on prompts before they go public.</p>

      <div className="mt-6 flex gap-2">
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`rounded-full border px-4 py-1.5 text-xs transition-colors ${
              tab === t ? 'border-gold-500 bg-gold-500/10 text-gold-400' : 'border-white/10 text-neutral-400 hover:border-gold-500/30'
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="mt-6 space-y-4">
        {loading ? (
          <p className="text-neutral-500">Loading…</p>
        ) : reviews.length === 0 ? (
          <p className="text-neutral-500">No {tab.toLowerCase()} reviews.</p>
        ) : (
          reviews.map((r) => (
            <div key={r.id} className="glass-card">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold text-neutral-100">{r.user?.name} <span className="text-xs font-normal text-neutral-500">on {r.content?.title}</span></p>
                  <div className="mt-1 flex gap-0.5">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={`h-3.5 w-3.5 ${i < r.rating ? 'fill-gold-500 text-gold-500' : 'text-neutral-700'}`} />
                    ))}
                  </div>
                </div>
                <span className="text-xs text-neutral-500">{new Date(r.createdAt).toLocaleDateString()}</span>
              </div>
              {r.comment && <p className="mt-3 text-sm text-neutral-300">{r.comment}</p>}

              <div className="mt-4 flex gap-2 border-t border-white/10 pt-4">
                {tab !== 'APPROVED' && (
                  <button onClick={() => act(r.id, 'approve')} className="btn-outline !py-1.5 text-xs !border-emerald-500/40 !text-emerald-400">
                    <Check className="h-3.5 w-3.5" /> Approve
                  </button>
                )}
                {tab !== 'REJECTED' && (
                  <button onClick={() => act(r.id, 'reject')} className="btn-outline !py-1.5 text-xs">
                    <X className="h-3.5 w-3.5" /> Reject
                  </button>
                )}
                <button onClick={() => act(r.id, 'delete')} className="btn-outline !py-1.5 text-xs !border-red-500/40 !text-red-400">
                  <Trash2 className="h-3.5 w-3.5" /> Delete
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
