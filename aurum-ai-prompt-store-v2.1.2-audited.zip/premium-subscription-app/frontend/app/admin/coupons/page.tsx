'use client';

import { useEffect, useState } from 'react';
import { Plus, Trash2, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

type Coupon = {
  id: string; code: string; type: 'PERCENTAGE' | 'FIXED'; value: number;
  expiresAt?: string; usageLimit?: number; usedCount: number; active: boolean;
};

export default function CouponsPage() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [form, setForm] = useState({ code: '', type: 'PERCENTAGE', value: '', expiresAt: '', usageLimit: '' });

  const load = () => api.get('/admin/coupons').then(({ data }) => setCoupons(data.coupons)).catch(() => toast.error('Could not load coupons')).finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  const createCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.code || !form.value) return toast.error('Code and value are required');
    setCreating(true);
    try {
      await api.post('/admin/coupons', {
        code: form.code,
        type: form.type,
        value: Number(form.value),
        expiresAt: form.expiresAt || undefined,
        usageLimit: form.usageLimit || undefined,
      });
      toast.success('Coupon created');
      setForm({ code: '', type: 'PERCENTAGE', value: '', expiresAt: '', usageLimit: '' });
      load();
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Could not create coupon');
    } finally {
      setCreating(false);
    }
  };

  const toggleActive = async (c: Coupon) => {
    setCoupons((prev) => prev.map((x) => (x.id === c.id ? { ...x, active: !x.active } : x)));
    try {
      await api.patch(`/admin/coupons/${c.id}`, { active: !c.active });
    } catch {
      toast.error('Could not update coupon');
      load();
    }
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this coupon?')) return;
    try {
      await api.delete(`/admin/coupons/${id}`);
      setCoupons((prev) => prev.filter((c) => c.id !== id));
    } catch {
      toast.error('Could not delete coupon');
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-neutral-50">Coupons</h1>
        <p className="mt-1 text-neutral-400">Discount codes applied at checkout for the membership subscription.</p>
      </div>

      <form onSubmit={createCoupon} className="glass-card space-y-4">
        <h2 className="font-semibold text-neutral-100">Create coupon</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <input placeholder="CODE (e.g. WELCOME10)" className="input-field uppercase" value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} />
          <select className="input-field" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
            <option value="PERCENTAGE">Percentage %</option>
            <option value="FIXED">Fixed amount (₦)</option>
          </select>
          <input type="number" min={0} placeholder={form.type === 'PERCENTAGE' ? 'e.g. 10 (%)' : 'e.g. 200 (₦)'} className="input-field" value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} />
          <input type="date" className="input-field" value={form.expiresAt} onChange={(e) => setForm({ ...form, expiresAt: e.target.value })} />
        </div>
        <input type="number" min={1} placeholder="Usage limit (optional)" className="input-field max-w-xs" value={form.usageLimit} onChange={(e) => setForm({ ...form, usageLimit: e.target.value })} />
        <button disabled={creating} className="btn-gold">
          {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
          Create Coupon
        </button>
      </form>

      <div className="glass-card overflow-x-auto">
        <h2 className="mb-4 font-semibold text-neutral-100">All coupons</h2>
        {loading ? (
          <p className="text-neutral-500">Loading…</p>
        ) : coupons.length === 0 ? (
          <p className="text-neutral-500">No coupons yet.</p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-white/10 text-neutral-400">
                <th className="pb-3">Code</th>
                <th className="pb-3">Discount</th>
                <th className="pb-3">Usage</th>
                <th className="pb-3">Expires</th>
                <th className="pb-3">Active</th>
                <th className="pb-3"></th>
              </tr>
            </thead>
            <tbody>
              {coupons.map((c) => (
                <tr key={c.id} className="border-b border-white/5 text-neutral-200">
                  <td className="py-3 font-mono text-gold-400">{c.code}</td>
                  <td className="py-3">{c.type === 'PERCENTAGE' ? `${c.value}%` : `₦${c.value.toLocaleString()}`}</td>
                  <td className="py-3 text-neutral-400">{c.usedCount}{c.usageLimit ? ` / ${c.usageLimit}` : ''}</td>
                  <td className="py-3 text-neutral-400">{c.expiresAt ? new Date(c.expiresAt).toLocaleDateString() : 'Never'}</td>
                  <td className="py-3">
                    <button onClick={() => toggleActive(c)} className={`h-5 w-9 rounded-full transition-colors ${c.active ? 'bg-gold-500' : 'bg-white/10'}`}>
                      <span className={`block h-4 w-4 translate-y-0.5 rounded-full bg-white transition-transform ${c.active ? 'translate-x-4' : 'translate-x-0.5'}`} />
                    </button>
                  </td>
                  <td className="py-3">
                    <button onClick={() => remove(c.id)} className="text-neutral-500 hover:text-red-400"><Trash2 className="h-4 w-4" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
