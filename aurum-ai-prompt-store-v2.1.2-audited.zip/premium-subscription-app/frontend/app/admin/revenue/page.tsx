'use client';

import { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { toast } from 'sonner';
import { api } from '@/lib/api';

type Revenue = {
  totalRevenueNaira: number;
  totalTransactions: number;
  monthly: { month: string; naira: number }[];
};

export default function AdminRevenuePage() {
  const [revenue, setRevenue] = useState<Revenue | null>(null);

  useEffect(() => {
    api.get('/admin/revenue').then(({ data }) => setRevenue(data)).catch(() => toast.error('Could not load revenue data'));
  }, []);

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-neutral-50">Revenue</h1>

      <div className="mt-6 grid grid-cols-1 gap-5 sm:grid-cols-2">
        <div className="glass-card">
          <p className="text-sm text-neutral-400">Total Revenue</p>
          <p className="mt-2 font-display text-4xl font-bold text-gold-400">
            ₦{revenue ? revenue.totalRevenueNaira.toLocaleString() : '—'}
          </p>
        </div>
        <div className="glass-card">
          <p className="text-sm text-neutral-400">Successful Transactions</p>
          <p className="mt-2 font-display text-4xl font-bold text-neutral-50">
            {revenue ? revenue.totalTransactions : '—'}
          </p>
        </div>
      </div>

      <div className="glass-card mt-6 h-80">
        <p className="mb-4 font-semibold text-neutral-100">Monthly revenue (₦)</p>
        {revenue && revenue.monthly.length > 0 ? (
          <ResponsiveContainer width="100%" height="90%">
            <BarChart data={revenue.monthly}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="month" stroke="#9ca3af" fontSize={12} />
              <YAxis stroke="#9ca3af" fontSize={12} />
              <Tooltip contentStyle={{ background: '#0b1f17', border: '1px solid rgba(212,175,55,0.3)' }} />
              <Bar dataKey="naira" fill="#d4af37" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : (
          <p className="text-neutral-500">No revenue data yet.</p>
        )}
      </div>
    </div>
  );
}
