'use client';

import { useEffect, useState } from 'react';
import { Trash2, UploadCloud, Loader2, Award, TrendingUp } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

type Content = {
  id: string;
  title: string;
  type: string;
  category: string;
  tags: string[];
  isPremium: boolean;
  isFeatured: boolean;
  isTrending: boolean;
  isBestSeller: boolean;
  isVerified: boolean;
  views: number;
  downloadCount: number;
  createdAt: string;
};

const CATEGORIES = [
  'Marketing & Copywriting',
  'Coding & Development',
  'Art & Midjourney',
  'Business & Strategy',
  'Writing & Content',
  'Education & Research',
  'General',
];

const initialForm = {
  title: '',
  description: '',
  type: 'TEXT',
  category: 'General',
  tags: '',
  isPremium: true,
  isFeatured: false,
  isTrending: false,
  isBestSeller: false,
  isVerified: false,
};

export default function AdminContentPage() {
  const [items, setItems] = useState<Content[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);

  const [form, setForm] = useState(initialForm);
  const [file, setFile] = useState<File | null>(null);

  const loadContent = () => api.get('/content').then(({ data }) => setItems(data.content)).catch(() => toast.error('Could not load content')).finally(() => setLoading(false));

  useEffect(() => { loadContent(); }, []);

  const onUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return toast.error('Please choose a file to upload');
    setUploading(true);

    const fd = new FormData();
    Object.entries(form).forEach(([key, value]) => fd.append(key, String(value)));
    fd.append('file', file);

    try {
      await api.post('/content', fd, { headers: { 'Content-Type': 'multipart/form-data' } });
      toast.success('Content uploaded');
      setForm(initialForm);
      setFile(null);
      loadContent();
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Upload failed');
    } finally {
      setUploading(false);
    }
  };

  const onDelete = async (id: string) => {
    if (!confirm('Delete this content item permanently?')) return;
    try {
      await api.delete(`/content/${id}`);
      toast.success('Content deleted');
      setItems((prev) => prev.filter((i) => i.id !== id));
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Delete failed');
    }
  };

  const toggleBadge = async (item: Content, field: 'isFeatured' | 'isTrending' | 'isBestSeller' | 'isVerified') => {
    const next = !item[field];
    setItems((prev) => prev.map((i) => (i.id === item.id ? { ...i, [field]: next } : i)));
    try {
      const fd = new FormData();
      fd.append(field, String(next));
      await api.patch(`/content/${item.id}`, fd, { headers: { 'Content-Type': 'multipart/form-data' } });
    } catch {
      toast.error('Could not update badge');
      loadContent();
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-neutral-50">Content Management</h1>
        <p className="mt-1 text-neutral-400">Upload and manage marketplace prompts across every category.</p>
      </div>

      <form onSubmit={onUpload} className="glass-card space-y-4">
        <h2 className="font-semibold text-neutral-100">Upload new prompt</h2>
        <input required placeholder="Title" className="input-field" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <textarea placeholder="Description (optional)" className="input-field" rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />

        <div className="flex flex-wrap gap-4">
          <select className="input-field w-auto" value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
            <option value="TEXT">Text</option>
            <option value="IMAGE">Image</option>
            <option value="VIDEO">Video</option>
            <option value="PDF">PDF</option>
            <option value="AUDIO">Audio</option>
          </select>

          <select className="input-field w-auto" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>

          <label className="flex items-center gap-2 text-sm text-neutral-300">
            <input type="checkbox" checked={form.isPremium} onChange={(e) => setForm({ ...form, isPremium: e.target.checked })} />
            Premium (locked)
          </label>
        </div>

        <input
          placeholder="Tags, comma-separated (e.g. email, b2b, sales)"
          className="input-field"
          value={form.tags}
          onChange={(e) => setForm({ ...form, tags: e.target.value })}
        />

        <div className="flex flex-wrap gap-4 text-sm text-neutral-300">
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={form.isFeatured} onChange={(e) => setForm({ ...form, isFeatured: e.target.checked })} />
            Featured
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={form.isTrending} onChange={(e) => setForm({ ...form, isTrending: e.target.checked })} />
            Trending badge
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={form.isBestSeller} onChange={(e) => setForm({ ...form, isBestSeller: e.target.checked })} />
            Best Seller badge
          </label>
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={form.isVerified} onChange={(e) => setForm({ ...form, isVerified: e.target.checked })} />
            Gold Verified badge
          </label>
        </div>

        <input required type="file" onChange={(e) => setFile(e.target.files?.[0] || null)} className="text-sm text-neutral-400 file:mr-4 file:rounded-full file:border-0 file:bg-gold-500/10 file:px-4 file:py-2 file:text-gold-400" />

        <button disabled={uploading} className="btn-gold">
          {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <UploadCloud className="h-4 w-4" />}
          Upload
        </button>
      </form>

      <div className="glass-card overflow-x-auto">
        <h2 className="mb-4 font-semibold text-neutral-100">All prompts</h2>
        {loading ? (
          <p className="text-neutral-500">Loading…</p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-white/10 text-neutral-400">
                <th className="pb-3">Title</th>
                <th className="pb-3">Category</th>
                <th className="pb-3">Access</th>
                <th className="pb-3">Badges</th>
                <th className="pb-3">Unlocks</th>
                <th className="pb-3"></th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.id} className="border-b border-white/5 text-neutral-200">
                  <td className="py-3">{item.title}</td>
                  <td className="py-3 text-neutral-400">{item.category}</td>
                  <td className="py-3">{item.isPremium ? <span className="text-gold-400">Premium</span> : <span className="text-emerald-400">Free</span>}</td>
                  <td className="py-3">
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => toggleBadge(item, 'isFeatured')}
                        className={`rounded-full px-2 text-[10px] font-semibold ${item.isFeatured ? 'bg-white/20 text-white' : 'bg-white/5 text-neutral-600'}`}
                        title="Toggle Featured"
                      >
                        FT
                      </button>
                      <button
                        onClick={() => toggleBadge(item, 'isTrending')}
                        className={`rounded-full p-1.5 ${item.isTrending ? 'bg-rose-500/20 text-rose-400' : 'bg-white/5 text-neutral-600'}`}
                        title="Toggle Trending"
                      >
                        <TrendingUp className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => toggleBadge(item, 'isBestSeller')}
                        className={`rounded-full p-1.5 ${item.isBestSeller ? 'bg-gold-500/20 text-gold-400' : 'bg-white/5 text-neutral-600'}`}
                        title="Toggle Best Seller"
                      >
                        <Award className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => toggleBadge(item, 'isVerified')}
                        className={`rounded-full px-2 text-[10px] font-semibold ${item.isVerified ? 'bg-gold-500/20 text-gold-400' : 'bg-white/5 text-neutral-600'}`}
                        title="Toggle Gold Verified"
                      >
                        GV
                      </button>
                    </div>
                  </td>
                  <td className="py-3 text-neutral-400">{item.downloadCount}</td>
                  <td className="py-3">
                    <button onClick={() => onDelete(item.id)} className="text-neutral-500 hover:text-red-400">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
