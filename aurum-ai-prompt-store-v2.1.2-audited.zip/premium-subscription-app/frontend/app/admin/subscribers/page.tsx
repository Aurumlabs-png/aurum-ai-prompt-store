'use client';

import { useEffect, useState } from 'react';
import { Download, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

type Subscriber = {
  id: string;
  name: string;
  email: string;
  isEmailVerified: boolean;
  subscription?: { status: string; expiresAt?: string };
};

const statusColor: Record<string, string> = {
  ACTIVE: 'text-emerald-400',
  EXPIRED: 'text-red-400',
  NONE: 'text-neutral-400',
  CANCELLED: 'text-neutral-400',
};

export default function AdminSubscribersPage() {
  const [subs, setSubs] = useState<Subscriber[]>([]);
  const [loading, setLoading] = useState(true);

  const load = () => api.get('/admin/subscribers').then(({ data }) => setSubs(data.subscribers)).catch(() => toast.error('Could not load subscribers')).finally(() => setLoading(false));

  useEffect(() => { load(); }, []);

  const onRemove = async (id: string) => {
    if (!confirm('Remove this user permanently?')) return;
    try {
      await api.delete(`/admin/users/${id}`);
      toast.success('User removed');
      setSubs((prev) => prev.filter((s) => s.id !== id));
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to remove user');
    }
  };

  const exportCsv = () => {
    window.open(`${process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api'}/admin/export/subscribers.csv`, '_blank');
  };

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-neutral-50">Subscribers</h1>
          <p className="mt-1 text-neutral-400">Manage users and monitor subscription status.</p>
        </div>
        <button onClick={exportCsv} className="btn-outline text-sm">
          <Download className="h-4 w-4" /> Export CSV
        </button>
      </div>

      <div className="glass-card mt-6 overflow-x-auto">
        {loading ? (
          <p className="text-neutral-500">Loading…</p>
        ) : (
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-white/10 text-neutral-400">
                <th className="pb-3">Name</th>
                <th className="pb-3">Email</th>
                <th className="pb-3">Status</th>
                <th className="pb-3">Expires</th>
                <th className="pb-3"></th>
              </tr>
            </thead>
            <tbody>
              {subs.map((s) => (
                <tr key={s.id} className="border-b border-white/5 text-neutral-200">
                  <td className="py-3">{s.name}</td>
                  <td className="py-3 text-neutral-400">{s.email}</td>
                  <td className={`py-3 font-medium ${statusColor[s.subscription?.status || 'NONE']}`}>
                    {s.subscription?.status || 'NONE'}
                  </td>
                  <td className="py-3 text-neutral-400">
                    {s.subscription?.expiresAt ? new Date(s.subscription.expiresAt).toLocaleDateString() : '—'}
                  </td>
                  <td className="py-3">
                    <button onClick={() => onRemove(s.id)} className="text-neutral-500 hover:text-red-400">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
