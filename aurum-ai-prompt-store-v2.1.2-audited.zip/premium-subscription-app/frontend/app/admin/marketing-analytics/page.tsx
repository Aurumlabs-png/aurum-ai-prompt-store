'use client';

import { useEffect, useState } from 'react';
import { Loader2, BarChart3 } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

export default function MarketingAnalyticsPage() {
  const [form, setForm] = useState({ gaId: '', metaPixelId: '', tiktokPixelId: '' });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get('/admin/settings').then(({ data }) => {
      setForm({
        gaId: data.settings.gaId || '',
        metaPixelId: data.settings.metaPixelId || '',
        tiktokPixelId: data.settings.tiktokPixelId || '',
      });
    }).catch(() => toast.error('Could not load analytics settings')).finally(() => setLoading(false));
  }, []);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.patch('/admin/settings', form);
      toast.success('Analytics settings saved — tags will load on the next page visit');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Could not save settings');
    } finally {
      setSaving(false);
    }
  };

  const panels = [
    { key: 'gaId', label: 'Google Analytics', placeholder: 'G-XXXXXXXXXX', help: 'GA4 Measurement ID' },
    { key: 'metaPixelId', label: 'Meta Pixel', placeholder: '1234567890123456', help: 'Facebook/Instagram Pixel ID' },
    { key: 'tiktokPixelId', label: 'TikTok Pixel', placeholder: 'CXXXXXXXXXXXXXXXXXXX', help: 'TikTok Pixel Code' },
  ] as const;

  return (
    <div>
      <h1 className="font-display text-3xl font-bold text-neutral-50">Analytics Integrations</h1>
      <p className="mt-1 text-neutral-400">
        Connect tracking pixels once — Aurum injects them site-wide automatically. No code changes needed.
      </p>

      {loading ? (
        <p className="mt-8 text-neutral-500">Loading…</p>
      ) : (
        <form onSubmit={save} className="mt-8 space-y-5">
          {panels.map((p) => (
            <div key={p.key} className="glass-card">
              <div className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-gold-400" />
                <p className="font-semibold text-neutral-100">{p.label}</p>
              </div>
              <p className="mt-1 text-xs text-neutral-500">{p.help}</p>
              <input
                placeholder={p.placeholder}
                className="input-field mt-3"
                value={form[p.key]}
                onChange={(e) => setForm({ ...form, [p.key]: e.target.value })}
              />
            </div>
          ))}

          <button disabled={saving} className="btn-gold">
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            Save Integrations
          </button>
        </form>
      )}
    </div>
  );
}
