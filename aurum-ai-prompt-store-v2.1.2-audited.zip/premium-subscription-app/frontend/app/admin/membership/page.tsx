'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { Loader2, Crown, Users as UsersIcon } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

type Subscriber = { subscription?: { status: string } };

export default function MembershipPage() {
  const [priceNaira, setPriceNaira] = useState('');
  const [durationDays, setDurationDays] = useState('');
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [counts, setCounts] = useState({ free: 0, premium: 0 });

  useEffect(() => {
    Promise.all([api.get('/admin/settings'), api.get('/admin/subscribers')]).then(([s, subs]) => {
      const price = s.data.settings.membershipPriceKobo;
      const days = s.data.settings.membershipDurationDays;
      setPriceNaira(price ? String(price / 100) : '1000');
      setDurationDays(days ? String(days) : '30');

      const list: Subscriber[] = subs.data.subscribers;
      const premium = list.filter((u) => u.subscription?.status === 'ACTIVE').length;
      setCounts({ free: list.length - premium, premium });
    }).catch(() => toast.error('Could not load membership data')).finally(() => setLoading(false));
  }, []);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await api.patch('/admin/settings', {
        membershipPriceKobo: Math.round(Number(priceNaira) * 100),
        membershipDurationDays: Number(durationDays),
      });
      toast.success('Membership settings updated');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Could not save settings');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="font-display text-3xl font-bold text-neutral-50">Membership</h1>
        <p className="mt-1 text-neutral-400">Manage pricing, renewal duration, and view your member mix.</p>
      </div>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
        <div className="glass-card">
          <div className="flex items-center justify-between">
            <p className="text-sm text-neutral-400">Free Users</p>
            <UsersIcon className="h-4 w-4 text-neutral-500" />
          </div>
          <p className="mt-3 font-display text-3xl font-bold text-neutral-50">{loading ? '—' : counts.free}</p>
          <Link href="/admin/users" className="mt-2 inline-block text-xs text-gold-400 hover:underline">Manage free users</Link>
        </div>
        <div className="glass-card border-gold-500/20">
          <div className="flex items-center justify-between">
            <p className="text-sm text-neutral-400">Premium Members</p>
            <Crown className="h-4 w-4 text-gold-400" />
          </div>
          <p className="mt-3 font-display text-3xl font-bold text-gold-400">{loading ? '—' : counts.premium}</p>
          <Link href="/admin/users" className="mt-2 inline-block text-xs text-gold-400 hover:underline">Manage premium users</Link>
        </div>
      </div>

      <form onSubmit={save} className="glass-card space-y-4">
        <h2 className="font-semibold text-neutral-100">Pricing & Renewal Settings</h2>
        <p className="text-sm text-neutral-400">
          Changes here apply to new subscriptions and renewals immediately — no redeploy needed.
        </p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="mb-1 block text-xs text-neutral-500">Price (₦)</label>
            <input type="number" min={1} className="input-field" value={priceNaira} onChange={(e) => setPriceNaira(e.target.value)} />
          </div>
          <div>
            <label className="mb-1 block text-xs text-neutral-500">Renewal Duration (days)</label>
            <input type="number" min={1} className="input-field" value={durationDays} onChange={(e) => setDurationDays(e.target.value)} />
          </div>
        </div>
        <button disabled={saving} className="btn-gold">
          {saving && <Loader2 className="h-4 w-4 animate-spin" />}
          Save Membership Settings
        </button>
      </form>
    </div>
  );
}
