import type { Metadata } from 'next';
import { Inter, Playfair_Display } from 'next/font/google';
import { AuthProvider } from '@/lib/auth-context';
import { Toaster } from 'sonner';
import AnalyticsScripts from '@/components/AnalyticsScripts';
import './globals.css';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const playfair = Playfair_Display({ subsets: ['latin'], variable: '--font-playfair' });

export const metadata: Metadata = {
  title: 'Aurum — Premium AI Prompt Vault',
  description: 'Hand-crafted, tested AI prompts for ChatGPT, Claude, and Midjourney — organized by category, unlocked instantly when you subscribe.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${playfair.variable}`}>
      <body className="bg-black min-h-screen">
        <AuthProvider>
          {children}
          <Toaster theme="dark" position="top-right" richColors />
          <AnalyticsScripts />
        </AuthProvider>
      </body>
    </html>
  );
}
