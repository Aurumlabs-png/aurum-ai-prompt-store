'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Crown, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post('/auth/forgot-password', { email });
      setSent(true);
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center px-6">
      <div className="glass-card w-full max-w-md">
        <Link href="/" className="mb-6 flex items-center justify-center gap-2">
          <Crown className="h-6 w-6 text-gold-500" />
          <span className="font-display text-xl font-bold text-gold-500">Aurum</span>
        </Link>

        {sent ? (
          <div role="status" className="text-center">
            <p className="text-neutral-300">
              If that email exists, a reset link has been sent. Check your inbox.
            </p>
            <Link href="/login" className="mt-6 inline-block text-sm text-gold-400 hover:underline">
              Back to login
            </Link>
          </div>
        ) : (
          <>
            <h1 className="text-center font-display text-2xl font-bold text-neutral-50">Reset password</h1>
            <p className="mt-1 text-center text-sm text-neutral-400">
              Enter your email and we'll send you a reset link.
            </p>
            <form onSubmit={onSubmit} className="mt-8 space-y-4">
              <label htmlFor="forgot-email" className="sr-only">Email address</label>
              <input
                id="forgot-email"
                name="email"
                required
                type="email"
                autoComplete="email"
                placeholder="Email address"
                className="input-field"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <button disabled={loading} aria-busy={loading} className="btn-gold w-full">
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                Send reset link
              </button>
            </form>
          </>
        )}
      </div>
    </main>
  );
}
