'use client';

import { Suspense, useEffect, useState } from 'react';
import { useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { Crown, CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { api } from '@/lib/api';

function VerifyEmailStatus() {
  const searchParams = useSearchParams();
  const token = searchParams.get('token');
  const [status, setStatus] = useState<'loading' | 'success' | 'error'>('loading');

  useEffect(() => {
    if (!token) return setStatus('error');
    api
      .get(`/auth/verify-email?token=${token}`)
      .then(() => setStatus('success'))
      .catch(() => setStatus('error'));
  }, [token]);

  return (
    <div className="glass-card w-full max-w-md text-center">
      <Link href="/" className="mb-6 flex items-center justify-center gap-2">
        <Crown className="h-6 w-6 text-gold-500" />
        <span className="font-display text-xl font-bold text-gold-500">Aurum</span>
      </Link>

      <div role="status">
        {status === 'loading' && <Loader2 className="mx-auto h-8 w-8 animate-spin text-gold-400" />}
        {status === 'success' && (
          <>
            <CheckCircle2 className="mx-auto h-10 w-10 text-emerald-400" />
            <p className="mt-4 text-neutral-200">Your email has been verified!</p>
            <Link href="/dashboard" className="btn-gold mt-6 inline-flex">Go to dashboard</Link>
          </>
        )}
        {status === 'error' && (
          <>
            <XCircle className="mx-auto h-10 w-10 text-red-400" />
            <p className="mt-4 text-neutral-200">This verification link is invalid or expired.</p>
            <Link href="/login" className="mt-6 inline-block text-sm text-gold-400 hover:underline">
              Back to login
            </Link>
          </>
        )}
      </div>
    </div>
  );
}

export default function VerifyEmailPage() {
  return (
    <main className="flex min-h-screen items-center justify-center px-6">
      <Suspense fallback={<Loader2 className="h-6 w-6 animate-spin text-gold-400" />}>
        <VerifyEmailStatus />
      </Suspense>
    </main>
  );
}
