import Navbar from '@/components/landing/Navbar';
import Hero from '@/components/landing/Hero';
import Categories from '@/components/landing/Categories';
import FeaturedPrompts from '@/components/landing/FeaturedPrompts';
import Features from '@/components/landing/Features';
import Pricing from '@/components/landing/Pricing';
import Testimonials from '@/components/landing/Testimonials';
import FAQ from '@/components/landing/FAQ';
import Footer from '@/components/landing/Footer';

export default function LandingPage() {
  return (
    <main className="overflow-hidden bg-black">
      <Navbar />
      <Hero />
      <Categories />
      <FeaturedPrompts />
      <Features />
      <Pricing />
      <Testimonials />
      <FAQ />
      <Footer />
    </main>
  );
}
