'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Crown, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth-context';

export default function SignupPage() {
  const router = useRouter();
  const { refresh } = useAuth();
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post('/auth/signup', form);
      await refresh();
      toast.success('Account created! Check your email to verify.');
      router.push('/dashboard');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Signup failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center px-6">
      <div className="glass-card w-full max-w-md">
        <Link href="/" className="mb-6 flex items-center justify-center gap-2">
          <Crown className="h-6 w-6 text-gold-500" />
          <span className="font-display text-xl font-bold text-gold-500">Aurum</span>
        </Link>
        <h1 className="text-center font-display text-2xl font-bold text-neutral-50">Create your account</h1>
        <p className="mt-1 text-center text-sm text-neutral-400">Join the inner circle in seconds.</p>

        <form onSubmit={onSubmit} className="mt-8 space-y-4">
          <label htmlFor="signup-name" className="sr-only">Full name</label>
          <input
            id="signup-name"
            name="name"
            required
            autoComplete="name"
            placeholder="Full name"
            className="input-field"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
          />
          <label htmlFor="signup-email" className="sr-only">Email address</label>
          <input
            id="signup-email"
            name="email"
            required
            type="email"
            autoComplete="email"
            placeholder="Email address"
            className="input-field"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />
          <label htmlFor="signup-password" className="sr-only">Password</label>
          <input
            id="signup-password"
            name="password"
            required
            type="password"
            minLength={8}
            autoComplete="new-password"
            placeholder="Password (min 8 characters)"
            className="input-field"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
          />
          <button disabled={loading} aria-busy={loading} className="btn-gold w-full">
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            Create account
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-neutral-400">
          Already have an account?{' '}
          <Link href="/login" className="text-gold-400 hover:underline">Log in</Link>
        </p>
      </div>
    </main>
  );
}
