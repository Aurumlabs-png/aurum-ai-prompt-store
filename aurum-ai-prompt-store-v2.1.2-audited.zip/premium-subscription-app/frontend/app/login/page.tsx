'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Crown, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth-context';

export default function LoginPage() {
  const router = useRouter();
  const { refresh } = useAuth();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data } = await api.post('/auth/login', form);
      await refresh();
      toast.success('Welcome back!');
      router.push(data.user.role === 'ADMIN' ? '/admin' : '/dashboard');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="flex min-h-screen items-center justify-center px-6">
      <div className="glass-card w-full max-w-md">
        <Link href="/" className="mb-6 flex items-center justify-center gap-2">
          <Crown className="h-6 w-6 text-gold-500" />
          <span className="font-display text-xl font-bold text-gold-500">Aurum</span>
        </Link>
        <h1 className="text-center font-display text-2xl font-bold text-neutral-50">Welcome back</h1>

        <form onSubmit={onSubmit} className="mt-8 space-y-4">
          <label htmlFor="login-email" className="sr-only">Email address</label>
          <input
            id="login-email"
            name="email"
            required
            type="email"
            autoComplete="email"
            placeholder="Email address"
            className="input-field"
            value={form.email}
            onChange={(e) => setForm({ ...form, email: e.target.value })}
          />
          <label htmlFor="login-password" className="sr-only">Password</label>
          <input
            id="login-password"
            name="password"
            required
            type="password"
            autoComplete="current-password"
            placeholder="Password"
            className="input-field"
            value={form.password}
            onChange={(e) => setForm({ ...form, password: e.target.value })}
          />
          <div className="text-right">
            <Link href="/forgot-password" className="text-xs text-gold-400 hover:underline">
              Forgot password?
            </Link>
          </div>
          <button disabled={loading} aria-busy={loading} className="btn-gold w-full">
            {loading && <Loader2 className="h-4 w-4 animate-spin" />}
            Log in
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-neutral-400">
          Don't have an account?{' '}
          <Link href="/signup" className="text-gold-400 hover:underline">Sign up</Link>
        </p>
      </div>
    </main>
  );
}
