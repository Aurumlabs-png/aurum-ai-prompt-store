'use client';

import { Suspense, useState } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { Crown, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { api } from '@/lib/api';

function ResetPasswordForm() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const token = searchParams.get('token') || '';
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await api.post('/auth/reset-password', { token, password });
      toast.success('Password reset. Please log in.');
      router.push('/login');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Reset failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="glass-card w-full max-w-md">
      <Link href="/" className="mb-6 flex items-center justify-center gap-2">
        <Crown className="h-6 w-6 text-gold-500" />
        <span className="font-display text-xl font-bold text-gold-500">Aurum</span>
      </Link>
      <h1 className="text-center font-display text-2xl font-bold text-neutral-50">Set a new password</h1>

      <form onSubmit={onSubmit} className="mt-8 space-y-4">
        <label htmlFor="reset-password-input" className="sr-only">New password</label>
        <input
          id="reset-password-input"
          name="password"
          required
          type="password"
          minLength={8}
          autoComplete="new-password"
          placeholder="New password (min 8 characters)"
          className="input-field"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button disabled={loading || !token} aria-busy={loading} className="btn-gold w-full">
          {loading && <Loader2 className="h-4 w-4 animate-spin" />}
          Reset password
        </button>
        {!token && <p className="text-center text-xs text-red-400">Missing or invalid reset link.</p>}
      </form>
    </div>
  );
}

export default function ResetPasswordPage() {
  return (
    <main className="flex min-h-screen items-center justify-center px-6">
      <Suspense fallback={<Loader2 className="h-6 w-6 animate-spin text-gold-400" />}>
        <ResetPasswordForm />
      </Suspense>
    </main>
  );
}
