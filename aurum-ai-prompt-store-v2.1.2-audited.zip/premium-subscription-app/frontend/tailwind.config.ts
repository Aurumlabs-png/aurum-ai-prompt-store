import type { Config } from 'tailwindcss';

const config: Config = {
  darkMode: 'class',
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        gold: {
          50: '#fdf9ec',
          100: '#faf0cc',
          300: '#e8c766',
          400: '#dfb94a',
          500: '#d4af37', // primary accent
          600: '#b8941f',
          700: '#8f7118',
        },
        emerald: {
          50: '#e8f5ef',
          100: '#c3e6d6',
          400: '#1f7a52',
          500: '#0f5c3d', // primary brand
          600: '#0b4a31',
          700: '#083825',
          900: '#0b1f17', // deep background
        },
      },
      backgroundImage: {
        'gold-gradient': 'linear-gradient(135deg, #f5d576 0%, #d4af37 45%, #b8941f 100%)',
        'emerald-radial': 'radial-gradient(circle at 20% 20%, #0f5c3d 0%, #0b1f17 70%)',
      },
      boxShadow: {
        gold: '0 8px 30px -8px rgba(212,175,55,0.45)',
        glass: '0 8px 32px 0 rgba(0,0,0,0.25)',
      },
      backdropBlur: {
        xs: '2px',
      },
      fontFamily: {
        display: ['var(--font-playfair)', 'serif'],
        sans: ['var(--font-inter)', 'sans-serif'],
      },
      keyframes: {
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
      animation: {
        shimmer: 'shimmer 3s linear infinite',
      },
    },
  },
  plugins: [],
};

export default config;
